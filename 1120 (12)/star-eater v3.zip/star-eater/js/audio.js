'use strict';
/* audio.js - Web Audio 로 BGM 2곡과 효과음을 직접 합성합니다. (외부 음원 파일 없음)
   모든 소리는 Sound.play('이름') 하나로 재생하고, 같은 소리가 한꺼번에 몰리지 않게 제한합니다.
   브라우저 정책 때문에 첫 클릭/키 입력 뒤에 AudioContext 를 시작합니다. */
const Sound = {
  ctx: null, master: null, bgmBus: null, sfxBus: null, noiseBuf: null,
  vol: { bgm: 0.5, sfx: 0.7 }, muted: false,
  KEY: 'starEater.audio',
  active: 0,                      // 지금 울리는 효과음 수 (동시 재생 제한용)
  lastPlay: {},                   // 소리별 마지막 재생 시각
  gemCombo: 0, gemLast: -9,       // 별 조각 연속 흡수 음 높이
  tracks: {}, trackName: null,    // BGM 트랙별 게인
  step: 0, nextTime: 0, timer: null,

  /* ---------- 설정 저장/불러오기 ---------- */
  load() {
    try {
      const v = JSON.parse(localStorage.getItem(this.KEY));
      if (v) {
        if (typeof v.bgm === 'number') this.vol.bgm = U.clamp(v.bgm, 0, 1);
        if (typeof v.sfx === 'number') this.vol.sfx = U.clamp(v.sfx, 0, 1);
        this.muted = !!v.muted;
      }
    } catch (e) { /* 저장소를 못 써도 정상 동작 */ }
  },
  save() {
    try { localStorage.setItem(this.KEY, JSON.stringify({ bgm: this.vol.bgm, sfx: this.vol.sfx, muted: this.muted })); } catch (e) { /* ignore */ }
  },

  /* ---------- 시작 ---------- */
  init() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    try {
      this.ctx = new AC();
    } catch (e) { return; }
    const c = this.ctx;
    this.master = c.createGain(); this.master.connect(c.destination);
    this.bgmBus = c.createGain(); this.bgmBus.connect(this.master);
    this.sfxBus = c.createGain(); this.sfxBus.connect(this.master);
    this.applyVolume();
    // 흰 잡음 버퍼 (타격음, 폭발음용)
    const len = c.sampleRate * 1;
    this.noiseBuf = c.createBuffer(1, len, c.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    for (const n of ['normal', 'boss']) { const g = c.createGain(); g.gain.value = 0; g.connect(this.bgmBus); this.tracks[n] = g; }
    this.nextTime = c.currentTime + 0.1;
    this.timer = setInterval(() => this.schedule(), 25);
    if (this.trackName) this.setTrack(this.trackName, true);
  },

  applyVolume() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.muted ? 0 : 1, t, 0.03);
    this.bgmBus.gain.setTargetAtTime(this.vol.bgm * 0.5, t, 0.05);
    this.sfxBus.gain.setTargetAtTime(this.vol.sfx * 0.8, t, 0.05);
  },
  setVolume(kind, v) { this.vol[kind] = U.clamp(v, 0, 1); this.applyVolume(); this.save(); },
  toggleMute() { this.muted = !this.muted; this.applyVolume(); this.save(); return this.muted; },

  /* ---------- BGM ---------- */
  /* 'normal' | 'boss' | null(조용히). 크로스페이드로 바뀝니다. */
  setTrack(name, force) {
    if (name === this.trackName && !force) return;
    this.trackName = name;
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    for (const n of ['normal', 'boss']) {
      const g = this.tracks[n].gain;
      g.cancelScheduledValues(t);
      g.setValueAtTime(g.value, t);
      g.linearRampToValueAtTime(n === name ? 1 : 0, t + 1.2);
    }
  },

  mtof(m) { return 440 * Math.pow(2, (m - 69) / 12); },

  /* 노트를 미리 예약하는 스케줄러 (0.2초 앞까지) */
  schedule() {
    const c = this.ctx;
    if (!c || c.state !== 'running') return;
    while (this.nextTime < c.currentTime + 0.2) {
      this.bgmNormal(this.step, this.nextTime);
      this.bgmBoss(this.step, this.nextTime);
      this.nextTime += 0.14;                 // 한 스텝 (16분음표)
      this.step++;
    }
  },
  note(bus, freq, t, dur, type, vol, attack) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = freq;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + (attack || 0.01));
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(bus);
    o.start(t); o.stop(t + dur + 0.05);
  },
  hat(bus, t, vol) {
    const c = this.ctx, s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf; f.type = 'highpass'; f.frequency.value = 7000;
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
    s.connect(f); f.connect(g); g.connect(bus);
    s.start(t, Math.random() * 0.5, 0.06);
  },
  /* 평상시: 느리고 몽환적인 A단조 아르페지오 */
  bgmNormal(step, t) {
    const bus = this.tracks.normal;
    if (!bus || bus.gain.value < 0.001 && this.trackName !== 'normal') return;
    const bar = Math.floor(step / 16) % 4, s = step % 16;
    const roots = [57, 53, 48, 55];                       // Am F C G
    const chord = [[0, 3, 7], [0, 4, 7], [0, 4, 7], [0, 4, 7]];
    const r = roots[bar], ch = bar === 0 ? [0, 3, 7] : chord[bar];
    if (s === 0) for (const iv of ch) this.note(bus, this.mtof(r + 12 + iv), t, 2.2, 'triangle', 0.05, 0.4);
    if (s === 0 || s === 8) this.note(bus, this.mtof(r - 12), t, 1.0, 'sine', 0.16, 0.02);
    if (s % 2 === 0) {
      const k = (s / 2) % 4, iv = [ch[0], ch[1], ch[2], ch[1] + 12][k];
      this.note(bus, this.mtof(r + 24 + iv), t, 0.5, 'sine', 0.07, 0.01);
    }
  },
  /* 보스전: 빠르고 긴장감 있는 D단조, 킥과 하이햇 */
  bgmBoss(step, t) {
    const bus = this.tracks.boss;
    if (!bus || bus.gain.value < 0.001 && this.trackName !== 'boss') return;
    const bar = Math.floor(step / 16) % 4, s = step % 16;
    const roots = [50, 46, 48, 45];                       // Dm Bb C A
    const r = roots[bar];
    if (s % 4 === 0) {                                    // 킥
      const c = this.ctx, o = c.createOscillator(), g = c.createGain();
      o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(42, t + 0.12);
      g.gain.setValueAtTime(0.5, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.16);
      o.connect(g); g.connect(bus); o.start(t); o.stop(t + 0.2);
    }
    if (s % 2 === 1) this.hat(bus, t, 0.12);
    if (s % 2 === 0) this.note(bus, this.mtof(r - 12 + (s % 8 === 6 ? 7 : 0)), t, 0.2, 'sawtooth', 0.09, 0.005);
    const lead = [0, 3, 7, 10, 7, 3, 12, 10][(s >> 1) % 8];
    if (s % 2 === 0) this.note(bus, this.mtof(r + 24 + lead), t, 0.18, 'square', 0.035, 0.005);
  },

  /* ---------- 효과음 ---------- */
  tone(freq, dur, type, vol, slideTo, delay) {
    const c = this.ctx, t = c.currentTime + (delay || 0);
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.sfxBus);
    o.start(t); o.stop(t + dur + 0.03);
  },
  noise(dur, vol, freq, type, delay) {
    const c = this.ctx, t = c.currentTime + (delay || 0);
    const s = c.createBufferSource(), f = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf; f.type = type || 'lowpass'; f.frequency.value = freq || 1500;
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.sfxBus);
    s.start(t, Math.random() * 0.5, dur + 0.02);
  },

  /* 소리 정의: gap = 같은 소리 최소 간격(초), fn = 합성 */
  defs: {
    fire_spaceDust: { gap: 0.09, fn: (S) => S.tone(980, 0.06, 'square', 0.05, 620) },
    fire_radiantHeat: { gap: 0.2, fn: (S) => S.noise(0.18, 0.08, 700, 'lowpass') },
    fire_satellite: { gap: 0.3, fn: (S) => S.tone(660, 0.25, 'sine', 0.07, 990) },
    fire_meteor: { gap: 0.12, fn: (S) => { S.tone(180, 0.28, 'sawtooth', 0.09, 50); S.noise(0.25, 0.1, 900, 'lowpass'); } },
    fire_atmosphere: { gap: 0.3, fn: (S) => S.tone(440, 0.3, 'sine', 0.07, 880) },
    fire_comet: { gap: 0.15, fn: (S) => S.tone(500, 0.3, 'sine', 0.07, 1500) },
    fire_blackHole: { gap: 0.4, fn: (S) => { S.tone(120, 0.6, 'sine', 0.12, 50); S.tone(90, 0.6, 'triangle', 0.08, 40); } },
    fire_plasma: { gap: 0.12, fn: (S) => { S.tone(300, 0.14, 'sawtooth', 0.06, 1100); S.noise(0.1, 0.05, 4000, 'highpass'); } },
    hit: { gap: 0.045, fn: (S) => S.tone(220 + Math.random() * 60, 0.04, 'square', 0.025, 110) },
    kill: { gap: 0.05, fn: (S) => { S.noise(0.1, 0.07, 1200, 'lowpass'); S.tone(300, 0.08, 'triangle', 0.05, 120); } },
    gem: { gap: 0.03, fn: (S) => {
      const f = 520 * Math.pow(2, Math.min(S.gemCombo, 12) / 12 * 1.0);
      S.tone(f, 0.09, 'sine', 0.06, f * 1.5);
    } },
    levelup: { gap: 0.3, fn: (S) => [523, 659, 784, 1047].forEach((f, i) => S.tone(f, 0.25, 'triangle', 0.09, null, i * 0.07)) },
    card: { gap: 0.05, fn: (S) => { S.tone(700, 0.08, 'square', 0.05, 1000); } },
    evolve: { gap: 0.5, fn: (S) => [392, 494, 587, 784, 988].forEach((f, i) => S.tone(f, 0.5, 'sawtooth', 0.06, f * 1.01, i * 0.09)) },
    shieldBreak: { gap: 0.2, fn: (S) => { S.noise(0.35, 0.14, 3000, 'highpass'); S.tone(900, 0.3, 'triangle', 0.08, 200); } },
    hurt: { gap: 0.15, fn: (S) => { S.tone(160, 0.25, 'sawtooth', 0.14, 60); S.noise(0.15, 0.1, 600, 'lowpass'); } },
    bossWarn: { gap: 0.8, fn: (S) => { S.tone(880, 0.18, 'square', 0.08); S.tone(880, 0.18, 'square', 0.08, null, 0.25); } },
    bossAppear: { gap: 1, fn: (S) => { S.tone(60, 1.6, 'sawtooth', 0.14, 140); S.noise(1.2, 0.1, 400, 'lowpass'); } },
    bossDeath: { gap: 1, fn: (S) => { S.noise(1.0, 0.2, 1800, 'lowpass'); S.tone(300, 1.0, 'sawtooth', 0.12, 40); [0, 0.2, 0.4].forEach((d) => S.noise(0.3, 0.12, 2500, 'lowpass', d)); } },
    item: { gap: 0.1, fn: (S) => [784, 988, 1175].forEach((f, i) => S.tone(f, 0.18, 'sine', 0.08, null, i * 0.05)) },
    burst: { gap: 0.3, fn: (S) => { S.noise(0.6, 0.22, 2500, 'lowpass'); S.tone(200, 0.5, 'sawtooth', 0.12, 50); } },
    gameover: { gap: 1, fn: (S) => [392, 330, 262, 196].forEach((f, i) => S.tone(f, 0.6, 'triangle', 0.1, f * 0.97, i * 0.28)) },
    clear: { gap: 1, fn: (S) => [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) => S.tone(f, 0.35, 'triangle', 0.1, null, i * 0.12)) },
  },

  play(name) {
    if (!this.ctx || this.muted || this.ctx.state !== 'running') return;
    const d = this.defs[name];
    if (!d) return;
    const now = this.ctx.currentTime;
    if (now - (this.lastPlay[name] || -9) < d.gap) return;       // 같은 소리 간격 제한
    if (this.active >= 14) return;                               // 동시 재생 수 제한
    this.lastPlay[name] = now;
    if (name === 'gem') {
      this.gemCombo = (now - this.gemLast < 0.45) ? this.gemCombo + 1 : 0;
      this.gemLast = now;
    }
    this.active++;
    setTimeout(() => { this.active = Math.max(0, this.active - 1); }, 180);
    d.fn(this);
  },
};
Sound.load();
