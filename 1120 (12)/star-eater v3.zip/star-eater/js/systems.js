'use strict';
/* systems.js - 진화 무기들이 함께 쓰는 공용 시스템
   (범위 폭발, 넉백/기절/화상/표식/견인, 연쇄 번개, 운석 낙하, 장판, 벽, 레이저 흔적)
   game.js 아래쪽에서 Game.prototype 에 합쳐집니다. */

function segDist(px, py, x1, y1, x2, y2) {
  const dx = x2 - x1, dy = y2 - y1, l2 = dx * dx + dy * dy;
  const t = l2 ? U.clamp(((px - x1) * dx + (py - y1) * dy) / l2, 0, 1) : 0;
  return Math.hypot(px - (x1 + dx * t), py - (y1 + dy * t));
}

const Systems = {
  initSystems() {
    this.strikes = []; this.zones = []; this.walls = []; this.segs = []; this.flashes = []; this.bolts = [];
    this.tmpB = [];            // 시스템 전용 공간 해시 질의 배열 (g.tmp 와 겹치지 않게)
    this.guide = null;         // 유도 플라즈마가 켜졌을 때 { range, turn }
  },

  /* ---------- 기본 도구 ---------- */
  /* 반경 안의 모든 적에게 범위 피해 */
  explode(x, y, r, dmg, color, quiet) {
    const near = this.enemyHash.query(x, y, r + 24, this.tmpB);
    for (const e of near) {
      if (!e.dead && Math.hypot(e.x - x, e.y - y) <= r + e.radius) this.damageEnemy(e, dmg, 'area', x, y);
    }
    this.fx.ring(x, y, r, color, 0.3);
    if (!quiet) this.fx.burst(x, y, color, 8, 140, 0.4, 3);
  },

  shootDust(x, y, angle, speed, dmg, range) {
    const c = CONFIG.weapons.spaceDust;
    const b = new Projectile(x, y, angle, speed, dmg, c.projectileRadius, range, 0, c.color);
    b.dust = true;
    this.projectiles.push(b);
    return b;
  },

  /* ---------- 상태 이상 (보스·앵커 등은 밀기/기절 면역) ---------- */
  knock(e, dx, dy, dist, dur) {
    if (e.dead || e.immovable || e.ccImmune) return;
    const d = Math.hypot(dx, dy) || 1;
    e.kn = { vx: dx / d * dist / dur, vy: dy / d * dist / dur, t: dur };
  },
  stun(e, t) {
    if (e.dead || e.immovable || e.ccImmune) return;
    e.stun = Math.max(e.stun, t);
  },
  ignite(e, time, gap, dmg) {
    if (!e.dead) e.burn = { t: time, gap, tick: gap, dmg };
  },

  /* 적 하나의 상태 처리. true 를 돌려주면 이번 프레임 이동/행동을 건너뜁니다(기절). */
  statusTick(e, dt) {
    if (e.knCd > 0) e.knCd -= dt;
    if (e.stunCd > 0) e.stunCd -= dt;
    if (e.mark > 0) e.mark -= dt;
    if (e.burn) {
      const b = e.burn;
      b.t -= dt; b.tick -= dt;
      if (b.tick <= 0) { b.tick += b.gap; this.damageEnemy(e, b.dmg, 'area'); if (e.dead) return true; }
      if (b.t <= 0) e.burn = null;
    }
    if (e.kn) {
      e.x += e.kn.vx * dt; e.y += e.kn.vy * dt;
      if ((e.kn.t -= dt) <= 0) e.kn = null;
    }
    if (e.tow) {                                       // 위성 쪽으로 끌려다님
      const sat = this.player.getWeapon('satellite');
      let best = null, bd = 1e12;
      if (sat && sat.active) {
        for (const s of sat.positions()) {
          const d = (s.x - e.x) ** 2 + (s.y - e.y) ** 2;
          if (d < bd) { bd = d; best = s; }
        }
      }
      if (!best || (e.tow.t -= dt) <= 0) e.tow = null;
      else if (!e.immovable && !e.ccImmune) {
        const d = Math.sqrt(bd) || 1, st = Math.min(e.tow.speed * dt, d);
        e.x += (best.x - e.x) / d * st; e.y += (best.y - e.y) / d * st;
      }
    }
    if (e.stun > 0) { e.stun -= dt; return true; }
    return false;
  },

  /* ---------- 연쇄 번개 (플라즈마 계열 공용) ----------
     hits = 총 타격 수(첫 대상 포함). 피해는 줄지 않습니다. */
  chain(first, dmg, hits, jump, sx, sy, color) {
    const list = [first], seen = new Set([first]);
    const pts = [{ x: sx, y: sy }, { x: first.x, y: first.y }];
    this.damageEnemy(first, dmg, 'line', sx, sy);
    let cur = first;
    for (let i = 1; i < hits; i++) {
      let best = null, bd = jump * jump;
      for (const e of this.enemies) {
        if (e.dead || seen.has(e)) continue;
        const d = (e.x - cur.x) ** 2 + (e.y - cur.y) ** 2;
        if (d <= bd) { bd = d; best = e; }
      }
      if (!best) break;
      seen.add(best); list.push(best); pts.push({ x: best.x, y: best.y });
      this.damageEnemy(best, dmg, 'line', cur.x, cur.y);
      cur = best;
    }
    for (const q of pts) q.j = [U.rand(-1, 1), U.rand(-1, 1)];
    this.bolts.push({ pts, t: 0.18, color });
    return { list, pts };
  },

  /* 선분(두께 w) 안의 살아 있는 적마다 fn 호출 */
  segEnemies(x1, y1, x2, y2, w, fn) {
    for (const e of this.enemies) {
      if (e.dead) continue;
      if (segDist(e.x, e.y, x1, y1, x2, y2) <= w / 2 + e.radius) fn(e);
    }
  },

  /* ---------- 운석 낙하 ---------- */
  addStrike(x, y, o) {
    this.strikes.push({ x, y, warn: o.warn, w0: o.warn, r: o.r, dmg: o.dmg, color: o.color, onImpact: o.onImpact || null });
  },

  /* ---------- 장판 (복사열/블랙홀 장판) ---------- */
  addZone(o) {
    const z = Object.assign({ t: o.tick || 0.5, spin: 0 }, o);
    this.zones.push(z);
    if (z.group) {                                     // 같은 종류는 max 개까지만
      const same = this.zones.filter((q) => q.group === z.group);
      for (let i = 0; i < same.length - z.max; i++) same[i].life = 0;
    }
    return z;
  },

  /* ---------- 벽 (일반 적과 적 탄을 막음) ---------- */
  addWall(x, y, ang, len, thick, life, max) {
    const c = Math.cos(ang) * len / 2, s = Math.sin(ang) * len / 2;
    this.walls.push({ x, y, ang, len, thick, life, life0: life, x1: x - c, y1: y - s, x2: x + c, y2: y + s });
    while (this.walls.length > max) this.walls.shift();
  },

  /* ---------- 레이저 흔적 (플라즈마 레이저) ---------- */
  addSeg(o) { this.segs.push(Object.assign({ t: o.tick, t0: o.life }, o, { life: o.life })); },
  addFlash(x1, y1, x2, y2, w, t, color) { this.flashes.push({ x1, y1, x2, y2, w, t, t0: t, color }); },

  /* ---------- 갱신 ---------- */
  updateSystems(dt) {
    // 운석
    for (const s of this.strikes) {
      s.warn -= dt;
      if (s.warn > 0) continue;
      s.done = true;
      this.explode(s.x, s.y, s.r, s.dmg, s.color, true);
      this.fx.burst(s.x, s.y, s.color, 16, 200, 0.5, 4);
      this.shake = Math.max(this.shake, 4);
      if (s.onImpact) s.onImpact(this, s);
    }
    this.strikes = this.strikes.filter((s) => !s.done);

    // 장판
    for (const z of this.zones) {
      z.life -= dt; z.spin += dt * 3;
      if (z.life <= 0) continue;
      let ticking = false;
      if (z.tick && (z.t -= dt) <= 0) { z.t += z.tick; ticking = true; }
      if (!ticking && !z.pull) continue;
      const near = this.enemyHash.query(z.x, z.y, z.r + 24, this.tmpB);
      for (const e of near) {
        if (e.dead) continue;
        const d = Math.hypot(z.x - e.x, z.y - e.y);
        if (d > z.r + e.radius) continue;
        if (z.pull && !e.immovable && !e.ccImmune && d > 10) {
          const st = Math.min(z.pull * dt, d - 10);
          e.x += (z.x - e.x) / d * st; e.y += (z.y - e.y) / d * st;
        }
        if (ticking && z.dmg) this.damageEnemy(e, z.dmg, 'area', z.x, z.y);
      }
    }
    this.zones = this.zones.filter((z) => z.life > 0);

    // 벽: 일반 적은 밀려나고 적 탄은 사라짐
    for (const w of this.walls) {
      w.life -= dt;
      if (w.life <= 0) continue;
      const near = this.enemyHash.query(w.x, w.y, w.len / 2 + 60, this.tmpB);
      for (const e of near) {
        if (e.dead || e.boss || e.immovable || e.ccImmune) continue;
        const dx = w.x2 - w.x1, dy = w.y2 - w.y1, l2 = dx * dx + dy * dy;
        const t = U.clamp(((e.x - w.x1) * dx + (e.y - w.y1) * dy) / l2, 0, 1);
        const cx = w.x1 + dx * t, cy = w.y1 + dy * t;
        const d = Math.hypot(e.x - cx, e.y - cy), lim = w.thick / 2 + e.radius;
        if (d >= lim) continue;
        let nx, ny;
        if (d > 0.001) { nx = (e.x - cx) / d; ny = (e.y - cy) / d; }
        else { nx = -Math.sin(w.ang); ny = Math.cos(w.ang); }
        e.x = cx + nx * lim; e.y = cy + ny * lim;
      }
      for (const b of this.enemyBullets) {
        if (!b.dead && segDist(b.x, b.y, w.x1, w.y1, w.x2, w.y2) <= w.thick / 2 + b.radius) b.dead = true;
      }
    }
    this.walls = this.walls.filter((w) => w.life > 0);

    // 레이저 흔적
    for (const s of this.segs) {
      s.life -= dt;
      if (s.life <= 0) continue;
      if ((s.t -= dt) > 0) continue;
      s.t += s.tick;
      for (const e of this.enemies) {
        if (e.dead) continue;
        for (let i = 1; i < s.pts.length; i++) {
          const a = s.pts[i - 1], b = s.pts[i];
          if (segDist(e.x, e.y, a.x, a.y, b.x, b.y) <= s.width / 2 + e.radius) { this.damageEnemy(e, s.dmg, 'line', a.x, a.y); break; }
        }
      }
    }
    this.segs = this.segs.filter((s) => s.life > 0);

    for (const f of this.flashes) f.t -= dt;
    this.flashes = this.flashes.filter((f) => f.t > 0);
    for (const b of this.bolts) b.t -= dt;
    this.bolts = this.bolts.filter((b) => b.t > 0);
  },

  /* ---------- 그리기 ---------- */
  drawSystemsUnder(ctx, cam) {
    for (const z of this.zones) {
      const x = z.x - cam.x, y = z.y - cam.y, c = z.color, f = Math.min(1, z.life / 0.4);
      ctx.globalAlpha = f;
      ctx.fillStyle = U.rgba(c, z.pull ? 0.07 : 0.12 + 0.05 * Math.sin(z.spin * 2));
      ctx.beginPath(); ctx.arc(x, y, z.r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = U.rgba(c, 0.4); ctx.lineWidth = 1.5; ctx.stroke();
      if (z.pull) {
        for (let i = 0; i < 3; i++) {
          const a0 = z.spin + i * Math.PI * 2 / 3;
          ctx.strokeStyle = U.rgba(c, 0.5); ctx.lineWidth = 2; ctx.beginPath();
          for (let k = 0; k <= 10; k++) {
            const t = k / 10, a = a0 + t * 2.2, r = z.r * (1 - t) * 0.95 + 4;
            const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
            if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
          }
          ctx.stroke();
        }
        ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(x, y, 9, 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
    for (const s of this.strikes) {                    // 착탄 경고
      const x = s.x - cam.x, y = s.y - cam.y, k = 1 - s.warn / s.w0;
      ctx.strokeStyle = U.rgba(s.color, 0.8); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, s.r, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = U.rgba(s.color, 0.10 + 0.25 * k);
      ctx.beginPath(); ctx.arc(x, y, s.r * k, 0, Math.PI * 2); ctx.fill();
    }
    for (const w of this.walls) {
      const f = Math.min(1, w.life / 0.4);
      ctx.save(); ctx.translate(w.x - cam.x, w.y - cam.y); ctx.rotate(w.ang); ctx.globalAlpha = f;
      ctx.fillStyle = 'rgba(255,150,100,0.35)'; ctx.fillRect(-w.len / 2, -w.thick / 2, w.len, w.thick);
      ctx.strokeStyle = 'rgba(255,190,150,0.95)'; ctx.lineWidth = 2; ctx.strokeRect(-w.len / 2, -w.thick / 2, w.len, w.thick);
      ctx.restore();
    }
  },

  drawSystemsOver(ctx, cam) {
    for (const s of this.strikes) {                    // 하늘에서 떨어지는 운석
      const k = 1 - s.warn / s.w0;
      const x = s.x - cam.x + (1 - k) * 90, y = s.y - cam.y - (1 - k) * 400;
      ctx.strokeStyle = U.rgba(s.color, 0.6); ctx.lineWidth = 6; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + 30, y - 120); ctx.stroke();
      ctx.drawImage(Glow.get(s.color, 24), x - 24, y - 24, 48, 48);
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI * 2); ctx.fill();
    }
    for (const s of this.segs) {
      ctx.globalAlpha = Math.min(1, s.life / 0.3);
      for (const pass of [[s.width, 0.3, s.color], [3, 0.9, [255, 255, 255]]]) {
        ctx.strokeStyle = U.rgba(pass[2], pass[1]); ctx.lineWidth = pass[0]; ctx.lineJoin = 'round'; ctx.lineCap = 'round';
        ctx.beginPath();
        s.pts.forEach((q, i) => { if (i === 0) ctx.moveTo(q.x - cam.x, q.y - cam.y); else ctx.lineTo(q.x - cam.x, q.y - cam.y); });
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
    for (const f of this.flashes) {
      ctx.globalAlpha = f.t / f.t0;
      ctx.strokeStyle = U.rgba(f.color, 0.5); ctx.lineWidth = f.w; ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(f.x1 - cam.x, f.y1 - cam.y); ctx.lineTo(f.x2 - cam.x, f.y2 - cam.y); ctx.stroke();
      ctx.strokeStyle = '#fff'; ctx.lineWidth = Math.max(2, f.w * 0.25);
      ctx.beginPath(); ctx.moveTo(f.x1 - cam.x, f.y1 - cam.y); ctx.lineTo(f.x2 - cam.x, f.y2 - cam.y); ctx.stroke();
      ctx.globalAlpha = 1;
    }
    for (const b of this.bolts) {                      // 플라즈마 번개
      ctx.globalAlpha = Math.min(1, b.t / 0.18 * 1.5);
      for (const pass of [[6, 0.35, b.color], [2, 1, [255, 255, 255]]]) {
        ctx.strokeStyle = U.rgba(pass[2], pass[1]); ctx.lineWidth = pass[0]; ctx.lineJoin = 'round';
        ctx.beginPath();
        for (let i = 0; i < b.pts.length; i++) {
          const q = b.pts[i];
          if (i === 0) { ctx.moveTo(q.x - cam.x, q.y - cam.y); continue; }
          const a = b.pts[i - 1], mx = (a.x + q.x) / 2 + q.j[0] * 14, my = (a.y + q.y) / 2 + q.j[1] * 14;
          ctx.lineTo(mx - cam.x, my - cam.y); ctx.lineTo(q.x - cam.x, q.y - cam.y);
        }
        ctx.stroke();
      }
      ctx.globalAlpha = 1;
    }
  },

  /* 유도 플라즈마: 표식이 붙은 적 쪽으로 우주 먼지 탄을 휘게 함 */
  guideProjectile(b, dt) {
    const G = this.guide;
    let best = null, bd = G.range * G.range;
    for (const e of this.enemies) {
      if (e.dead || e.mark <= 0) continue;
      const d = (e.x - b.x) ** 2 + (e.y - b.y) ** 2;
      if (d < bd) { bd = d; best = e; }
    }
    if (!best) return;
    let diff = Math.atan2(best.y - b.y, best.x - b.x) - b.angle;
    while (diff > Math.PI) diff -= Math.PI * 2;
    while (diff < -Math.PI) diff += Math.PI * 2;
    const turn = G.turn * Math.PI / 180 * dt;
    b.angle += U.clamp(diff, -turn, turn);
    b.vx = Math.cos(b.angle) * b.speed; b.vy = Math.sin(b.angle) * b.speed;
  },
};
