'use strict';
/* game.js - 게임 본체: 상태 머신, 루프, 카메라, 스폰, 충돌, 레벨업 카드, HUD */

const FONT = '"Noto Sans KR", "Malgun Gothic", "Apple SD Gothic Neo", sans-serif';
const STEP = 1 / 60;   // 고정 타임스텝

class Game {
  constructor() {
    this.canvas = document.getElementById('game');
    this.ctx = this.canvas.getContext('2d');
    this.input = new Input();
    this.fx = new Effects();
    this.bg = new Background();
    this.best = Store.load();
    this.debug = /[?&]debug=1/.test(location.search);
    this.state = 'title';          // title | select | play | levelup | pause | gameover | clear
    this.enemyHash = new SpatialHash(64);
    this.tmp = [];                 // 공간 해시 질의용 재사용 배열
    this.cam = { x: 0, y: 0 };
    this.shake = 0; this.hitFlash = 0;
    this.fps = 60;
    this.W = 800; this.H = 600; this.dpr = 1;

    this.resetWorld();
    this.bindUI();
    this.input.onPress = (code) => this.onKey(code);
    this.input.attachTouch(this.canvas);
    this.input.canStick = () => this.state === 'play';
    const wake = () => Sound.init();                       // 첫 클릭/키 입력 뒤에 소리 시작
    window.addEventListener('pointerdown', wake); window.addEventListener('keydown', wake);
    window.addEventListener('resize', () => this.resize());
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.autoPause(); });
    window.addEventListener('blur', () => this.autoPause());
    this.resize();
    this.showScreen('title');

    this.last = performance.now();
    this.acc = 0;
    requestAnimationFrame((t) => this.loop(t));
  }

  /* ---------------- 초기화 ---------------- */
  resetWorld() {
    this.player = new Player();
    this.enemies = [];
    this.gems = [];
    this.projectiles = [];
    this.enemyBullets = [];
    this.initSystems();
    this.initPolish();
    this.rerollsLeft = CONFIG.rerolls;
    this.initItems();
    this.bench = null;
    this.tick = 0;
    this.fx.reset();
    this.time = 0;
    this.growthTime = 0;      // 일반 적 성장 시간 (이후 보스전 동안 멈춤)
    this.spawnAcc = 0;
    this.pendingLevelUps = 0;
    this.cards = [];
    this.mergeTimer = 0;
    this.shake = 0; this.hitFlash = 0;
    this.godMode = false;
    this.arena = null;                      // 보스전 동안 플레이어를 가두는 화면 크기 구역
    this.bossPhase = 'none';                // none | intro | fight
    this.bossTimer = CONFIG.boss.firstAt;
    this.bossIndex = 0; this.bossIntroT = 0; this.bossKills = 0; this.bossTotal = 1; this.bossName = '';
    this.bossLast = { x: 0, y: 0 };
    this.bossOrder = U.shuffle(CONFIG.boss.order.slice()).concat([CONFIG.boss.finalBoss]);
    this.notice = { text: '', t: 0 };
  }

  notify(text) { this.notice = { text, t: 3 }; }

  startRun(passive) {
    this.resetWorld();
    const p = this.player;
    p.passive = passive;
    const w = new WEAPON_CLASSES[passive.weapon](this);
    w.mods = passive.mods;                 // 시작 무기에만 패시브 효과가 붙음
    p.weapons.push(w);
    if (passive.id === 'earth') {          // 지구: 대기가 시작 무기, 나머지 7종 중 랜덤 1개를 추가로 듦
      const others = CONFIG.weaponOrder.filter((id) => id !== 'atmosphere');
      const pickId = U.pick(others);
      p.weapons.push(new WEAPON_CLASSES[pickId](this));
      this.notify('랜덤 무기: ' + CONFIG.weapons[pickId].name);
    }
    this.input.clear();
    this.hideScreens();
    this.state = 'play';
    Sound.setTrack('normal');
  }

  resize() {
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.W = window.innerWidth; this.H = window.innerHeight;
    this.canvas.width = Math.floor(this.W * this.dpr);
    this.canvas.height = Math.floor(this.H * this.dpr);
    this.canvas.style.width = this.W + 'px';
    this.canvas.style.height = this.H + 'px';
  }

  /* ---------------- 메인 루프 ---------------- */
  loop(ts) {
    requestAnimationFrame((t) => this.loop(t));
    let frame = (ts - this.last) / 1000;
    this.last = ts;
    if (frame > 0.1) frame = 0.1;          // 탭 전환 후 시간이 튀지 않게
    this.fps += (1 / Math.max(frame, 0.001) - this.fps) * 0.05;
    this.acc += frame;
    while (this.acc >= STEP) {
      if (this.state === 'play') this.update(STEP);
      else if (this.state === 'ending') this.updateEnding(STEP);
      this.acc -= STEP;
    }
    this.render(frame);
  }

  autoPause() { if (this.state === 'play') this.pause(); }
  pause() { this.state = 'pause'; this.showScreen('pause'); }
  resume() { this.input.clear(); this.hideScreens(); this.state = 'play'; this.last = performance.now(); }

  /* ---------------- 업데이트 ---------------- */
  update(dt) {
    const p = this.player;
    this.time += dt;
    if (this.bossPhase === 'none') this.growthTime += dt;     // 보스전 동안 적 성장은 멈춤
    this.tick++;

    p.update(dt, this.input.getMove());
    if (!this.bench) this.updateBoss(dt);
    if (this.arena) this.clampToArena(p);
    if (this.bossPhase === 'none' && !this.bench && !this.labStopped()) this.spawn(dt);
    for (const e of this.enemies) if (!e.dead && !this.statusTick(e, dt)) e.update(dt, p, this);

    this.enemyHash.clear();
    for (const e of this.enemies) this.enemyHash.insert(e);

    const pl = p.getWeapon('plasma');
    this.guide = pl && pl.eid === 'guided' ? { range: pl.ep.range, turn: pl.ep.turn } : null;
    for (const w of p.weapons) w.update(dt);
    this.updateSystems(dt);
    this.updateItems(dt);
    this.updatePolish(dt);
    if (this.bench) this.benchTick(dt);
    this.updateProjectiles(dt);
    this.updateEnemyBullets(dt);
    this.contactDamage();
    this.updateGems(dt);
    this.fx.update(dt);

    compact(this.enemies); compact(this.gems); compact(this.projectiles); compact(this.enemyBullets);

    this.shake = Math.max(0, this.shake - 30 * dt);
    this.hitFlash = Math.max(0, this.hitFlash - dt);
    if (this.notice.t > 0) this.notice.t -= dt;
    if (this.godMode) p.hp = p.maxHp;

    this.checkLevelUp();
    if (p.hp <= 0) this.gameOver();
  }

  /* ---------------- 보스 ---------------- */
  clampToArena(p) {
    const A = this.arena;
    p.x = U.clamp(p.x, A.x0 + p.radius, A.x1 - p.radius);
    p.y = U.clamp(p.y, A.y0 + p.radius, A.y1 - p.radius);
  }

  updateBoss(dt) {
    const B = CONFIG.boss, p = this.player;
    if (this.bossPhase === 'none') {
      if (this.labStopped()) return;
      const before = Math.ceil(this.bossTimer);
      this.bossTimer -= dt;
      if (this.bossTimer <= B.warnAt && (before > B.warnAt && Math.ceil(this.bossTimer) <= B.warnAt || Math.ceil(this.bossTimer) !== before && this.bossTimer <= B.countdownAt)) Sound.play('bossWarn');
      if (this.bossTimer <= 0) this.beginBoss();
    } else if (this.bossPhase === 'intro') {
      this.bossIntroT -= dt;
      p.invuln = Math.max(p.invuln, 0.1);
      if (this.bossIntroT <= 0) { this.spawnBoss(); this.bossPhase = 'fight'; }
    } else {
      let alive = false;
      for (const e of this.enemies) {
        if (e.boss && !e.dead) { alive = true; this.bossLast.x = e.x; this.bossLast.y = e.y; }
      }
      if (!alive) this.endBoss();
    }
  }

  /* 소환 시작: 화면 크기 구역으로 가두고, 일반 적은 구슬로 바꿈 */
  beginBoss() {
    const p = this.player;
    this.arena = { x0: p.x - this.W / 2, y0: p.y - this.H / 2, x1: p.x + this.W / 2, y1: p.y + this.H / 2, cx: p.x, cy: p.y, w: this.W, h: this.H };
    for (const e of this.enemies) {
      if (e.dead) continue;
      e.dead = true;
      this.gems.push(new Gem(e.x, e.y, 'small'));
      this.fx.burst(e.x, e.y, e.color, 3, 80, 0.4, 2);
    }
    this.enemyBullets.length = 0;
    this.bossPhase = 'intro'; this.bossIntroT = CONFIG.boss.intro;
    const id = this.bossOrder[this.bossIndex];
    this.bossName = CONFIG.enemies[id].name;
    this.notify('보스 출현: ' + this.bossName);
    Sound.play('bossAppear'); Sound.setTrack('boss');
  }

  scaleFor(index) {
    const B = CONFIG.boss;
    return index >= this.bossOrder.length - 1 ? B.final : B.scale[Math.min(index, B.scale.length - 1)];
  }

  spawnBoss() {
    const B = CONFIG.boss, A = this.arena, id = this.bossOrder[this.bossIndex], sc = this.scaleFor(this.bossIndex);
    const e = new Enemy(A.cx, A.y0 + A.h * 0.28, id, 0);
    e.boss = true; e.ccImmune = true; e.immovable = true;
    e.dmgMul = sc.dmg; e.pSpeedMul = sc.speed; e.intMul = sc.interval;
    e.maxHp = e.hp = B.baseHp * sc.hp * B.hpMul[id];
    e.contact = B.contact * sc.dmg;
    if (id === 'bossSplit') {
      e.gen = 0; e.ccImmune = false; e.immovable = false; e.radius = e.radius0 = B.split.radius[0];
    }
    if (e.behavior.init2) e.behavior.init2(e, this);
    this.enemies.push(e);
    if (id === 'bossShield') e.behavior.spawnSats(e, this);
    this.bossTotal = e.maxHp;
    this.bossLast.x = e.x; this.bossLast.y = e.y;
    this.fx.ring(e.x, e.y, 150, e.color, 0.8); this.shake = 10;
  }

  /* 분열 보스 조각 */
  makePiece(parent, gen) {
    const S = CONFIG.boss.split;
    const c = new Enemy(parent.x, parent.y, 'bossSplit', 0);
    c.boss = true; c.gen = gen; c.ccImmune = false; c.immovable = false;
    c.dmgMul = parent.dmgMul; c.pSpeedMul = parent.pSpeedMul; c.intMul = parent.intMul;
    c.radius = c.radius0 = S.radius[gen];
    c.maxHp = c.hp = Math.max(1, parent.hp / 2);
    c.contact = parent.contact;
    return c;
  }

  endBoss() {
    const B = CONFIG.boss, p = this.player, x = this.bossLast.x, y = this.bossLast.y;
    const n = B.dropCount + (Math.random() < B.dropExtraChance ? 1 : 0);
    for (let i = 0; i < n; i++) this.gems.push(new Gem(x + U.rand(-30, 30), y + U.rand(-30, 30), 'large'));
    if (B.healOnKill) p.heal(p.maxHp * B.healOnKill);
    if (CONFIG.items.bossDrop && this.bossIndex < this.bossOrder.length - 1) this.dropItem(x, y + 40, CONFIG.items.bossDrop);   // 보스는 회복 구슬을 보장
    Sound.play('bossDeath'); Sound.setTrack('normal');
    this.fx.ring(x, y, 200, [255, 240, 160], 0.8); this.fx.burst(x, y, [255, 240, 160], 40, 300, 0.9, 4);
    this.enemyBullets.length = 0;
    this.bossKills++;
    const wasFinal = this.bossIndex >= this.bossOrder.length - 1;
    this.bossIndex++;
    this.arena = null; this.bossPhase = 'none'; this.bossTimer = B.gap;
    this.notify(wasFinal ? '' : '보스 처치! 회복 구슬을 먹어 체력을 회복하세요');
    if (wasFinal) this.startEnding();
  }

  spawn(dt) {
    const p = this.player, S = CONFIG.spawn;
    const minutes = this.growthTime / 60;
    this.spawnAcc += (S.base + S.perMin * minutes) * dt;
    const dist = Math.hypot(this.W, this.H) / 2 + S.margin;   // 화면 밖에서 생성
    while (this.spawnAcc >= 1) {
      this.spawnAcc -= 1;
      if (this.enemies.length >= S.maxEnemies) continue;
      const a = Math.random() * Math.PI * 2;
      this.enemies.push(new Enemy(p.x + Math.cos(a) * dist, p.y + Math.sin(a) * dist, this.pickType(minutes), minutes));
    }
  }

  /* 이번에 나올 적 종류: 일부는 특수 적, 나머지는 기본 적 */
  pickType(min) {
    const S = CONFIG.specials;
    if (Math.random() >= Math.min(S.maxShare, S.shareBase + S.sharePerMin * min)) return 'basic';
    const pool = S.types.filter((t) => min >= t.unlock);
    let r = Math.random() * pool.reduce((a, t) => a + t.weight, 0);
    for (const t of pool) { r -= t.weight; if (r <= 0) return t.id; }
    return pool[0].id;
  }

  findNearestEnemy(x, y, range) {
    let best = null, bd = range * range;
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = (e.x - x) * (e.x - x) + (e.y - y) * (e.y - y);
      if (d <= bd) { bd = d; best = e; }
    }
    return best;
  }

  /* 모든 피해는 여기를 거칩니다. 방어력은 퍼센트 감소. */
  damageEnemy(e, amount, kind, hx, hy) {
    if (e.dead) return;
    if (e.shield > 0) {                                  // 보호막: 0.2초 안의 연속 타격은 1회로 침
      if (this.time - e.shieldLast >= CONFIG.enemies.shielded.shieldGap) {
        e.shieldLast = this.time; e.shield--;
        this.fx.ring(e.x, e.y, e.radius + 8, [255, 225, 80], 0.25);
      }
      e.flash = 0.05;
      return;
    }
    if (e.behavior && e.behavior.filter) {               // 보스 규칙 (방벽 흡수, 약점 구역, 기절 배율)
      amount = e.behavior.filter(e, this, amount, kind || 'area', hx === undefined ? this.player.x : hx, hy === undefined ? this.player.y : hy);
      if (amount <= 0) { e.flash = 0.04; return; }
    }
    const dmg = amount * (1 - e.defense);
    e.hp -= dmg;
    e.flash = 0.08;
    if (e.dummy) { if (this.bench && !this.bench.done) this.bench.dealt += dmg; this.labLog(dmg); e.hp = e.maxHp; }   // 밸런스 테스트 더미
    Sound.play('hit');
    this.fx.popup(e.x, e.y - e.radius, String(Math.max(1, Math.round(dmg))), [255, 255, 255]);
    if (e.hp <= 0) this.killEnemy(e);
    else if (e.behavior && e.behavior.onHit) e.behavior.onHit(e, this);
  }

  killEnemy(e) {
    e.dead = true;
    this.player.kills++;
    Sound.play('kill');
    this.maybeDropItem(e);
    this.fx.burst(e.x, e.y, e.color, 7, 110, 0.45, 3);
    const d = e.drop;
    if (d) this.gems.push(new Gem(e.x, e.y, d.tier));                  // 구슬은 확정 드롭
    if (d && d.bonusTier && Math.random() < d.bonusChance) this.gems.push(new Gem(e.x + U.rand(-8, 8), e.y + U.rand(-8, 8), d.bonusTier));
    if (e.behavior && e.behavior.onDeath) e.behavior.onDeath(e, this);
  }

  endProj(b) {
    if (b.dead) return;
    b.dead = true;
    if (b.onEnd) b.onEnd(this, b);
  }

  updateProjectiles(dt) {
    for (const b of this.projectiles) {
      if (b.dead) continue;
      if (b.dust && this.guide) this.guideProjectile(b, dt);
      if (b.onTick) b.onTick(this, b, dt);
      b.x += b.vx * dt; b.y += b.vy * dt;
      b.traveled += b.speed * dt;
      if (b.traveled >= b.range) { this.endProj(b); continue; }
      const near = this.enemyHash.query(b.x, b.y, b.radius + 24, this.tmp);
      for (const e of near) {
        if (e.dead || b.hit.has(e)) continue;
        if (Math.hypot(e.x - b.x, e.y - b.y) <= b.radius + e.radius) {
          this.damageEnemy(e, b.damage, 'proj', b.x, b.y);
          b.hit.add(e);
          this.fx.burst(b.x, b.y, b.color, 3, 70, 0.25, 2);
          if (b.onHit && b.onHit(this, b, e) === 'keep') break;      // 튕김: 방향이 바뀌었으니 다음 프레임에
          if (b.pierce > 0) b.pierce--; else { this.endProj(b); break; }
        }
      }
    }
  }

  updateEnemyBullets(dt) {
    const p = this.player;
    for (const b of this.enemyBullets) {
      const s = b.speed * dt;
      if (b.vortex) {                                  // 블랙홀 보스를 향해 돌면서 점점 빨라지며 빨려 들어가는 탄
        const t = this.enemies.find((q) => q.type === 'bossHole' && !q.dead), v = b.vortex;
        if (!t) { b.dead = true; continue; }
        v.r -= b.speed * 0.6 * dt;
        v.th += v.dir * (b.speed / Math.max(v.r, 70)) * dt;
        if (v.r < t.radius * 0.8) { b.dead = true; continue; }
        const nx = t.x + Math.cos(v.th) * v.r, ny = t.y + Math.sin(v.th) * v.r;
        b.vx = (nx - b.x) / dt; b.vy = (ny - b.y) / dt; b.traveled = 0;
      }
      b.x += b.vx * dt; b.y += b.vy * dt; b.traveled += s;
      if (b.traveled >= b.range || (b.life !== undefined && (b.life -= dt) <= 0)) { b.dead = true; continue; }
      const A = this.arena;
      if (A && !b.vortex && (b.x < A.x0 - 80 || b.x > A.x1 + 80 || b.y < A.y0 - 80 || b.y > A.y1 + 80)) { b.dead = true; continue; }
      if (p.invuln <= 0 && Math.hypot(b.x - p.x, b.y - p.y) <= b.radius + p.radius) {
        b.dead = true;
        if (p.takeDamage(b.damage)) this.hurtFx();
      }
    }
  }

  hurtFx() {
    const p = this.player;
    this.shake = 7; this.hitFlash = 0.3;
    Sound.play('hurt');
    this.fx.burst(p.x, p.y, [255, 90, 90], 10, 140, 0.4, 3);
  }

  contactDamage() {
    const p = this.player;
    if (p.invuln > 0) return;
    const near = this.enemyHash.query(p.x, p.y, p.radius + 24, this.tmp);
    for (const e of near) {
      if (e.dead) continue;
      if (Math.hypot(e.x - p.x, e.y - p.y) <= p.radius + e.radius) {
        if (p.takeDamage(e.contactNow)) this.hurtFx();
        break;
      }
    }
  }

  updateGems(dt) {
    const p = this.player, M = CONFIG.xp.magnet;
    for (const g of this.gems) {
      const dx = p.x - g.x, dy = p.y - g.y;
      const d = Math.hypot(dx, dy) || 0.001;
      if (!g.attracted && d <= p.magnetRange) g.attracted = true;
      if (g.attracted) {
        g.speed += M.accel * dt;                       // 가속하며 빨려 들어옴
        const step = Math.min(g.speed * dt, d);
        g.x += (dx / d) * step; g.y += (dy / d) * step;
      }
      if (d <= M.pickupRadius) { g.dead = true; p.xp += g.value; Sound.play('gem'); }
    }
    this.mergeTimer -= dt;
    if (this.gems.length > CONFIG.xp.maxGems && this.mergeTimer <= 0) {
      this.mergeGems(); this.mergeTimer = 0.25;
    }
  }

  /* 구슬이 너무 많으면 가까운 것끼리 합쳐 한 단계 큰 구슬로 (경험치 총량은 유지) */
  mergeGems() {
    const made = [];
    const pass = (tier, count, next) => {
      const groups = new Map();
      for (const g of this.gems) {
        if (g.dead || g.attracted || g.tier !== tier) continue;
        const key = Math.floor(g.x / 80) * 100003 + Math.floor(g.y / 80);
        let a = groups.get(key); if (!a) { a = []; groups.set(key, a); }
        a.push(g);
      }
      for (const arr of groups.values()) {
        while (arr.length >= count) {
          const part = arr.splice(0, count);
          let cx = 0, cy = 0;
          for (const g of part) { cx += g.x; cy += g.y; g.dead = true; }
          made.push(new Gem(cx / count, cy / count, next));
        }
      }
    };
    pass('small', 5, 'medium');
    pass('medium', 4, 'large');
    for (const g of made) this.gems.push(g);
  }

  /* ---------------- 레벨업 ---------------- */
  checkLevelUp() {
    const p = this.player;
    while (p.xp >= p.xpNeeded) { p.xp -= p.xpNeeded; p.level++; this.pendingLevelUps++; }
    if (this.pendingLevelUps > 0 && this.state === 'play') this.openLevelUp();
  }

  /* 지금 고를 수 있는 진화: 대상 무기와 짝 무기가 모두 5레벨(또는 진화 완료)이어야 함 */
  availableEvolutions() {
    const p = this.player, out = [];
    for (const w of p.weapons) {
      if (w.evo || !w.isLv5) continue;
      for (const evo of CONFIG.evolutions) {
        if (evo.target !== w.id) continue;
        const partner = p.getWeapon(evo.partner);
        if (partner && partner.isLv5) out.push(evo);
      }
    }
    return out;
  }

  buildCards() {
    const p = this.player, pool = [];
    for (const w of p.weapons) if (!w.maxed) pool.push({ type: 'upgrade', id: w.id, weight: 1 });
    if (p.weapons.length < CONFIG.maxWeaponSlots) {
      for (const id of CONFIG.weaponOrder) if (!p.getWeapon(id)) pool.push({ type: 'acquire', id, weight: 1 });
    }
    for (const evo of this.availableEvolutions()) pool.push({ type: 'evolve', evo, weight: CONFIG.evoWeight });
    const cards = [];
    while (cards.length < 3 && pool.length) {            // 가중치 추첨 (진화 카드가 더 잘 나옴)
      let r = Math.random() * pool.reduce((a, c) => a + c.weight, 0), i = 0;
      for (; i < pool.length - 1; i++) { r -= pool[i].weight; if (r <= 0) break; }
      cards.push(pool.splice(i, 1)[0]);
    }
    while (cards.length < 3) cards.push({ type: 'recover' });   // 카드가 모자라면 회복 카드
    return cards;
  }

  statText(cfg, key, v) {
    if (key === 'cooldown') return v.toFixed(2) + '초';
    if (key === 'radius') return v + 'px';
    if (key === 'speed') return v + 'px/s';
    if (key === 'orbitSpeed') return v + '°/s';
    if (key === 'duration') return v.toFixed(1) + '초';
    return String(v);
  }

  describeCard(c) {
    if (c.type === 'recover') {
      return { title: '체력 회복', tag: '회복', color: [120, 230, 150],
        desc: '최대 체력의 ' + Math.round(CONFIG.xp.recoverCardRate * 100) + '%를 회복합니다.', lines: [] };
    }
    if (c.type === 'evolve') {
      const evo = c.evo, t = CONFIG.weapons[evo.target], q = CONFIG.weapons[evo.partner];
      return { title: evo.name, tag: '★ 진화 · ' + t.name + ' + ' + q.name, color: [255, 214, 90], evo: true, desc: evo.desc,
        lines: [t.name + ' Lv 5 → 진화', q.name + ' Lv 5 보유 중'] };
    }
    const cfg = CONFIG.weapons[c.id];
    if (c.type === 'acquire') {
      const lv = cfg.levels[0];
      return { title: cfg.name, tag: '새 무기', color: cfg.color, desc: cfg.desc,
        lines: Object.keys(cfg.labels).map((k) => cfg.labels[k] + ' ' + this.statText(cfg, k, lv[k])) };
    }
    const w = this.player.getWeapon(c.id);
    const a = cfg.levels[w.level - 1], b = cfg.levels[w.level];
    const lines = Object.keys(cfg.labels).filter((k) => a[k] !== b[k]).map((k) =>
      cfg.labels[k] + ' ' + this.statText(cfg, k, a[k]) + ' → ' + this.statText(cfg, k, b[k]));
    if (w.level + 1 === cfg.levels.length && cfg.lv5) lines.push('★ MAX 보너스: ' + cfg.lv5.text);
    return { title: cfg.name, tag: 'Lv ' + w.level + ' → ' + (w.level + 1), color: cfg.color, desc: cfg.desc, lines };
  }

  openLevelUp() {
    this.state = 'levelup';
    Sound.play('levelup');
    this.cards = this.buildCards();
    this.renderCards();
    this.showScreen('levelup');
  }

  /* 카드 목록 그리기 + 리롤 버튼 상태 */
  renderCards() {
    const box = document.getElementById('card-list');
    box.innerHTML = '';
    this.cards.forEach((c, i) => {
      const d = this.describeCard(c);
      const el = document.createElement('button');
      el.className = 'card' + (d.evo ? ' evo' : '');
      el.style.setProperty('--c', d.color.join(','));
      el.innerHTML = '<span class="key">' + (i + 1) + '</span><h3>' + d.title + '</h3><div class="tag">' + d.tag +
        '</div><p>' + d.desc + '</p><ul>' + d.lines.map((l) => '<li>' + l + '</li>').join('') + '</ul>';
      el.addEventListener('click', () => this.chooseCard(i));
      box.appendChild(el);
    });
    document.getElementById('levelup-sub').textContent = 'Lv ' + this.player.level + ' 달성  ·  카드 하나를 고르세요 (1·2·3 키)';
    const rb = document.getElementById('btn-reroll');
    rb.textContent = '카드 다시 뽑기 (R) · 남은 ' + this.rerollsLeft + '회';
    rb.disabled = this.rerollsLeft <= 0;
  }

  /* 리롤: 한 판에 CONFIG.rerolls 번, 지금 보이는 카드를 모두 새로 뽑음 */
  reroll() {
    if (this.state !== 'levelup' || this.rerollsLeft <= 0) return;
    this.rerollsLeft--;
    Sound.play('card');
    this.cards = this.buildCards();
    this.renderCards();
  }

  chooseCard(i) {
    if (this.state !== 'levelup') return;
    const c = this.cards[i];
    if (!c) return;
    const p = this.player;
    Sound.play('card');
    if (c.type === 'upgrade') p.getWeapon(c.id).levelUp();
    else if (c.type === 'evolve') {
      p.getWeapon(c.evo.target).evolve(c.evo);
      this.notify('★ ' + c.evo.name + ' 진화!');
      Sound.play('evolve');
    }
    else if (c.type === 'acquire') p.weapons.push(new WEAPON_CLASSES[c.id](this));
    else if (c.type === 'recover') p.heal(p.maxHp * CONFIG.xp.recoverCardRate);
    this.fx.ring(p.x, p.y, 50, [255, 240, 160], 0.5);
    this.pendingLevelUps--;
    if (this.pendingLevelUps > 0) { this.openLevelUp(); return; }
    this.hideScreens();             // 키 입력은 지우지 않음: 이동 키를 누른 채 카드를 골라도 계속 이동
    this.state = 'play';
  }

  /* ---------------- 게임 종료 ---------------- */
  victory() {
    if (this.state === 'clear') return;
    this.state = 'clear';
    const p = this.player, b = this.best;
    Sound.play('clear'); Sound.setTrack(null);
    const record = b.clear === undefined || b.clear === 0 || this.time < b.clear;
    b.time = Math.max(b.time, this.time);
    b.level = Math.max(b.level, p.level);
    b.kills = Math.max(b.kills, p.kills);
    b.clear = record ? this.time : b.clear;
    Store.save(b);
    document.getElementById('clear-stats').innerHTML =
      '<div><b>' + U.fmtTime(this.time) + '</b><span>클리어 시간' + (record ? ' (신기록!)' : '') + '</span></div>' +
      '<div><b>' + p.kills + '</b><span>처치 수</span></div>' +
      '<div><b>Lv ' + p.level + '</b><span>도달 레벨</span></div>' +
      '<div><b>' + this.bossKills + '</b><span>처치한 보스</span></div>';
    this.showScreen('clear');
  }

  gameOver() {
    if (this.state === 'gameover') return;
    this.state = 'gameover';
    const p = this.player, b = this.best;
    Sound.play('gameover'); Sound.setTrack(null);
    const record = this.time > b.time;
    b.time = Math.max(b.time, this.time);
    b.level = Math.max(b.level, p.level);
    b.kills = Math.max(b.kills, p.kills);
    Store.save(b);
    document.getElementById('go-stats').innerHTML =
      '<div><b>' + U.fmtTime(this.time) + '</b><span>생존 시간' + (record ? ' (신기록!)' : '') + '</span></div>' +
      '<div><b>' + p.kills + '</b><span>처치 수</span></div>' +
      '<div><b>Lv ' + p.level + '</b><span>도달 레벨</span></div>' +
      '<div><b>' + this.bossKills + '</b><span>처치한 보스</span></div>';
    document.getElementById('go-best').textContent = '최고 기록  ' + U.fmtTime(b.time) + '  ·  Lv ' + b.level + '  ·  처치 ' + b.kills;
    this.showScreen('gameover');
  }

  /* ---------------- UI(DOM) ---------------- */
  showScreen(id) {
    document.querySelectorAll('.screen').forEach((el) => el.classList.add('hidden'));
    const el = document.getElementById('screen-' + id);
    if (el) el.classList.remove('hidden');
    if (id === 'title') {
      const b = this.best;
      document.getElementById('title-best').textContent =
        b.time > 0 ? '최고 기록  ' + U.fmtTime(b.time) + '  ·  Lv ' + b.level + '  ·  처치 ' + b.kills : '';
    }
  }
  hideScreens() { document.querySelectorAll('.screen').forEach((el) => el.classList.add('hidden')); }

  openSelect() {
    this.state = 'select';
    const box = document.getElementById('passive-list');
    box.innerHTML = '';
    CONFIG.passives.forEach((ps, i) => {
      const wname = ps.id === 'earth' ? '대기 + 랜덤 무기 1개' : CONFIG.weaponNames[ps.weapon];
      const color = ps.id === 'earth' ? [127, 200, 255] : (CONFIG.weapons[ps.weapon] ? CONFIG.weapons[ps.weapon].color : [150, 160, 190]);
      const el = document.createElement('button');
      el.className = 'card' + (ps.enabled ? '' : ' locked');
      el.style.setProperty('--c', color.join(','));
      el.disabled = !ps.enabled;
      el.innerHTML = '<span class="key">' + (i + 1) + '</span><h3>' + ps.name + '</h3><div class="tag">시작 무기 · ' + wname +
        '</div><p>' + ps.desc + '</p>' + (ps.enabled ? '' : '<em>다음 단계에서 열립니다</em>');
      if (ps.enabled) el.addEventListener('click', () => this.startRun(ps));
      box.appendChild(el);
    });
    this.showScreen('select');
  }

  bindUI() {
    const on = (id, fn) => document.getElementById(id).addEventListener('click', fn);
    on('btn-start', () => this.openSelect());
    on('btn-resume', () => this.resume());
    on('btn-quit', () => { this.state = 'title'; this.showScreen('title'); });
    on('btn-retry', () => this.openSelect());
    on('btn-title', () => { this.state = 'title'; this.showScreen('title'); });
    on('btn-clear-retry', () => this.openSelect());
    on('btn-clear-title', () => { this.state = 'title'; this.showScreen('title'); });
    on('btn-back', () => { this.state = 'title'; this.showScreen('title'); });
    on('btn-reroll', () => this.reroll());
    on('btn-pause', () => { if (this.state === 'play') this.pause(); });
    document.querySelectorAll('.vol-bgm').forEach((el) => el.addEventListener('input', () => { Sound.init(); Sound.setVolume('bgm', el.value / 100); this.syncAudioUI(); }));
    document.querySelectorAll('.vol-sfx').forEach((el) => el.addEventListener('input', () => { Sound.init(); Sound.setVolume('sfx', el.value / 100); this.syncAudioUI(); }));
    document.querySelectorAll('.btn-mute').forEach((el) => el.addEventListener('click', () => { Sound.init(); Sound.toggleMute(); this.syncAudioUI(); }));
    this.syncAudioUI();
  }

  syncAudioUI() {
    document.querySelectorAll('.vol-bgm').forEach((el) => { el.value = Math.round(Sound.vol.bgm * 100); });
    document.querySelectorAll('.vol-sfx').forEach((el) => { el.value = Math.round(Sound.vol.sfx * 100); });
    document.querySelectorAll('.btn-mute').forEach((el) => { el.textContent = Sound.muted ? '소리 꺼짐 (M)' : '소리 켜짐 (M)'; });
  }

  onKey(code) {
    const s = this.state;
    if (code === 'KeyM') { Sound.toggleMute(); this.syncAudioUI(); }
    if (this.debug && s === 'play' && this.bench && code !== 'KeyV' && this.benchKey(code)) return;
    if (s === 'title' && (code === 'Enter' || code === 'Space')) this.openSelect();
    else if (s === 'select') {
      const m = /^(?:Digit|Numpad)(\d)$/.exec(code);
      if (m) { const ps = CONFIG.passives[+m[1] - 1]; if (ps && ps.enabled) this.startRun(ps); }
      if (code === 'Escape') { this.state = 'title'; this.showScreen('title'); }
    }
    else if (s === 'play' && (code === 'KeyP' || code === 'Escape')) this.pause();
    else if (s === 'pause' && (code === 'KeyP' || code === 'Escape')) this.resume();
    else if (s === 'levelup') {
      const m = /^(?:Digit|Numpad)(\d)$/.exec(code);
      if (m) this.chooseCard(+m[1] - 1);
      else if (code === 'KeyR') this.reroll();
    }
    else if ((s === 'gameover' || s === 'clear') && (code === 'Enter' || code === 'KeyR')) this.openSelect();

    if (this.debug && this.state === 'play' && this.labKey(code)) return;
    if (this.debug && this.state === 'play') this.debugKey(code);
  }

  /* 개발용 키 (주소 뒤에 ?debug=1 을 붙였을 때만 동작) */
  debugKey(code) {
    const p = this.player;
    if (code === 'KeyV') {                                   // 밸런스 테스트 모드 켜기/끄기
      if (this.bench) { this.bench = null; this.input.override = null; this.state = 'title'; this.showScreen('title'); }
      else this.startBench(0, 'single');
      return;
    }
    if (code === 'KeyL') p.xp += p.xpNeeded;                 // 즉시 레벨업
    if (code === 'KeyK') for (const e of this.enemies) this.damageEnemy(e, 99999);
    if (code === 'KeyH') p.hp = p.maxHp;
    if (code === 'KeyT') this.growthTime += 60;              // 성장 시간 +1분
    if (code === 'KeyG') this.godMode = !this.godMode;       // 무적 토글
    if (code === 'KeyB' && this.bossPhase === 'none') this.bossTimer = 0.01;        // 보스 즉시 소환
    if (code === 'KeyN') for (const e of this.enemies) if (e.boss || e.bossPart) e.hp = Math.min(e.hp, 1);   // 보스 체력 1로
    if (code === 'KeyE') {                                   // 진화 하나씩 돌려 보기
      this.debugEvo = ((this.debugEvo || 0) % CONFIG.evolutions.length) + 1;
      this.debugEvolve(CONFIG.evolutions[this.debugEvo - 1].id);
    }
    if (code === 'KeyY') {                                   // 특수 적 10종을 주변에 소환
      CONFIG.specials.types.forEach((t, i) => {
        const a = (i / 10) * Math.PI * 2;
        this.enemies.push(new Enemy(p.x + Math.cos(a) * 260, p.y + Math.sin(a) * 260, t.id, this.growthTime / 60));
      });
    }
  }

  /* 개발용: 대상·짝 무기를 5레벨로 만들고 진화시킴 (슬롯 제한 무시) */
  debugEvolve(id) {
    const evo = CONFIG.evolutions.find((e) => e.id === id), p = this.player;
    for (const wid of [evo.target, evo.partner]) {
      let w = p.getWeapon(wid);
      if (!w) { w = new WEAPON_CLASSES[wid](this); p.weapons.push(w); }
      while (!w.isLv5) w.levelUp();
    }
    const w = p.getWeapon(evo.target);
    if (w.evo) { w.evo = null; w.refresh(); }
    w.evolve(evo);
    this.notify('★ ' + evo.name + ' 진화!');
    return w;
  }

  /* ---------------- 렌더 ---------------- */
  render() {
    const ctx = this.ctx, W = this.W, H = this.H;
    ctx.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    const playing = this.state === 'play' || this.state === 'levelup' || this.state === 'pause' || this.state === 'gameover' || this.state === 'clear' || this.state === 'ending';
    const p = this.player;

    if (playing && this.arena) { this.cam.x = this.arena.cx - W / 2; this.cam.y = this.arena.cy - H / 2; }   // 보스전은 카메라 고정
    else if (playing) { this.cam.x = p.x - W / 2; this.cam.y = p.y - H / 2; }
    else { this.cam.x += 0.35; this.cam.y += 0.12; }          // 타이틀 배경은 천천히 흐름
    const sh = this.shake * CONFIG.fx.shake;
    if (document.body.dataset.state !== this.state) document.body.dataset.state = this.state;   // 터치 버튼 표시용
    const cam = { x: this.cam.x + (Math.random() - 0.5) * sh, y: this.cam.y + (Math.random() - 0.5) * sh };

    if (this.state === 'ending') { this.bg.cx = p.x - cam.x; this.bg.cy = p.y - cam.y; }
    this.bg.draw(ctx, cam, W, H);
    if (!playing) return;
    if (this.arena) this.drawArena(ctx, cam);

    for (const w of p.weapons) w.drawUnder(ctx, cam);
    this.drawSystemsUnder(ctx, cam);
    this.drawGems(ctx, cam);
    this.drawItems(ctx, cam);
    this.drawEnemies(ctx, cam);
    this.drawProjectiles(ctx, cam);
    for (const w of p.weapons) w.drawOver(ctx, cam);
    this.drawSystemsOver(ctx, cam);
    this.drawPlayer(ctx, cam);
    this.fx.draw(ctx, cam);
    this.drawVignette(ctx);
    if (this.bossPhase === 'intro') {                       // 소환 연출: 화면이 어두워졌다가 밝아짐
      ctx.fillStyle = 'rgba(0,0,0,' + (0.55 * this.bossIntroT / CONFIG.boss.intro) + ')'; ctx.fillRect(0, 0, W, H);
    }
    if (this.state === 'ending') { this.drawEnding(ctx); return; }
    this.drawLab(ctx, cam);
    this.drawBannerFlash(ctx);
    this.drawHUD(ctx);
  }

  drawArena(ctx, cam) {
    const A = this.arena, x0 = A.x0 - cam.x, y0 = A.y0 - cam.y, w = A.w, h = A.h, W = this.W, H = this.H;
    const k = this.bossPhase === 'intro' ? 1 - this.bossIntroT / CONFIG.boss.intro : 1;
    ctx.fillStyle = 'rgba(0,0,0,0.6)';                         // 구역 밖은 어둡게
    ctx.fillRect(0, 0, W, Math.max(0, y0)); ctx.fillRect(0, y0 + h, W, Math.max(0, H - y0 - h));
    ctx.fillRect(0, y0, Math.max(0, x0), h); ctx.fillRect(x0 + w, y0, Math.max(0, W - x0 - w), h);
    ctx.strokeStyle = 'rgba(255,90,90,' + (0.35 + 0.35 * Math.sin(performance.now() / 300)) * k + ')';
    ctx.lineWidth = 4; ctx.strokeRect(x0 + 2, y0 + 2, w - 4, h - 4);
  }

  onScreen(x, y, m, cam) {
    const sx = x - cam.x, sy = y - cam.y;
    return sx > -m && sx < this.W + m && sy > -m && sy < this.H + m;
  }

  drawGems(ctx, cam) {
    const t = performance.now() / 1000;
    for (const g of this.gems) {
      if (!this.onScreen(g.x, g.y, 30, cam)) continue;
      const x = g.x - cam.x, y = g.y - cam.y;
      const pulse = 1 + 0.15 * Math.sin(t * 5 + g.phase);
      const gs = Math.ceil(g.radius * 3 * pulse);
      ctx.drawImage(Glow.get(g.color, 16), x - gs, y - gs, gs * 2, gs * 2);
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(x, y, g.radius * 0.45, 0, Math.PI * 2); ctx.fill();
    }
  }

  drawEnemies(ctx, cam) {
    for (const e of this.enemies) {
      if (e.dead || !this.onScreen(e.x, e.y, e.type === 'charger' ? 460 : 60, cam)) continue;
      const x = e.x - cam.x, y = e.y - cam.y;
      ENEMY_TYPES[e.type].draw(ctx, e, x, y, this);
      if (e.type !== 'basic' && e.type !== 'fragment' && e.hp < e.maxHp) {       // 체력 바
        const w = Math.max(20, e.radius * 2);
        ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(x - w / 2, y - e.radius - 11, w, 4);
        ctx.fillStyle = '#ff6b6b'; ctx.fillRect(x - w / 2, y - e.radius - 11, w * Math.max(0, e.hp / e.maxHp), 4);
      }
    }
    // 각성한 포식이 화면 밖에 있으면 방향 화살표
    for (const e of this.enemies) {
      if (e.dead || !e.awake || this.onScreen(e.x, e.y, 0, cam)) continue;
      const cx = this.W / 2, cy = this.H / 2, a = Math.atan2(e.y - this.player.y, e.x - this.player.x);
      const k = Math.min((cx - 30) / Math.abs(Math.cos(a) || 1e-6), (cy - 30) / Math.abs(Math.sin(a) || 1e-6));
      const ax = cx + Math.cos(a) * k, ay = cy + Math.sin(a) * k;
      ctx.save(); ctx.translate(ax, ay); ctx.rotate(a);
      ctx.fillStyle = 'rgba(255,60,60,' + (0.6 + 0.4 * Math.sin(performance.now() / 120)) + ')';
      ctx.beginPath(); ctx.moveTo(14, 0); ctx.lineTo(-10, -10); ctx.lineTo(-10, 10); ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    // 적 탄
    for (const b of this.enemyBullets) {
      if (!this.onScreen(b.x, b.y, 20, cam)) continue;
      const x = b.x - cam.x, y = b.y - cam.y;
      if (b.tail) { ctx.strokeStyle = 'rgba(190,140,255,0.55)'; ctx.lineWidth = 3; ctx.lineCap = 'round'; ctx.beginPath(); ctx.moveTo(x - b.vx * 0.09, y - b.vy * 0.09); ctx.lineTo(x, y); ctx.stroke(); }
      ctx.drawImage(Glow.get(b.color, 12), x - 12, y - 12, 24, 24);
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, b.radius * 0.6, 0, Math.PI * 2); ctx.fill();
    }
  }

  drawProjectiles(ctx, cam) {
    for (const b of this.projectiles) {
      if (!this.onScreen(b.x, b.y, 40, cam)) continue;
      const x = b.x - cam.x, y = b.y - cam.y;
      if (b.style === 'comet') { this.drawComet(ctx, b, x, y); continue; }
      if (b.style === 'ray') {                                  // 별가루 광선: 가늘고 긴 빛줄기
        ctx.strokeStyle = U.rgba(b.color, 0.45); ctx.lineWidth = 6; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(x - Math.cos(b.angle) * 90, y - Math.sin(b.angle) * 90); ctx.lineTo(x, y); ctx.stroke();
        ctx.strokeStyle = '#fff'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(x - Math.cos(b.angle) * 60, y - Math.sin(b.angle) * 60); ctx.lineTo(x, y); ctx.stroke();
        continue;
      }
      ctx.strokeStyle = U.rgba(b.color, 0.5);
      ctx.lineWidth = b.radius * 1.3;
      ctx.lineCap = 'round';
      ctx.beginPath(); ctx.moveTo(x - b.vx * 0.035, y - b.vy * 0.035); ctx.lineTo(x, y); ctx.stroke();
      ctx.fillStyle = '#fff';
      ctx.beginPath(); ctx.arc(x, y, b.radius * 0.8, 0, Math.PI * 2); ctx.fill();
    }
  }

  drawComet(ctx, b, x, y) {
    const len = 90, tx = x - Math.cos(b.angle) * len, ty = y - Math.sin(b.angle) * len;
    const gr = ctx.createLinearGradient(x, y, tx, ty);
    gr.addColorStop(0, U.rgba(b.color, 0.85)); gr.addColorStop(1, U.rgba(b.color, 0));
    ctx.strokeStyle = gr; ctx.lineWidth = b.radius * 1.6; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(tx, ty); ctx.stroke();
    const s = Math.ceil(b.radius * 2.6);
    ctx.drawImage(Glow.get(b.color, 16), x - s, y - s, s * 2, s * 2);
    ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, b.radius * 0.6, 0, Math.PI * 2); ctx.fill();
  }

  drawPlayer(ctx, cam) {
    const p = this.player;
    const x = p.x - cam.x, y = p.y - cam.y;
    ctx.drawImage(Glow.get([170, 200, 255], 32), x - 32, y - 32, 64, 64);
    const blink = p.invuln > 0 && Math.floor(p.invuln * 20) % 2 === 0;
    ctx.fillStyle = blink ? 'rgba(255,255,255,0.35)' : '#ffffff';
    ctx.beginPath(); ctx.arc(x, y, p.radius, 0, Math.PI * 2); ctx.fill();
  }

  drawVignette(ctx) {
    const p = this.player, W = this.W, H = this.H;
    const low = p.hp / p.maxHp < 0.3 ? 0.12 + 0.08 * Math.sin(performance.now() / 160) : 0;
    const a = Math.max(low, this.hitFlash / 0.3 * 0.4 * CONFIG.fx.hitFlash);
    if (a <= 0.01) return;
    const g = ctx.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.hypot(W, H) / 2);
    g.addColorStop(0, 'rgba(255,40,40,0)');
    g.addColorStop(1, 'rgba(255,40,40,' + a + ')');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
  }

  drawHUD(ctx) {
    const p = this.player, W = this.W, H = this.H;
    ctx.textBaseline = 'middle';

    // 경험치 바 (상단 전체)
    const need = p.xpNeeded;
    ctx.fillStyle = 'rgba(255,255,255,0.12)';
    ctx.fillRect(0, 0, W, 16);
    const xg = ctx.createLinearGradient(0, 0, W, 0);
    xg.addColorStop(0, '#ffe680'); xg.addColorStop(1, '#7fe0ff');
    ctx.fillStyle = xg;
    ctx.fillRect(0, 0, W * U.clamp(p.xp / need, 0, 1), 16);
    ctx.fillStyle = '#fff'; ctx.font = 'bold 11px ' + FONT; ctx.textAlign = 'center';
    ctx.fillText('Lv ' + p.level + '   ' + p.xp + ' / ' + need, W / 2, 8.5);

    // 시간, 처치 수 (우상단)
    ctx.textAlign = 'right';
    ctx.font = 'bold 20px ' + FONT; ctx.fillStyle = '#fff';
    ctx.fillText(U.fmtTime(this.time), W - 14, 38);
    ctx.font = '13px ' + FONT; ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.fillText('처치 ' + p.kills, W - 14, 58);
    if (Sound.muted) ctx.fillText('음소거 (M)', W - 14, 76);
    if (this.magnetT > 0) { ctx.fillStyle = 'rgba(170,110,255,0.9)'; ctx.fillText('중력 구슬 ' + this.magnetT.toFixed(0) + '초', W - 14, 94); }
    if (this.bench) this.drawBench(ctx);
    const st = this.input.stick;                              // 터치 가상 조이스틱
    if (st && this.state === 'play') {
      ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(st.bx, st.by, st.R, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = 'rgba(255,255,255,0.35)';
      ctx.beginPath(); ctx.arc(st.bx + st.x * st.R, st.by + st.y * st.R, 22, 0, Math.PI * 2); ctx.fill();
    }

    // 무기 슬롯 (좌상단)
    ctx.textAlign = 'center';
    const canEvo = new Set(this.availableEvolutions().map((e) => e.target));
    const blink = 0.55 + 0.45 * Math.sin(performance.now() / 180);
    const sz = Math.min(46, Math.floor((W - 24) / CONFIG.maxWeaponSlots) - 5), gap = sz + 5;
    p.weapons.forEach((w, i) => {
      const x = 12 + i * gap, y = 26, s = sz;
      ctx.fillStyle = 'rgba(8,10,24,0.7)';
      ctx.fillRect(x, y, s, s);
      ctx.strokeStyle = w.evo ? 'rgba(255,214,90,1)' : U.rgba(w.cfg.color, 0.9); ctx.lineWidth = w.evo ? 3 : 2;
      ctx.strokeRect(x + 1, y + 1, s - 2, s - 2);
      drawWeaponIcon(ctx, w.id, x + s / 2, y + s * 0.42, s * 0.34, w.cfg.color, performance.now() / 1000);
      ctx.textAlign = 'center';
      ctx.fillStyle = w.evo ? '#ffd65a' : '#fff'; ctx.font = (w.evo ? 'bold ' : '') + Math.round(s * 0.24) + 'px ' + FONT;
      ctx.fillText(w.evo ? 'EVO' : w.maxed ? 'MAX' : 'Lv ' + w.level, x + s / 2, y + s * 0.85);
      if (canEvo.has(w.id)) {                                  // 진화 가능 표시
        ctx.fillStyle = 'rgba(255,214,90,' + blink + ')'; ctx.font = 'bold 14px ' + FONT;
        ctx.fillText('★', x + s - 8, y + 9);
      }
    });
    if (p.passive) {
      ctx.textAlign = 'left'; ctx.font = '12px ' + FONT; ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.fillText('패시브 · ' + p.passive.name, 14, 26 + sz + 16);
    }

    // 체력 바 (하단 중앙)
    const bw = Math.min(340, W * 0.6), bx = (W - bw) / 2, by = H - 34;
    ctx.fillStyle = 'rgba(8,10,24,0.75)'; ctx.fillRect(bx - 2, by - 2, bw + 4, 20);
    const ratio = U.clamp(p.hp / p.maxHp, 0, 1);
    ctx.fillStyle = ratio < 0.3 ? '#ff5a5a' : '#4be08a';
    ctx.fillRect(bx, by, bw * ratio, 16);
    ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.font = 'bold 12px ' + FONT;
    ctx.fillText(Math.max(0, Math.ceil(p.hp)) + ' / ' + p.maxHp, W / 2, by + 8.5);

    // 보스 경고 / 카운트다운 / 체력 바
    if (this.bossPhase === 'none' && this.bossTimer <= CONFIG.boss.warnAt) {
      const sec = Math.ceil(this.bossTimer);
      ctx.textAlign = 'center';
      const pulse = 0.65 + 0.35 * Math.sin(performance.now() / 150);
      ctx.fillStyle = 'rgba(255,90,90,' + pulse + ')'; ctx.font = 'bold 18px ' + FONT;
      ctx.fillText('⚠ 보스 출현까지 ' + sec + '초 — 화면에 갇힙니다', W / 2, H * 0.12);
      if (this.bossTimer <= CONFIG.boss.countdownAt) {
        ctx.font = 'bold 72px ' + FONT; ctx.fillStyle = 'rgba(255,255,255,' + (0.35 + 0.35 * pulse) + ')';
        ctx.fillText(String(sec), W / 2, H * 0.3);
      }
    }
    if (this.bossPhase !== 'none') {
      let sum = 0;
      for (const e of this.enemies) if (e.boss && !e.dead) sum += Math.max(0, e.hp);
      const bw = Math.min(460, W * 0.5), bx = (W - bw) / 2, by = 46;
      ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.font = 'bold 15px ' + FONT;
      ctx.fillText(this.bossName + '  (' + (this.bossIndex + 1) + '/' + this.bossOrder.length + ')', W / 2, 32);
      ctx.fillStyle = 'rgba(8,10,24,0.8)'; ctx.fillRect(bx - 2, by - 2, bw + 4, 16);
      ctx.fillStyle = '#ff5a8a'; ctx.fillRect(bx, by, bw * U.clamp(sum / this.bossTotal, 0, 1), 12);
    }

    if (this.notice.t > 0) {
      ctx.globalAlpha = Math.min(1, this.notice.t);
      ctx.textAlign = 'center'; ctx.font = 'bold 18px ' + FONT; ctx.fillStyle = '#ffe680';
      ctx.fillText(this.notice.text, W / 2, H * 0.22);
      ctx.globalAlpha = 1;
    }

    if (this.debug) {
      ctx.textAlign = 'left'; ctx.font = '12px monospace'; ctx.fillStyle = '#9f9';
      ctx.fillText('FPS ' + this.fps.toFixed(0) + '  적 ' + this.enemies.length + '  구슬 ' + this.gems.length +
        '  투사체 ' + this.projectiles.length + (this.godMode ? '  [무적]' : ''), 14, 104);
      ctx.fillText('L 레벨업  K 적 처치  H 회복  T +1분  G 무적  Y 특수적  B 보스  N 보스 체력 1', 14, 120);
    }
  }
}

/* 배열에서 dead 인 항목을 제자리에서 제거 (새 배열을 만들지 않음) */
function compact(arr) {
  let j = 0;
  for (let i = 0; i < arr.length; i++) if (!arr[i].dead) arr[j++] = arr[i];
  arr.length = j;
}

Object.assign(Game.prototype, Systems, ItemSystem, Bench, Polish, TestLab);   // systems.js 의 공용 시스템 합치기

window.addEventListener('DOMContentLoaded', () => { window.__game = new Game(); });
