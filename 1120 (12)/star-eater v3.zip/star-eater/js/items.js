'use strict';
/* items.js - 특수 아이템: 별의 폭발, 중력 구슬, 회복 구슬
   적이 가끔 떨어뜨리고(화면에 동시에 maxOnField 개, 드롭 사이 minGap 초 간격 제한),
   플레이어가 가까이 가서 먹어야 발동합니다. 수치는 CONFIG.items. */
class Item {
  constructor(x, y, type) {
    this.x = x; this.y = y; this.type = type;
    this.cfg = CONFIG.items.types[type];
    this.color = this.cfg.color;
    this.life = CONFIG.items.life;
    this.radius = 10;
    this.dead = false;
    this.phase = Math.random() * 6.28;
  }
}

const ItemSystem = {
  initItems() { this.items = []; this.lastItemDrop = -99; this.magnetT = 0; },

  /* 적이 죽을 때 확률로 드롭 (보스는 따로 확정 드롭) */
  maybeDropItem(e) {
    const I = CONFIG.items;
    if (this.bench || e.boss || e.dummy) return;
    if (this.items.length >= I.maxOnField || this.time - this.lastItemDrop < I.minGap) return;
    const special = e.type !== 'basic' && e.type !== 'fragment';
    const mul = special ? I.specialMul : 1;
    for (const id of Object.keys(I.types)) {
      if (Math.random() < I.types[id].chance * mul) { this.dropItem(e.x, e.y, id); break; }
    }
  },
  dropItem(x, y, id) {
    this.items.push(new Item(x, y, id));
    this.lastItemDrop = this.time;
    this.fx.ring(x, y, 30, CONFIG.items.types[id].color, 0.5);
  },

  updateItems(dt) {
    const p = this.player, I = CONFIG.items;
    for (const it of this.items) {
      it.life -= dt;
      if (it.life <= 0) { it.dead = true; continue; }
      const dx = p.x - it.x, dy = p.y - it.y, d = Math.hypot(dx, dy) || 0.001;
      if (d < I.attractRange) {                          // 가까이 오면 천천히 끌려옴
        const st = Math.min(170 * dt, d);
        it.x += dx / d * st; it.y += dy / d * st;
      }
      if (d <= I.pickupRadius + p.radius) { it.dead = true; this.applyItem(it); }
    }
    this.items = this.items.filter((it) => !it.dead);
    if (this.magnetT > 0) this.magnetT -= dt;
    p.magnetRange = CONFIG.player.magnetRange * (this.magnetT > 0 ? CONFIG.items.types.gravityOrb.magnetMul : 1);
  },

  applyItem(it) {
    const p = this.player, c = it.cfg;
    Sound.play('item');
    this.fx.ring(p.x, p.y, 70, it.color, 0.5);
    this.fx.burst(p.x, p.y, it.color, 16, 200, 0.6, 3);
    if (it.type === 'healOrb') {
      p.heal(p.maxHp * c.heal);
    } else if (it.type === 'gravityOrb') {
      for (const g of this.gems) { g.attracted = true; g.speed = Math.max(g.speed, 300); }
      this.magnetT = c.time;
    } else if (it.type === 'starBurst') {
      const hw = this.W / 2 + 40, hh = this.H / 2 + 40;
      for (const e of this.enemies) {
        if (e.dead || Math.abs(e.x - p.x) > hw || Math.abs(e.y - p.y) > hh) continue;
        this.damageEnemy(e, c.damage, 'area', p.x, p.y);
      }
      this.fx.ring(p.x, p.y, Math.max(this.W, this.H) / 2, it.color, 0.7);
      this.shake = Math.max(this.shake, 10);
      Sound.play('burst');
    }
    this.notify(c.name + '! ' + c.desc);
  },

  drawItems(ctx, cam) {
    const t = performance.now() / 1000;
    for (const it of this.items) {
      if (!this.onScreen(it.x, it.y, 40, cam)) continue;
      if (it.life < 5 && Math.floor(it.life * 6) % 2 === 0) continue;       // 사라지기 직전 깜빡임
      const x = it.x - cam.x, y = it.y - cam.y, c = it.color, pulse = 1 + 0.15 * Math.sin(t * 5 + it.phase);
      ctx.drawImage(Glow.get(c, 26), x - 26 * pulse, y - 26 * pulse, 52 * pulse, 52 * pulse);
      ctx.fillStyle = '#fff'; ctx.strokeStyle = U.rgba(c, 1); ctx.lineWidth = 2;
      if (it.type === 'healOrb') {                                           // 십자
        ctx.fillStyle = U.rgba(c, 1);
        ctx.fillRect(x - 3, y - 9, 6, 18); ctx.fillRect(x - 9, y - 3, 18, 6);
      } else if (it.type === 'starBurst') {                                  // 8각 별
        ctx.beginPath();
        for (let i = 0; i < 16; i++) {
          const a = i * Math.PI / 8 + t, r = i % 2 ? 5 : 11;
          ctx.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
        }
        ctx.closePath(); ctx.fillStyle = U.rgba(c, 1); ctx.fill();
      } else {                                                               // 중력 구슬: 고리 + 점
        ctx.beginPath(); ctx.arc(x, y, 10, 0, Math.PI * 2); ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2); ctx.fill();
      }
    }
  },
};
