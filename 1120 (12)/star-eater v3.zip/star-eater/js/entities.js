'use strict';
/* entities.js - 플레이어, 적, 경험치 구슬, 투사체 */

class Player {
  constructor() {
    const c = CONFIG.player;
    this.x = 0; this.y = 0; this.vx = 0; this.vy = 0;
    this.radius = c.radius;
    this.maxHp = c.maxHp; this.hp = this.maxHp;
    this.speed = c.speed;
    this.invuln = 0;
    this.magnetRange = c.magnetRange;
    this.level = 1; this.xp = 0; this.kills = 0;
    this.weapons = [];
    this.passive = null;
  }
  get xpNeeded() { return CONFIG.xp.need(this.level); }

  update(dt, move) {
    const k = 1 - Math.exp(-CONFIG.player.smooth * dt);   // 지수 보간으로 부드러운 가감속
    this.vx += (move.x * this.speed - this.vx) * k;
    this.vy += (move.y * this.speed - this.vy) * k;
    this.x += this.vx * dt;
    this.y += this.vy * dt;
    if (this.invuln > 0) this.invuln = Math.max(0, this.invuln - dt);
  }
  /* 피해를 받았으면 true */
  takeDamage(n) {
    if (this.invuln > 0) return false;
    const atm = this.getWeapon('atmosphere');
    if (atm && atm.tryBlock()) return false;       // 보호막이 막음
    this.hp -= n;
    this.invuln = CONFIG.player.invuln;
    return true;
  }
  heal(n) { this.hp = Math.min(this.maxHp, this.hp + n); }
  getWeapon(id) { return this.weapons.find((w) => w.id === id); }
}

class Enemy {
  /* growthMin: 성장 시간(분). 스폰 시점의 스탯으로 고정됩니다. */
  constructor(x, y, type, growthMin) {
    const base = CONFIG.enemies[type], g = CONFIG.growth;
    this.type = type; this.base = base; this.gm = growthMin;
    this.x = x; this.y = y;
    this.radius = base.radius; this.radius0 = base.radius;
    const eh = CONFIG.earlyHp;
    const early = eh.start + (1 - eh.start) * Math.min(1, growthMin / eh.minutes);   // 초반 체력 완화
    this.maxHp = base.hp * (1 + g.hp * growthMin) * early;
    this.hp = this.maxHp;
    this.defense = Math.min(0.85, base.defense + Math.min(g.defenseMax, g.defense * growthMin));   // 시간이 지날수록 방어력 증가
    this.speed = base.speed * (1 + g.speed * growthMin);
    this.contact = base.contact * (1 + g.contact * growthMin);
    this.contact0 = this.contact;
    this.color = base.color;
    this.drop = base.drop;
    this.flash = 0;
    this.dead = false;
    this.ang = 0;                 // 바라보는 방향 (그리기용)
    this.speedMul = 1;
    this.immovable = !!base.immovable;   // 밀기/끌기 면역
    this.ccImmune = false;
    this.shield = 0; this.shieldLast = -9;
    this.state = ''; this.t = 0;
    this.stun = 0; this.kn = null; this.burn = null; this.mark = 0; this.tow = null; this.knCd = 0; this.stunCd = 0;   // 진화 무기 상태 이상
    this.behavior = ENEMY_TYPES[type] || null;
    if (this.behavior && this.behavior.init) this.behavior.init(this, base, growthMin);
  }
  get contactNow() { return this.contact * (this.dashing ? this.base.dashContactMul : 1); }
  /* 플레이어를 향해 이동 */
  chase(dt, player, mul) {
    const dx = player.x - this.x, dy = player.y - this.y;
    const d = Math.hypot(dx, dy) || 1;
    const s = this.speed * this.speedMul * (mul || 1) * dt;
    this.x += (dx / d) * s; this.y += (dy / d) * s;
    this.ang = Math.atan2(dy, dx);
  }
  update(dt, player, game) {
    if (this.flash > 0) this.flash -= dt;
    const b = this.behavior;
    if (b && b.update && b.update(this, dt, game)) return;   // true 면 스스로 이동을 처리함
    this.chase(dt, player);
  }
}

/* 적이 쏘는 탄 */
class EnemyBullet {
  constructor(x, y, angle, speed, damage, range) {
    this.x = x; this.y = y;
    this.vx = Math.cos(angle) * speed; this.vy = Math.sin(angle) * speed;
    this.speed = speed; this.damage = damage; this.range = range; this.traveled = 0;
    this.radius = CONFIG.enemyBullet.radius; this.color = CONFIG.enemyBullet.color;
    this.dead = false;
  }
}

class Gem {
  constructor(x, y, tier) {
    const t = CONFIG.xp.gems[tier];
    this.x = x; this.y = y;
    this.tier = tier; this.value = t.value; this.radius = t.radius; this.color = t.color;
    this.attracted = false;
    this.speed = CONFIG.xp.magnet.startSpeed;
    this.dead = false;
    this.phase = Math.random() * 6.28;
  }
}

/* 플레이어 투사체 (우주 먼지 등) */
class Projectile {
  constructor(x, y, angle, speed, damage, radius, range, pierce, color) {
    this.x = x; this.y = y;
    this.vx = Math.cos(angle) * speed; this.vy = Math.sin(angle) * speed;
    this.angle = angle;
    this.speed = speed; this.damage = damage; this.radius = radius;
    this.range = range; this.traveled = 0;
    this.pierce = pierce;            // 0이면 첫 적을 맞히고 사라짐 (Infinity면 무한 관통)
    this.style = 'dust';             // 그리기 모양: dust | ray | comet
    this.dust = false;               // 우주 먼지 계열 탄 (유도 대상)
    this.onHit = null; this.onTick = null; this.onEnd = null;   // 진화 효과 훅
    this.color = color;
    this.hit = new Set();            // 같은 적을 두 번 때리지 않도록 기록
    this.dead = false;
  }
}
