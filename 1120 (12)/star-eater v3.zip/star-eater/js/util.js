'use strict';
/* util.js - 공용 함수와 공간 해시(충돌 최적화) */
const U = {
  clamp: (v, a, b) => Math.max(a, Math.min(b, v)),
  rand: (a, b) => a + Math.random() * (b - a),
  randInt: (a, b) => Math.floor(a + Math.random() * (b - a + 1)),
  pick: (arr) => arr[Math.floor(Math.random() * arr.length)],
  shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  },
  fmtTime(sec) {
    sec = Math.floor(sec);
    const m = Math.floor(sec / 60), s = sec % 60;
    return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  },
  rgba: (c, a) => 'rgba(' + c[0] + ',' + c[1] + ',' + c[2] + ',' + a + ')',
};

/* 공간 해시: "이 위치 반경 안의 개체 목록"을 빠르게 구합니다. (원형 충돌체용) */
class SpatialHash {
  constructor(cell) { this.cell = cell; this.map = new Map(); this.bigs = []; }
  clear() { this.map.clear(); this.bigs.length = 0; }
  _key(cx, cy) { return cx * 100003 + cy; }
  insert(o) {
    if (o.radius > 30) { this.bigs.push(o); return; }   // 보스처럼 큰 개체는 따로 보관
    const k = this._key(Math.floor(o.x / this.cell), Math.floor(o.y / this.cell));
    let a = this.map.get(k);
    if (!a) { a = []; this.map.set(k, a); }
    a.push(o);
  }
  query(x, y, r, out) {
    out.length = 0;
    const c = this.cell;
    const x0 = Math.floor((x - r) / c), x1 = Math.floor((x + r) / c);
    const y0 = Math.floor((y - r) / c), y1 = Math.floor((y + r) / c);
    for (let cx = x0; cx <= x1; cx++) {
      for (let cy = y0; cy <= y1; cy++) {
        const a = this.map.get(this._key(cx, cy));
        if (a) for (let i = 0; i < a.length; i++) out.push(a[i]);
      }
    }
    for (let i = 0; i < this.bigs.length; i++) {
      const o = this.bigs[i];
      if (Math.hypot(o.x - x, o.y - y) <= r + o.radius) out.push(o);
    }
    return out;
  }
}

/* 최고 기록 저장 (저장소를 못 쓰는 환경에서도 게임은 정상 동작) */
const Store = {
  KEY: 'starEater.best',
  load() {
    try {
      const v = JSON.parse(localStorage.getItem(this.KEY));
      if (v && typeof v === 'object') return { time: v.time || 0, level: v.level || 0, kills: v.kills || 0, clear: v.clear || 0 };
    } catch (e) { /* ignore */ }
    return { time: 0, level: 0, kills: 0, clear: 0 };
  },
  save(best) {
    try { localStorage.setItem(this.KEY, JSON.stringify(best)); } catch (e) { /* ignore */ }
  },
};
