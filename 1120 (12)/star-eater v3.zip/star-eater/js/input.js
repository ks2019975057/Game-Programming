'use strict';
/* input.js - 키보드 입력. WASD / 방향키로 이동합니다. */
class Input {
  constructor() {
    this.keys = new Set();
    this.override = null;       // 테스트용: {x, y}를 넣으면 키 입력 대신 사용
    this.onPress = null;        // (code) => void : 키가 눌린 순간 호출
    this.stick = null;          // 터치 가상 조이스틱 { id, bx, by, x, y }
    this.canStick = () => true; // 조이스틱을 시작해도 되는 상태인지 (game 이 지정)
    window.addEventListener('keydown', (e) => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
      if (!this.keys.has(e.code) && this.onPress) this.onPress(e.code);
      this.keys.add(e.code);
    });
    window.addEventListener('keyup', (e) => this.keys.delete(e.code));
    window.addEventListener('blur', () => this.keys.clear());
  }
  clear() { this.keys.clear(); this.stick = null; }
  /* 터치: 화면을 누른 자리에 조이스틱이 생기고, 드래그한 방향으로 이동합니다. */
  attachTouch(el) {
    const R = 55;                                   // 조이스틱 최대 반경(px)
    el.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' || this.stick || !this.canStick()) return;
      this.stick = { id: e.pointerId, bx: e.clientX, by: e.clientY, x: 0, y: 0, R };
      try { el.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    });
    el.addEventListener('pointermove', (e) => {
      const s = this.stick;
      if (!s || s.id !== e.pointerId) return;
      let dx = e.clientX - s.bx, dy = e.clientY - s.by;
      const d = Math.hypot(dx, dy);
      if (d > R) { dx = dx / d * R; dy = dy / d * R; }
      s.x = dx / R; s.y = dy / R;
      s.kx = s.bx + dx; s.ky = s.by + dy;
    });
    const end = (e) => { if (this.stick && this.stick.id === e.pointerId) this.stick = null; };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
  }
  /* 이동 방향. 대각선도 길이가 1이 되도록 보정합니다. */
  getMove() {
    if (this.override) return this.override;
    if (this.stick && Math.hypot(this.stick.x, this.stick.y) > 0.12) return { x: this.stick.x, y: this.stick.y };
    const k = this.keys;
    let x = 0, y = 0;
    if (k.has('KeyA') || k.has('ArrowLeft')) x -= 1;
    if (k.has('KeyD') || k.has('ArrowRight')) x += 1;
    if (k.has('KeyW') || k.has('ArrowUp')) y -= 1;
    if (k.has('KeyS') || k.has('ArrowDown')) y += 1;
    if (x !== 0 && y !== 0) { x *= Math.SQRT1_2; y *= Math.SQRT1_2; }
    return { x, y };
  }
}
