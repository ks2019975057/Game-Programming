'use strict';
/* enemies.js - 특수 적 10종의 동작과 그리기.
   init(e)        생성 직후
   update(e,dt,g) true 를 돌려주면 이동까지 직접 처리한 것 (아니면 기본 추적)
   onHit(e,g)     피해를 입었을 때 (죽지 않은 경우)
   onDeath(e,g)   죽었을 때
   draw(ctx,e,x,y,g) 그리기 (없으면 원) */

const ENEMY_TYPES = {};
const TAU = Math.PI * 2;

function bodyColor(e) { return e.flash > 0 ? '#ffffff' : U.rgba(e.color, 1); }
function outline(ctx) { ctx.strokeStyle = 'rgba(0,0,0,0.5)'; ctx.lineWidth = 2; ctx.stroke(); }
function circle(ctx, e, x, y) {
  ctx.fillStyle = bodyColor(e); ctx.beginPath(); ctx.arc(x, y, e.radius, 0, TAU); ctx.fill(); outline(ctx);
}
function shootAt(g, x, y, ang, cfg, gm) {
  const dmg = cfg.bulletDamage * (1 + CONFIG.growth.contact * gm);
  g.enemyBullets.push(new EnemyBullet(x, y, ang, cfg.bulletSpeed, dmg, cfg.bulletRange));
}

/* ---- 기본 적 ---- */
ENEMY_TYPES.basic = { draw: circle };

/* ---- 1. 스피드: 맞으면 3초간 2배 속도, 화살표 ---- */
ENEMY_TYPES.speedy = {
  init(e) { e.boost = 0; },
  update(e, dt) { e.boost = Math.max(0, e.boost - dt); e.speedMul = e.boost > 0 ? e.base.boostMul : 1; return false; },
  onHit(e) { e.boost = e.base.boostTime; },
  draw(ctx, e, x, y) {
    const r = e.radius;
    ctx.save(); ctx.translate(x, y); ctx.rotate(e.ang);
    if (e.boost > 0) { ctx.fillStyle = 'rgba(255,200,120,0.35)'; ctx.beginPath(); ctx.moveTo(-r * 3, 0); ctx.lineTo(-r * 0.5, -r * 0.8); ctx.lineTo(-r * 0.5, r * 0.8); ctx.fill(); }
    ctx.fillStyle = bodyColor(e);
    ctx.beginPath(); ctx.moveTo(r * 1.5, 0); ctx.lineTo(-r, -r * 0.95); ctx.lineTo(-r * 0.4, 0); ctx.lineTo(-r, r * 0.95); ctx.closePath();
    ctx.fill(); outline(ctx); ctx.restore();
  },
};

/* ---- 2. 보호막: 피해를 n회 무조건 막음 ---- */
ENEMY_TYPES.shielded = {
  init(e, base, gm) { e.shield = Math.min(base.shieldMax, base.shieldBase + Math.floor(gm * base.shieldPerMin)); },
  draw(ctx, e, x, y) {
    circle(ctx, e, x, y);
    if (e.shield > 0) {
      ctx.fillStyle = 'rgba(255,225,80,0.16)'; ctx.beginPath(); ctx.arc(x, y, e.radius + 5, 0, TAU); ctx.fill();
      ctx.strokeStyle = 'rgba(255,225,80,0.95)'; ctx.lineWidth = 2.5; ctx.stroke();
      for (let i = 0; i < e.shield; i++) {                       // 남은 횟수 점
        const a = -Math.PI / 2 + (i - (e.shield - 1) / 2) * 0.5;
        ctx.fillStyle = '#ffe650'; ctx.beginPath(); ctx.arc(x + Math.cos(a) * (e.radius + 11), y + Math.sin(a) * (e.radius + 11), 2.2, 0, TAU); ctx.fill();
      }
    }
  },
};

/* ---- 3. 탱커: 체력 높고 느림, 방어력은 시간에 따라 증가 ---- */
ENEMY_TYPES.tanker = {
  init(e, base, gm) { e.defense = Math.min(base.defenseMax, base.defense + base.defensePerMin * gm); },
  draw(ctx, e, x, y) {
    circle(ctx, e, x, y);
    ctx.strokeStyle = 'rgba(200,215,255,0.5)'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(x, y, e.radius - 4, 0, TAU); ctx.stroke();
  },
};

/* ---- 4. 분열: 죽으면 조각으로 쪼개짐 ---- */
ENEMY_TYPES.splitter = {
  onDeath(e, g) {
    const b = e.base, n = e.gm >= b.lateMin ? b.splitCountLate : b.splitCount;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * TAU + Math.random(), f = new Enemy(e.x + Math.cos(a) * 8, e.y + Math.sin(a) * 8, 'fragment', e.gm);
      g.enemies.push(f);
    }
  },
  draw(ctx, e, x, y) {
    circle(ctx, e, x, y);
    ctx.strokeStyle = 'rgba(255,255,255,0.75)'; ctx.lineWidth = 1.5; ctx.beginPath();   // 금
    const r = e.radius;
    ctx.moveTo(x - r * 0.2, y - r); ctx.lineTo(x + r * 0.15, y - r * 0.3); ctx.lineTo(x - r * 0.25, y + r * 0.1); ctx.lineTo(x + r * 0.2, y + r);
    ctx.moveTo(x + r * 0.15, y - r * 0.3); ctx.lineTo(x + r, y - r * 0.1);
    ctx.stroke();
  },
};
ENEMY_TYPES.fragment = { draw: circle };

/* ---- 5. 반격: 죽으면 틈이 있는 전방향 탄 ---- */
ENEMY_TYPES.counter = {
  onDeath(e, g) {
    const b = e.base, step = TAU / b.dirs, a0 = Math.random() * TAU, gap = Math.floor(Math.random() * b.dirs);
    for (let i = 0; i < b.dirs; i++) {
      let skip = false;
      for (let k = 0; k < b.gapDirs; k++) if (i === (gap + k) % b.dirs) skip = true;
      if (!skip) shootAt(g, e.x, e.y, a0 + i * step, b, e.gm);
    }
  },
  draw(ctx, e, x, y) {
    const r = e.radius, n = 10;
    ctx.fillStyle = bodyColor(e); ctx.beginPath();
    for (let i = 0; i < n * 2; i++) {
      const a = (i / (n * 2)) * TAU + e.ang * 0, rr = i % 2 ? r * 0.75 : r * 1.45;
      const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    ctx.closePath(); ctx.fill(); outline(ctx);
  },
};

/* ---- 6. 돌진: 접근 → 경고선 → 돌진 → 휴식 ---- */
ENEMY_TYPES.charger = {
  init(e) { e.state = 'approach'; e.dashAng = 0; e.dashing = false; },
  update(e, dt, g) {
    const b = e.base, p = g.player;
    if (e.state === 'approach') {
      const d = Math.hypot(p.x - e.x, p.y - e.y);
      if (d <= b.stopDist) { e.state = 'warn'; e.t = b.warn; e.dashAng = Math.atan2(p.y - e.y, p.x - e.x); e.ang = e.dashAng; }
      else e.chase(dt, p);
    } else if (e.state === 'warn') {
      e.t -= dt;
      if (e.t <= 0) { e.state = 'dash'; e.dashLeft = b.dashDist; e.dashing = true; e.immovable = true; }
    } else if (e.state === 'dash') {
      const step = Math.min(b.dashSpeed * dt, e.dashLeft);
      e.x += Math.cos(e.dashAng) * step; e.y += Math.sin(e.dashAng) * step; e.dashLeft -= step;
      if (e.dashLeft <= 0) { e.state = 'rest'; e.t = b.rest; e.dashing = false; e.immovable = false; }
    } else {   // rest: 멈춰서 숨을 돌림 (공격받기 쉬움)
      e.t -= dt;
      if (e.t <= 0) e.state = 'approach';
    }
    return true;
  },
  draw(ctx, e, x, y) {
    if (e.state === 'warn') {
      const k = 1 - e.t / e.base.warn;
      ctx.strokeStyle = 'rgba(255,70,70,' + (0.35 + 0.5 * k) + ')'; ctx.lineWidth = 2 + 5 * k; ctx.lineCap = 'butt';
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(e.dashAng) * e.base.dashDist, y + Math.sin(e.dashAng) * e.base.dashDist); ctx.stroke();
    }
    const r = e.radius;
    ctx.save(); ctx.translate(x, y); ctx.rotate(e.ang);
    ctx.fillStyle = bodyColor(e); ctx.fillRect(-r, -r, r * 2, r * 2);
    ctx.strokeStyle = e.dashing ? '#fff' : 'rgba(0,0,0,0.5)'; ctx.lineWidth = 2; ctx.strokeRect(-r, -r, r * 2, r * 2);
    ctx.restore();
  },
};

/* ---- 7. 치유: 범위 안 아군을 초당 최대 체력의 5% 회복 (중첩 없음, 자신 제외) ---- */
ENEMY_TYPES.healer = {
  update(e, dt, g) {
    const b = e.base;
    for (const a of g.enemyHash.query(e.x, e.y, b.healRange + 24, g.tmp)) {
      if (a === e || a.dead || a.healTick === g.tick) continue;
      if (Math.hypot(a.x - e.x, a.y - e.y) > b.healRange) continue;
      a.healTick = g.tick;
      a.hp = Math.min(a.maxHp, a.hp + a.maxHp * b.healRate * dt);
    }
    return false;
  },
  draw(ctx, e, x, y) {
    ctx.strokeStyle = 'rgba(90,230,130,0.22)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(x, y, e.base.healRange, 0, TAU); ctx.stroke();
    const r = e.radius, t = r * 0.62;
    ctx.fillStyle = bodyColor(e);
    ctx.beginPath(); ctx.rect(x - t, y - r * 1.2, t * 2, r * 2.4); ctx.rect(x - r * 1.2, y - t, r * 2.4, t * 2); ctx.fill(); outline(ctx);
  },
};

/* ---- 8. 포식: 기본 적을 잡아먹고 강해짐 → 각성하면 플레이어를 쫓음 ---- */
ENEMY_TYPES.devourer = {
  init(e) { e.state = 'hunt'; e.eats = 0; e.pause = 0; e.eatCd = 0; e.life = 0; e.awake = false; },
  update(e, dt, g) {
    const b = e.base, p = g.player;
    e.life += dt;
    if (e.state === 'hunt') {
      if (e.life >= b.timeout) { e.state = 'chase'; return false; }       // 안전장치: 각성 없이 추격만
      if (e.pause > 0) { e.pause -= dt; return true; }
      e.eatCd -= dt;
      let prey = null, bd = b.huntRange * b.huntRange;
      for (const o of g.enemies) {
        if (o.dead || o.type !== 'basic') continue;
        const d = (o.x - e.x) ** 2 + (o.y - e.y) ** 2;
        if (d < bd) { bd = d; prey = o; }
      }
      if (!prey) return false;                                              // 먹이가 없으면 플레이어 쪽으로
      const dx = prey.x - e.x, dy = prey.y - e.y, d = Math.hypot(dx, dy) || 1;
      e.ang = Math.atan2(dy, dx);
      if (d <= b.eatDist + prey.radius && e.eatCd <= 0) { this.eat(e, prey, g); return true; }
      const s = Math.min(e.speed * dt, d);
      e.x += dx / d * s; e.y += dy / d * s;
      return true;
    }
    return false;                                                           // awake / chase 는 기본 추적
  },
  eat(e, prey, g) {
    const b = e.base;
    prey.dead = true;                                                       // 잡아먹힌 적은 처치로 세지 않음
    g.fx.burst(prey.x, prey.y, e.color, 8, 90, 0.4, 3);
    e.eats++; e.pause = b.eatPause; e.eatCd = b.eatGap;
    e.maxHp += prey.maxHp * b.gainHp; e.hp += prey.maxHp * b.gainHp;
    e.contact += e.contact0 * b.gainContact;
    e.speed += b.gainSpeed;
    e.radius = e.radius0 * (1 + b.gainRadius * e.eats);
    if (e.eats >= b.maxEats) {
      e.awake = true; e.state = 'awake';
      e.defense = b.awakeDefense; e.ccImmune = true; e.speed *= b.awakeSpeedMul;
      g.fx.ring(e.x, e.y, 80, [255, 60, 60], 0.6);
      g.notify('포식이 각성했다! 빨리 잡아야 한다');
    }
  },
  onDeath(e, g) {
    for (let i = 0; i < e.eats; i++) {                                      // 먹은 적들의 드롭도 함께 떨굼
      g.gems.push(new Gem(e.x + U.rand(-14, 14), e.y + U.rand(-14, 14), 'small'));
    }
    if (e.awake) g.gems.push(new Gem(e.x, e.y, 'large'));
  },
  draw(ctx, e, x, y) {
    const t = performance.now() / 1000;
    if (e.awake) {
      const pr = e.radius + 6 + 4 * Math.sin(t * 8);
      ctx.strokeStyle = 'rgba(255,50,50,0.9)'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.arc(x, y, pr, 0, TAU); ctx.stroke();
    }
    circle(ctx, e, x, y);
    ctx.fillStyle = e.awake ? '#ff3030' : 'rgba(40,0,30,0.85)';                // 입
    ctx.beginPath(); ctx.arc(x, y, e.radius * 0.5, 0, TAU); ctx.fill();
    if (!e.awake && e.eats > 0) {                                           // 먹은 횟수 점
      for (let i = 0; i < e.eats; i++) { const a = (i / 8) * TAU - Math.PI / 2; ctx.fillStyle = '#ffd0f0'; ctx.fillRect(x + Math.cos(a) * (e.radius + 5) - 1.5, y + Math.sin(a) * (e.radius + 5) - 1.5, 3, 3); }
    }
  },
};

/* ---- 9. 앵커: 밀기/끌기/넉백 면역 (이동 면역은 immovable 플래그로 처리) ---- */
ENEMY_TYPES.anchor = {
  draw(ctx, e, x, y) {
    const r = e.radius;
    ctx.strokeStyle = e.flash > 0 ? '#fff' : U.rgba(e.color, 1); ctx.lineWidth = 6; ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x - r, y - r); ctx.lineTo(x + r, y + r); ctx.moveTo(x + r, y - r); ctx.lineTo(x - r, y + r); ctx.stroke();
    ctx.strokeStyle = 'rgba(0,0,0,0.45)'; ctx.lineWidth = 1.5; ctx.stroke();
  },
};

/* ---- 10. 사수: 거리를 두고 조준 후 발사, 가까워지면 후퇴 ---- */
ENEMY_TYPES.archer = {
  init(e, base) { e.fireT = U.rand(0.8, base.fireGap); e.aimAng = 0; },
  update(e, dt, g) {
    const b = e.base, p = g.player, dx = p.x - e.x, dy = p.y - e.y, d = Math.hypot(dx, dy) || 1;
    if (e.state === 'aim') {
      e.t -= dt;
      if (e.t <= 0) { shootAt(g, e.x, e.y, e.aimAng, b, e.gm); e.state = ''; e.fireT = b.fireGap; }
      return true;
    }
    e.fireT -= dt;
    e.ang = Math.atan2(dy, dx);
    if (e.fireT <= 0 && d <= b.fireRange) { e.state = 'aim'; e.t = b.aim; e.aimAng = e.ang; return true; }
    const s = e.speed * dt;
    if (d < b.retreatDist) { e.x -= dx / d * s; e.y -= dy / d * s; }
    else if (d > b.stopDist) { e.x += dx / d * s; e.y += dy / d * s; }
    return true;
  },
  draw(ctx, e, x, y) {
    if (e.state === 'aim') {
      const k = 1 - e.t / e.base.aim;
      ctx.strokeStyle = 'rgba(255,90,90,' + (0.25 + 0.6 * k) + ')'; ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(e.aimAng) * e.base.bulletRange, y + Math.sin(e.aimAng) * e.base.bulletRange); ctx.stroke();
    }
    ctx.strokeStyle = e.flash > 0 ? '#fff' : U.rgba(e.color, 1); ctx.lineWidth = 3.5;
    ctx.beginPath(); ctx.arc(x, y, e.radius - 1.5, 0, TAU); ctx.stroke();
    ctx.fillStyle = e.flash > 0 ? '#fff' : U.rgba(e.color, 1);
    ctx.beginPath(); ctx.arc(x, y, 2.5, 0, TAU); ctx.fill();
  },
};
