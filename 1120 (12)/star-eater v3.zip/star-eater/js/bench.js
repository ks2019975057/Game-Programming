'use strict';
/* bench.js - 밸런스 테스트 모드 (개발용, ?debug=1 에서 V 키)
   체력이 무한이고 움직이지 않는 더미 적에게 선택한 무기를 쓰고, 초당 평균 피해(DPS)를 잽니다.
   - 단일: 더미 1마리 / 밀집: 더미 4마리가 40px 안에 뭉침
   - [ ] 무기/진화 바꾸기, 1 단일, 4 밀집, R 다시 시작, U 전체 측정(20초씩), V 나가기 */
const Bench = {
  benchEntries() {
    const w = CONFIG.weaponOrder.map((id) => ({ id, label: CONFIG.weaponNames[id] + ' Lv5', evo: null }));
    return w.concat(CONFIG.evolutions.map((e) => ({ id: e.id, label: e.name + ' (' + CONFIG.weaponNames[e.target] + ' 진화)', evo: e })));
  },

  startBench(index, mode, secs) {
    const list = this.benchEntries();
    index = (index + list.length) % list.length;
    const ent = list[index];
    this.benchResults = this.benchResults || {};
    this.resetWorld();
    const p = this.player;
    for (const wid of (ent.evo ? [ent.evo.target, ent.evo.partner] : [ent.id])) {
      const w = new WEAPON_CLASSES[wid](this);
      while (!w.isLv5) w.levelUp();
      p.weapons.push(w);
    }
    if (ent.evo) p.getWeapon(ent.evo.target).evolve(ent.evo);
    this.bench = { index, mode, ent, t: 0, dealt: 0, dur: secs || 60, done: false, hurt: 1 };
    this.godMode = true;
    this.input.override = { x: 0, y: 0 };
    const D = 110, offs = mode === 'single' ? [[0, 0]] : [[-14, -14], [14, -14], [-14, 14], [14, 14]];
    for (const o of offs) {                    // 플레이어 오른쪽 110px (복사열·위성이 닿는 거리)
      const e = new Enemy(p.x + D + o[0], p.y + o[1], 'basic', 0);
      e.dummy = true; e.immovable = true; e.maxHp = e.hp = 1e9; e.speed = 0; e.contact = 0; e.contact0 = 0;
      this.enemies.push(e);
    }
    this.hideScreens();
    this.state = 'play';
  },

  benchTick(dt) {
    const b = this.bench;
    if (b.done) return;
    b.t += dt;
    const tw = b.ent.evo ? b.ent.evo.target : b.ent.id;
    if (tw === 'atmosphere' && (b.hurt -= dt) <= 0) {      // 대기 진화는 보호막이 깨져야 발동하므로 주기적으로 맞아 줌
      const p = this.player; b.hurt = 9; p.invuln = 0; p.takeDamage(1);
    }
    if (b.t >= b.dur) {
      b.done = true;
      this.benchResults[b.ent.id + ':' + b.mode] = b.dealt / b.dur;
      this.notify('측정 완료: ' + b.ent.label + ' ' + (b.mode === 'single' ? '단일' : '밀집') + ' ' + Math.round(b.dealt / b.dur) + ' DPS');
    }
  },

  /* 화면 없이 바로 측정 (밸런스 점검용) */
  runBenchSync(index, mode, secs) {
    this.startBench(index, mode, secs);
    for (let i = 0; i < Math.round(secs * 60); i++) this.update(STEP);
    const b = this.bench;
    return b.dealt / b.dur;
  },

  /* 전부 측정해서 표로 출력 (기본 20초씩)
     진화 줄에는 짝 무기 피해가 섞여 있으므로 (진화 합계 - 짝 무기 단독)을 진화의 몫으로 보고,
     원본 5레벨 단독 DPS 와 비교한 배율을 계산합니다. */
  benchAll(secs) {
    const list = this.benchEntries(), rows = [], base = {};
    list.forEach((ent, i) => {
      const s = this.runBenchSync(i, 'single', secs || 20), c = this.runBenchSync(i, 'cluster', secs || 20);
      if (!ent.evo) base[ent.id] = { s, c };
      rows.push({ ent, s, c });
    });
    const out = rows.map((r) => {
      const e = r.ent.evo, row = { 이름: r.ent.label, 단일: Math.round(r.s), 밀집: Math.round(r.c) };
      if (e) {
        const t = base[e.target], q = base[e.partner];
        row['진화 몫(단일)'] = Math.round(r.s - q.s); row['진화 몫(밀집)'] = Math.round(r.c - q.c);
        row['단일 배율'] = t.s > 0 ? +((r.s - q.s) / t.s).toFixed(2) : '-';
        row['밀집 배율'] = t.c > 0 ? +((r.c - q.c) / t.c).toFixed(2) : '-';
      }
      return row;
    });
    this.state = 'title'; this.bench = null; this.showScreen('title'); this.input.override = null;
    console.table(out);
    return out;
  },

  benchKey(code) {
    const b = this.bench;
    if (code === 'BracketRight') this.startBench(b.index + 1, b.mode);
    else if (code === 'BracketLeft') this.startBench(b.index - 1, b.mode);
    else if (code === 'Digit1') this.startBench(b.index, 'single');
    else if (code === 'Digit4') this.startBench(b.index, 'cluster');
    else if (code === 'KeyR') this.startBench(b.index, b.mode);
    else if (code === 'KeyU') this.benchAll(20);
    else return false;
    return true;
  },

  drawBench(ctx) {
    const b = this.bench, W = this.W, x = W / 2, y = 130;
    const R = this.benchResults || {};
    const dps = b.t > 0 ? b.dealt / b.t : 0;
    ctx.fillStyle = 'rgba(8,10,24,0.82)'; ctx.fillRect(x - 230, y - 16, 460, 118);
    ctx.strokeStyle = 'rgba(255,214,90,0.7)'; ctx.lineWidth = 1; ctx.strokeRect(x - 230, y - 16, 460, 118);
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffd65a'; ctx.font = 'bold 15px ' + FONT;
    ctx.fillText('밸런스 테스트 · ' + b.ent.label, x, y);
    ctx.fillStyle = '#fff'; ctx.font = '13px ' + FONT;
    ctx.fillText((b.mode === 'single' ? '단일 대상(1마리)' : '밀집(4마리, 40px 안)') + '  ·  ' + Math.min(b.t, b.dur).toFixed(0) + ' / ' + b.dur + '초' + (b.done ? '  완료' : ''), x, y + 22);
    ctx.font = 'bold 22px ' + FONT; ctx.fillStyle = b.done ? '#7fe0ff' : '#fff';
    ctx.fillText('DPS ' + Math.round(dps), x, y + 48);
    const s = R[b.ent.id + ':single'], c = R[b.ent.id + ':cluster'];
    ctx.font = '12px ' + FONT; ctx.fillStyle = 'rgba(255,255,255,0.7)';
    ctx.fillText('기록  단일 ' + (s === undefined ? '-' : Math.round(s)) + '  ·  밀집 ' + (c === undefined ? '-' : Math.round(c)), x, y + 70);
    ctx.fillText('[ ] 무기 바꾸기 · 1 단일 · 4 밀집 · R 다시 · U 전체 측정 · V 나가기', x, y + 88);
  },
};
