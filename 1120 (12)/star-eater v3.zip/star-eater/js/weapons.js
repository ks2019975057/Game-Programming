'use strict';
/* weapons.js - 무기 클래스 8종과 각 무기의 진화 효과
   모든 수치는 CONFIG.weapons / CONFIG.evolutions 에서 읽습니다.
   진화하면 5레벨 수치 위에 evo.stats 가 덮어써지고, evo.p 가 진화 효과 수치가 됩니다. */

class Weapon {
  constructor(game, id) {
    this.game = game;
    this.id = id;
    this.cfg = CONFIG.weapons[id];
    this.level = 1;
    this.timer = 0;
    this.mods = {};          // 시작 패시브 효과 (시작 무기에만 붙음)
    this.evo = null;         // 진화하면 CONFIG.evolutions 의 항목이 들어감
    this.refresh();
  }
  refresh() {
    const L = this.cfg.levels;
    const base = this.evo ? Object.assign({}, L[L.length - 1], this.evo.stats) : Object.assign({}, L[this.level - 1]);
    const B = CONFIG.balance, bonus = this.evo ? B.evo : (this.isLv5 ? B.lv5 : null);   // MAX/진화 보너스
    if (bonus) {
      if (typeof base.damage === 'number') base.damage *= bonus.damage;
      if (typeof base.cooldown === 'number') base.cooldown *= bonus.cooldown;
    }
    this._lv = base;
  }
  get lv() { return this._lv; }
  get eid() { return this.evo ? this.evo.id : ''; }                 // 진화 id (없으면 '')
  get ep() { return this.evo ? this.evo.p : null; }                 // 진화 효과 수치
  get isLv5() { return this.level >= this.cfg.levels.length; }       // 진화한 무기도 5레벨로 칩니다
  get maxed() { return !!this.evo || this.isLv5; }
  get special() { return this.isLv5 && !this.evo; }                  // 5레벨 전용 특수 효과 (진화하면 진화 효과로 대체)
  mod(key) { return this.mods[key] !== undefined ? this.mods[key] : 1; }
  levelUp() {
    if (this.isLv5) return;
    this.level++; this.refresh();
    if (this.isLv5 && this.game.state !== 'title') this.game.weaponMaxFx(this);       // MAX 도달 연출
  }
  evolve(evo) {
    this.evo = evo; this.level = this.cfg.levels.length; this.refresh();
    this.game.evolveFx(this);
    this.onEvolve();
  }
  onEvolve() {}
  sfx() { Sound.play('fire_' + this.id); }
  /* 패시브가 반영된 쿨타임 */
  cooldown() {
    return Math.max(this.cfg.minCooldown || 0, this.lv.cooldown * this.mod('cooldown'));
  }
  update(dt) {}
  drawUnder(ctx, cam) {}   // 적 아래에 그려지는 효과
  drawOver(ctx, cam) {}    // 적 위에 그려지는 효과
}

/* ------------------ 우주 먼지 ------------------ */
class SpaceDust extends Weapon {
  constructor(game) { super(game, 'spaceDust'); this.queue = []; }

  shoot(angle) {
    const g = this.game, p = g.player, cfg = this.cfg, lv = this.lv, ep = this.ep;
    const b = new Projectile(p.x, p.y, angle, lv.speed * this.mod('speed'), lv.damage * this.mod('damage'),
      cfg.projectileRadius, cfg.maxRange * this.mod('range'), lv.pierce || 0, cfg.color);
    b.dust = true;
    this.sfx();
    switch (this.eid) {
      case 'starRay': b.style = 'ray'; break;
      case 'burstDust':                                  // 적중하면 폭발
        b.onHit = (g, b) => g.explode(b.x, b.y, ep.radius, ep.damage, cfg.color);
        break;
      case 'shockDust':                                  // 맞은 적을 날아가던 방향으로 밀어냄
        b.onHit = (g, b, e) => { if (e.knCd <= 0) { g.knock(e, b.vx, b.vy, ep.dist, ep.dur); e.knCd = ep.cd; } };
        break;
      case 'ricochetDust':                               // 근처의 다른 적으로 튕김
        b.bounce = 0;
        b.onHit = (g, b, e) => {
          if (b.bounce >= ep.max) return;
          let best = null, bd = ep.range * ep.range;
          for (const o of g.enemies) {
            if (o.dead || b.hit.has(o)) continue;
            const d = (o.x - e.x) ** 2 + (o.y - e.y) ** 2;
            if (d < bd) { bd = d; best = o; }
          }
          if (!best) return;
          b.bounce++;
          b.angle = Math.atan2(best.y - b.y, best.x - b.x);
          b.vx = Math.cos(b.angle) * b.speed; b.vy = Math.sin(b.angle) * b.speed;
          b.damage *= ep.mul;
          b.traveled = Math.min(b.traveled, b.range - 320);
          return 'keep';
        };
        break;
    }
    g.projectiles.push(b);
  }

  update(dt) {
    const g = this.game, p = g.player, cfg = this.cfg, lv = this.lv;
    for (const s of this.queue) {                        // 순차 발사 큐
      s.delay -= dt;
      if (s.delay <= 0 && !s.fired) { s.fired = true; this.shoot(s.angle); }
    }
    this.queue = this.queue.filter((s) => !s.fired);

    this.timer -= dt;
    if (this.timer > 0) return;
    const target = g.findNearestEnemy(p.x, p.y, cfg.targetRange);
    if (!target) { this.timer = 0.1; return; }
    const angle = Math.atan2(target.y - p.y, target.x - p.x);
    for (let i = 0; i < lv.count; i++) this.queue.push({ delay: i * cfg.burstInterval, angle, fired: false });
    if (this.special && (this.vN = (this.vN || 0) + 1) % 4 === 0) {       // 5레벨: 4번째 연사마다 관통 대형탄
      const S = cfg.lv5, b = new Projectile(p.x, p.y, angle, lv.speed * 0.9, lv.damage * S.mul, cfg.projectileRadius * 2.2, cfg.maxRange, S.pierce, [255, 255, 255]);
      b.dust = true; g.projectiles.push(b);
    }
    this.timer = this.cooldown();
  }
}

/* ------------------ 복사열 ------------------ */
class RadiantHeat extends Weapon {
  constructor(game) { super(game, 'radiantHeat'); this.glow = 0; this.orb = 0; }
  get radius() { return this.lv.radius * this.mod('radius'); }
  /* 궤도 복사: 플레이어 주위를 도는 영역들 */
  areas() {
    const p = this.game.player, ep = this.ep, out = [];
    for (let i = 0; i < ep.count; i++) {
      const a = this.orb + i * Math.PI * 2 / ep.count;
      out.push({ x: p.x + Math.cos(a) * ep.orbit, y: p.y + Math.sin(a) * ep.orbit, r: ep.radius * this.mod('radius') });
    }
    return out;
  }
  update(dt) {
    this.glow = Math.max(0, this.glow - dt * 3.5);
    if (this.eid === 'orbitHeat') this.orb += this.ep.speed * Math.PI / 180 * dt;
    this.timer -= dt;
    if (this.timer > 0) return;
    if (this.pulse() === false) { this.timer = 0.1; return; }
    this.timer = this.cooldown();
  }
  pulse() {
    const g = this.game, p = g.player, c = this.cfg.color, dmg = this.lv.damage * this.mod('damage'), ep = this.ep;
    if (this.eid === 'rayHeat') return this.ray(dmg);
    if (this.eid === 'orbitHeat') {
      for (const a of this.areas()) {
        for (const e of g.enemyHash.query(a.x, a.y, a.r + 24, g.tmpB)) {
          if (!e.dead && Math.hypot(e.x - a.x, e.y - a.y) <= a.r + e.radius) g.damageEnemy(e, dmg);
        }
        g.fx.ring(a.x, a.y, a.r, c, 0.3);
      }
      this.glow = 1;
      return true;
    }
    const R = this.radius;
    const near = g.enemyHash.query(p.x, p.y, R + 24, g.tmp);
    for (const e of near) {
      if (e.dead || Math.hypot(e.x - p.x, e.y - p.y) > R + e.radius) continue;
      g.damageEnemy(e, dmg);
      if (this.special) g.ignite(e, this.cfg.lv5.time, 0.5, dmg * this.cfg.lv5.mul);   // 5레벨: 맞은 적이 불탐
      if (this.eid === 'pressure') g.knock(e, e.x - p.x, e.y - p.y, ep.push, ep.dur);
      else if (this.eid === 'shockHeat') {
        g.damageEnemy(e, ep.damage, 'line');
        if (e.stunCd <= 0) { g.stun(e, ep.stun); e.stunCd = ep.stunCd; }
      }
    }
    this.glow = 1;
    this.sfx();
    g.fx.ring(p.x, p.y, R, c, 0.35);
    return true;
  }
  /* 복사 광선: 가까운 적 위치에 짧은 광선 */
  ray(dmg) {
    const g = this.game, p = g.player, ep = this.ep;
    const t = g.findNearestEnemy(p.x, p.y, ep.range);
    if (!t) return false;
    const a = Math.atan2(t.y - p.y, t.x - p.x), hx = Math.cos(a) * ep.len / 2, hy = Math.sin(a) * ep.len / 2;
    g.segEnemies(t.x - hx, t.y - hy, t.x + hx, t.y + hy, ep.width, (e) => g.damageEnemy(e, dmg, 'line', p.x, p.y));
    g.addFlash(p.x, p.y, t.x, t.y, 5, ep.dur * 2, this.cfg.color);
    g.addFlash(t.x - hx, t.y - hy, t.x + hx, t.y + hy, ep.width, ep.dur * 2, this.cfg.color);
    return true;
  }
  drawUnder(ctx, cam) {
    if (this.eid === 'rayHeat') return;
    const p = this.game.player, c = this.cfg.color;
    const list = this.eid === 'orbitHeat' ? this.areas() : [{ x: p.x, y: p.y, r: this.radius }];
    for (const a of list) {
      const x = a.x - cam.x, y = a.y - cam.y;
      ctx.fillStyle = U.rgba(c, 0.06 + 0.22 * this.glow);
      ctx.beginPath(); ctx.arc(x, y, a.r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = U.rgba(c, 0.28 + 0.5 * this.glow);
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }
}

/* ------------------ 위성 ------------------ */
class Satellite extends Weapon {
  constructor(game) {
    super(game, 'satellite');
    this.active = true;               // 얻자마자 바로 소환
    this.life = this.duration();
    this.angle = 0;
    this.alpha = 0;
    this.extraN = 0; this.extraT = 0;  // 쌍성 방벽이 잠깐 더해 주는 위성
    this.sT = [];                      // 위성별 발사 타이머 (먼지/방전 위성)
  }
  duration() { return this.lv.duration * this.mod('duration'); }
  count() { return this.lv.count + (this.extraT > 0 ? this.extraN : 0); }
  /* 쌍성 방벽: 위성을 즉시 소환하고 잠시 더 늘림 */
  summonNow(extraN, extraT) {
    this.active = true; this.life = Math.max(this.life, this.duration());
    this.alpha = Math.max(this.alpha, 0.6);
    this.extraN = extraN; this.extraT = extraT;
  }
  positions() {
    const n = this.count(), p = this.game.player, out = [];
    for (let i = 0; i < n; i++) {
      const a = this.angle + (i * Math.PI * 2) / n;
      out.push({ x: p.x + Math.cos(a) * this.cfg.orbitRadius, y: p.y + Math.sin(a) * this.cfg.orbitRadius });
    }
    return out;
  }
  update(dt) {
    const g = this.game, cfg = this.cfg, ep = this.ep, eid = this.eid;
    if (this.extraT > 0) this.extraT -= dt;
    if (!this.active) {
      this.alpha = Math.max(0, this.alpha - dt / cfg.fade);
      this.timer -= dt;
      if (this.timer <= 0) { this.active = true; this.life = this.duration(); this.sfx(); }
      return;
    }
    this.alpha = Math.min(1, this.alpha + dt / cfg.fade);
    this.angle += (this.lv.orbitSpeed * Math.PI / 180) * dt;
    this.life -= dt;
    if (this.life <= 0) { this.active = false; this.timer = this.cooldown(); return; }
    if (this.alpha < 0.5) return;
    const dmg = this.lv.damage * this.mod('damage');
    this.positions().forEach((s, i) => {
      for (const e of g.enemyHash.query(s.x, s.y, cfg.satRadius + 24, g.tmp)) {
        if (e.dead || Math.hypot(e.x - s.x, e.y - s.y) > cfg.satRadius + e.radius) continue;
        const hits = e._sat || (e._sat = []);
        if (g.time - (hits[i] || -9) < cfg.hitInterval) continue;
        hits[i] = g.time;
        g.damageEnemy(e, dmg);
        if (this.special) g.knock(e, e.x - s.x, e.y - s.y, cfg.lv5.push, 0.15);   // 5레벨: 닿은 적을 튕겨냄
        if (eid === 'heatSat') g.ignite(e, ep.time, ep.tick, ep.damage);
        g.fx.burst(s.x, s.y, cfg.color, 3, 70, 0.25, 2);
      }
      if (eid === 'gravitySat') {                          // 가까운 적을 위성 쪽으로 약하게 끌어당김
        for (const e of g.enemyHash.query(s.x, s.y, ep.range + 24, g.tmpB)) {
          if (e.dead || e.immovable || e.ccImmune) continue;
          const d = Math.hypot(s.x - e.x, s.y - e.y);
          if (d > ep.range + e.radius || d < 6) continue;
          const st = Math.min(ep.pull * dt, d - 4);
          e.x += (s.x - e.x) / d * st; e.y += (s.y - e.y) / d * st;
        }
      } else if (eid === 'dustSat' || eid === 'plasmaSat') {
        if (this.sT[i] === undefined) this.sT[i] = U.rand(0.2, ep.gap);
        if ((this.sT[i] -= dt) > 0) return;
        const t = g.findNearestEnemy(s.x, s.y, ep.range);
        if (!t) { this.sT[i] = 0.2; return; }
        this.sT[i] = ep.gap;
        if (eid === 'dustSat') g.shootDust(s.x, s.y, Math.atan2(t.y - s.y, t.x - s.x), ep.speed, ep.damage, ep.range);
        else g.chain(t, ep.damage, ep.hits, ep.jump, s.x, s.y, CONFIG.weapons.plasma.color);
      }
    });
  }
  drawOver(ctx, cam) {
    if (this.alpha <= 0) return;
    const c = this.cfg.color, p = this.game.player;
    ctx.globalAlpha = this.alpha;
    ctx.strokeStyle = U.rgba(c, 0.12); ctx.lineWidth = 1;
    ctx.beginPath(); ctx.arc(p.x - cam.x, p.y - cam.y, this.cfg.orbitRadius, 0, Math.PI * 2); ctx.stroke();
    for (const s of this.positions()) {
      const x = s.x - cam.x, y = s.y - cam.y, r = this.cfg.satRadius;
      ctx.drawImage(Glow.get(c, 20), x - 20, y - 20, 40, 40);
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, r * 0.75, 0, Math.PI * 2); ctx.fill();
    }
    ctx.globalAlpha = 1;
  }
}

/* ------------------ 운석 ------------------ */
class Meteor extends Weapon {
  constructor(game) { super(game, 'meteor'); this.casts = []; }
  randomTarget() {
    const p = this.game.player, R = this.cfg.targetRange, cand = [];
    for (const e of this.game.enemies) {
      if (!e.dead && Math.hypot(e.x - p.x, e.y - p.y) <= R) cand.push(e);
    }
    return cand.length ? U.pick(cand) : null;
  }
  /* 착탄 시 진화 효과 */
  hook() {
    const ep = this.ep, color = this.cfg.color;
    switch (this.eid) {
      case 'dustRain': return (g, s) => {
        for (let i = 0; i < ep.count; i++) g.shootDust(s.x, s.y, i * Math.PI * 2 / ep.count, ep.speed, ep.damage, ep.range);
      };
      case 'barrier': return (g, s) => g.addWall(s.x, s.y, Math.random() * Math.PI, ep.len, ep.thick, ep.life, ep.max);
      case 'fireball': return (g, s) => g.addZone({ x: s.x, y: s.y, r: ep.radius, life: ep.life, tick: ep.tick, dmg: ep.damage, color: [255, 140, 60], group: 'fire', max: 10 });
      case 'gravityMeteor': return (g, s) => g.addZone({ x: s.x, y: s.y, r: ep.radius, life: ep.life, pull: ep.pull, dmg: 0, color: [170, 110, 255], group: 'gm', max: ep.max });
    }
    if (this.special) {                                    // 5레벨: 착탄 자리에 잔불 장판
      const S = this.cfg.lv5, dmg = this.lv.damage * this.mod('damage') * S.mul;
      return (g, s) => g.addZone({ x: s.x, y: s.y, r: S.radius, life: S.life, tick: 0.5, dmg, color: [255, 140, 60], group: 'ember', max: 12 });
    }
    return null;
  }
  update(dt) {
    const g = this.game, cfg = this.cfg;
    this.timer -= dt;
    if (this.timer <= 0) {
      if (!this.randomTarget()) this.timer = cfg.retry;
      else {
        for (let i = 0; i < this.lv.count; i++) this.casts.push({ wait: i * cfg.castInterval });
        this.timer = this.cooldown();
      }
    }
    for (const m of this.casts) {
      m.wait -= dt;
      if (m.wait > 0) continue;
      m.done = true;
      const t = this.randomTarget();                       // 경고가 시작될 때 위치를 확정
      if (t) this.sfx();
      if (t) g.addStrike(t.x, t.y, { warn: cfg.warn, r: this.lv.radius * this.mod('radius'),
        dmg: this.lv.damage * this.mod('damage'), color: cfg.color, onImpact: this.hook() });
    }
    this.casts = this.casts.filter((m) => !m.done);
  }
}

/* ------------------ 대기 ------------------ */
class Atmosphere extends Weapon {
  constructor(game) {
    super(game, 'atmosphere');
    this.layers = 0;
    this.pending = [];         // 유성 방벽: 시간차로 떨어뜨릴 운석
  }
  get maxLayers() { return this.mods.layers || 1; }
  init() { if (this.layers === 0 && !this._init) { this.layers = this.maxLayers; this._init = true; } }
  update(dt) {
    this.init();
    if (this.layers < this.maxLayers) {
      this.timer -= dt;
      if (this.timer <= 0) {
        this.layers++;
        this.sfx();
        this.game.fx.ring(this.game.player.x, this.game.player.y, 22, this.cfg.color, 0.4);
        this.timer = this.cooldown();
      }
    }
    for (const m of this.pending) {
      m.wait -= dt;
      if (m.wait > 0) continue;
      m.done = true;
      const g = this.game, p = g.player, ep = this.ep, cand = [];
      for (const e of g.enemies) if (!e.dead && Math.hypot(e.x - p.x, e.y - p.y) <= ep.range) cand.push(e);
      if (cand.length) {
        const t = U.pick(cand);
        g.addStrike(t.x, t.y, { warn: ep.warn, r: ep.radius, dmg: ep.damage, color: CONFIG.weapons.meteor.color });
      }
    }
    this.pending = this.pending.filter((m) => !m.done);
  }
  /* 피해를 막았으면 true */
  tryBlock() {
    this.init();
    if (this.layers <= 0) return false;
    const g = this.game, p = g.player;
    if (this.layers === this.maxLayers) this.timer = this.cooldown();   // 재생성 시작
    this.layers--;
    p.invuln = this.cfg.breakInvuln;
    g.fx.ring(p.x, p.y, 40, this.cfg.color, 0.45);
    g.fx.burst(p.x, p.y, this.cfg.color, 14, 160, 0.45, 3);
    g.shake = Math.max(g.shake, 3);
    Sound.play('shieldBreak');
    this.onBreak();
    return true;
  }
  /* 보호막이 깨질 때마다 진화 효과 발동 */
  onBreak() {
    const g = this.game, p = g.player, ep = this.ep;
    switch (this.eid) {
      case 'gravityWall': {                                // 충격파로 적을 가장자리까지 밀어냄
        for (const e of g.enemyHash.query(p.x, p.y, ep.radius + 24, g.tmpB)) {
          const d = Math.hypot(e.x - p.x, e.y - p.y);
          if (e.dead || d > ep.radius + e.radius) continue;
          g.damageEnemy(e, ep.damage, 'area', p.x, p.y);
          g.knock(e, e.x - p.x, e.y - p.y, Math.max(80, ep.radius - d), ep.dur);
        }
        g.fx.ring(p.x, p.y, ep.radius, this.cfg.color, 0.5);
        g.shake = Math.max(g.shake, 8);
        break;
      }
      case 'starWall': {                                   // 사방으로 혜성
        const c = CONFIG.weapons.comet;
        for (let i = 0; i < ep.count; i++) {
          const b = new Projectile(p.x, p.y, i * Math.PI * 2 / ep.count, c.speed, ep.damage, c.radius, c.range, Infinity, c.color);
          b.style = 'comet';
          g.projectiles.push(b);
        }
        break;
      }
      case 'meteorWall':
        for (let i = 0; i < ep.count; i++) this.pending.push({ wait: i * ep.gap });
        break;
      case 'twinWall': {
        const sat = p.getWeapon('satellite');
        if (sat) sat.summonNow(ep.extra, ep.time);
        break;
      }
    }
    if (this.special) {                                    // 5레벨: 보호막이 깨질 때 충격파로 적을 밀어냄
      const S = this.cfg.lv5;
      for (const e of g.enemyHash.query(p.x, p.y, S.radius + 24, g.tmpB)) {
        const d = Math.hypot(e.x - p.x, e.y - p.y);
        if (e.dead || d > S.radius + e.radius) continue;
        g.damageEnemy(e, S.damage, 'area', p.x, p.y);
        g.knock(e, e.x - p.x, e.y - p.y, S.push, 0.2);
      }
      g.fx.ring(p.x, p.y, S.radius, this.cfg.color, 0.5); g.shake = Math.max(g.shake, 6);
    }
  }
  drawOver(ctx, cam) {
    const p = this.game.player, c = this.cfg.color, x = p.x - cam.x, y = p.y - cam.y;
    for (let i = 0; i < this.layers; i++) {
      const r = 15 + i * 6;
      ctx.fillStyle = U.rgba(c, 0.08); ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = this.evo ? 'rgba(255,214,90,0.85)' : U.rgba(c, 0.75); ctx.lineWidth = 2; ctx.stroke();
    }
    if (this.layers < this.maxLayers) {     // 재생성 게이지
      const k = 1 - Math.max(0, this.timer) / this.cooldown();
      const r = 15 + this.layers * 6;
      ctx.strokeStyle = U.rgba(c, 0.35); ctx.lineWidth = 2;
      ctx.beginPath(); ctx.arc(x, y, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * k); ctx.stroke();
    }
  }
}

/* ------------------ 혜성 ------------------ */
class Comet extends Weapon {
  constructor(game) { super(game, 'comet'); this.beam = null; }

  fire(base) {
    const g = this.game, p = g.player, cfg = this.cfg, lv = this.lv, ep = this.ep, step = cfg.spread * Math.PI / 180;
    for (let i = 0; i < lv.count; i++) {
      const a = base + (i - (lv.count - 1) / 2) * step;
      const b = new Projectile(p.x, p.y, a, cfg.speed, lv.damage * this.mod('damage'),
        cfg.radius, (lv.range || cfg.range) * this.mod('range'), Infinity, cfg.color);
      b.style = 'comet';
      switch (this.eid) {
        case 'nebula':                                      // 날면서 좌우로 먼지 탄환
          b.nt = 0; b.pairs = 0;
          b.onTick = (g, b, dt) => {
            if ((b.nt -= dt) > 0 || b.pairs >= ep.maxPairs) return;
            b.nt = ep.interval; b.pairs++;
            g.shootDust(b.x, b.y, b.angle + Math.PI / 2, ep.speed, ep.damage, ep.range);
            g.shootDust(b.x, b.y, b.angle - Math.PI / 2, ep.speed, ep.damage, ep.range);
          };
          break;
        case 'blaze':                                       // 지나간 자리에 복사열 장판
          b.nextDrop = 0;
          b.onTick = (g, b) => {
            while (b.traveled >= b.nextDrop) {
              b.nextDrop += ep.step;
              g.addZone({ x: b.x, y: b.y, r: ep.radius, life: ep.life, tick: ep.tick, dmg: ep.damage, color: [255, 154, 60], group: 'blaze', max: 40 });
            }
          };
          break;
        case 'boom':                                        // 사거리 끝에서 폭발
          b.onEnd = (g, b) => g.explode(b.x, b.y, ep.radius, ep.damage, cfg.color);
          break;
      }
      if (this.special) {                                  // 5레벨: 끝에서 큰 폭발 + 지나가며 꼬리불
        const S = cfg.lv5, dmg = lv.damage * this.mod('damage');
        b.onEnd = (g, b) => g.explode(b.x, b.y, S.radius, dmg * S.mul, cfg.color);
      }
      g.projectiles.push(b);
    }
  }

  update(dt) {
    const g = this.game, p = g.player, cfg = this.cfg;
    if (this.beam) this.updateBeam(dt);
    this.timer -= dt;
    if (this.timer > 0) return;
    const t = g.findNearestEnemy(p.x, p.y, cfg.targetRange);
    if (!t) { this.timer = 0.1; return; }
    const base = Math.atan2(t.y - p.y, t.x - p.x);
    this.sfx();
    if (this.eid === 'cometLaser') this.beam = { t: this.ep.dur, ang: base, tick: 0 };
    else this.fire(base);
    this.timer = this.cooldown();
  }

  /* 혜성 레이저: 가장 가까운 적 쪽으로 천천히 돌며 쓸어 냄 */
  updateBeam(dt) {
    const g = this.game, p = g.player, ep = this.ep, b = this.beam;
    if ((b.t -= dt) <= 0) { this.beam = null; return; }
    const t = g.findNearestEnemy(p.x, p.y, this.cfg.targetRange);
    if (t) {
      let diff = Math.atan2(t.y - p.y, t.x - p.x) - b.ang;
      while (diff > Math.PI) diff -= Math.PI * 2;
      while (diff < -Math.PI) diff += Math.PI * 2;
      const turn = ep.turn * Math.PI / 180 * dt;
      b.ang += U.clamp(diff, -turn, turn);
    }
    if ((b.tick -= dt) > 0) return;
    b.tick += ep.tick;
    const x2 = p.x + Math.cos(b.ang) * ep.len, y2 = p.y + Math.sin(b.ang) * ep.len;
    g.segEnemies(p.x, p.y, x2, y2, ep.width, (e) => {
      g.damageEnemy(e, ep.damage * this.mod('damage'), 'line', p.x, p.y);
      if (e.knCd <= 0) { g.knock(e, e.x - p.x, e.y - p.y, ep.knock, 0.15); e.knCd = ep.knockCd; }
    });
  }

  drawOver(ctx, cam) {
    if (!this.beam) return;
    const p = this.game.player, ep = this.ep, b = this.beam, c = this.cfg.color;
    const x = p.x - cam.x, y = p.y - cam.y, x2 = x + Math.cos(b.ang) * ep.len, y2 = y + Math.sin(b.ang) * ep.len;
    const f = Math.min(1, b.t / 0.2);
    ctx.globalAlpha = f; ctx.lineCap = 'round';
    ctx.strokeStyle = U.rgba(c, 0.3); ctx.lineWidth = ep.width * 1.6;
    ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x2, y2); ctx.stroke();
    ctx.strokeStyle = U.rgba(c, 0.75); ctx.lineWidth = ep.width * 0.7; ctx.stroke();
    ctx.strokeStyle = '#fff'; ctx.lineWidth = ep.width * 0.28; ctx.stroke();
    ctx.globalAlpha = 1;
  }
}

/* ------------------ 블랙홀 ------------------ */
class BlackHole extends Weapon {
  constructor(game) { super(game, 'blackHole'); this.holes = []; }
  get radius() { return this.lv.radius * this.mod('radius'); }
  /* 적이 가장 많이 모인 곳 (플레이어 근처 targetRange 안) */
  densestSpot() {
    const g = this.game, p = g.player, R = this.radius;
    let best = null, bn = 0;
    for (const e of g.enemies) {
      if (e.dead || Math.hypot(e.x - p.x, e.y - p.y) > this.cfg.targetRange) continue;
      let n = 0, sx = 0, sy = 0;
      for (const o of g.enemyHash.query(e.x, e.y, R + 24, g.tmp)) {
        if (!o.dead && Math.hypot(o.x - e.x, o.y - e.y) <= R) { n++; sx += o.x; sy += o.y; }
      }
      if (n > bn) { bn = n; best = { x: sx / n, y: sy / n }; }
    }
    return best;
  }
  orbs(h) {                                                // 강착 원반: 중심을 도는 작은 위성들
    const ep = this.ep, out = [];
    for (let i = 0; i < ep.count; i++) {
      const a = h.oa + i * Math.PI * 2 / ep.count;
      out.push({ x: h.x + Math.cos(a) * ep.radius, y: h.y + Math.sin(a) * ep.radius });
    }
    return out;
  }
  update(dt) {
    const g = this.game, cfg = this.cfg, ep = this.ep, eid = this.eid;
    this.timer -= dt;
    if (this.timer <= 0) {
      const spot = this.densestSpot();
      if (!spot) this.timer = cfg.retry;
      else {
        const life = this.lv.duration * this.mod('duration');
        this.holes.push({ x: spot.x, y: spot.y, life, tick: cfg.tick, r: this.radius,
          dmg: this.lv.damage * this.mod('damage'), spin: 0, dis: 0.3, oa: 0, ended: false });
        this.sfx();
        if (eid === 'flameHole') g.addZone({ x: spot.x, y: spot.y, r: ep.radius, life, tick: ep.tick, dmg: ep.damage, color: [255, 140, 60] });
        this.timer = this.cooldown();
      }
    }
    for (const h of this.holes) {
      h.life -= dt; h.spin += dt * 3;
      if (h.life <= 0) {
        if (!h.ended) {
          h.ended = true;
          if (this.special) { g.explode(h.x, h.y, h.r, h.dmg * cfg.lv5.mul, cfg.color); g.shake = Math.max(g.shake, 6); }   // 5레벨: 사라질 때 폭발
          if (eid === 'collapse') for (let i = 0; i < ep.count; i++)       // 끝날 때 중심으로 운석
            g.addStrike(h.x, h.y, { warn: ep.warn + i * ep.gap, r: ep.radius, dmg: ep.damage, color: CONFIG.weapons.meteor.color });
        }
        continue;
      }
      const near = g.enemyHash.query(h.x, h.y, h.r + 24, g.tmp);
      const ticking = (h.tick -= dt) <= 0;
      if (ticking) h.tick += cfg.tick;
      for (const e of near) {
        if (e.dead) continue;
        const d = Math.hypot(h.x - e.x, h.y - e.y);
        if (d > h.r) continue;
        if (d > cfg.stopRadius && !e.immovable) {
          const step = Math.min(cfg.pullSpeed * dt, d - cfg.stopRadius);
          e.x += (h.x - e.x) / d * step; e.y += (h.y - e.y) / d * step;
        }
        if (ticking) g.damageEnemy(e, h.dmg);
      }
      if (eid === 'discharge' && (h.dis -= dt) <= 0) {                     // 1초마다 범위 안 적에게 플라즈마
        h.dis += ep.interval;
        const cand = near.filter((e) => !e.dead && Math.hypot(h.x - e.x, h.y - e.y) <= h.r);
        if (cand.length) g.chain(U.pick(cand), ep.damage, ep.hits, ep.jump, h.x, h.y, CONFIG.weapons.plasma.color);
      } else if (eid === 'accretion') {
        h.oa += ep.speed * Math.PI / 180 * dt;
        for (const o of this.orbs(h)) {
          for (const e of near) {
            if (e.dead || Math.hypot(e.x - o.x, e.y - o.y) > ep.size + e.radius) continue;
            if (g.time - (e._orbT || -9) < ep.gap) continue;
            e._orbT = g.time;
            g.damageEnemy(e, ep.damage);
          }
        }
      }
    }
    this.holes = this.holes.filter((h) => h.life > 0);
  }
  drawUnder(ctx, cam) {
    const c = this.cfg.color;
    for (const h of this.holes) {
      const x = h.x - cam.x, y = h.y - cam.y, f = Math.min(1, h.life / 0.4);
      ctx.globalAlpha = f;
      ctx.fillStyle = U.rgba(c, 0.07); ctx.beginPath(); ctx.arc(x, y, h.r, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = U.rgba(c, 0.35); ctx.lineWidth = 1.5; ctx.stroke();
      for (let i = 0; i < 3; i++) {                       // 소용돌이 팔
        const a0 = h.spin + i * Math.PI * 2 / 3;
        ctx.strokeStyle = U.rgba(c, 0.5); ctx.lineWidth = 2;
        ctx.beginPath();
        for (let k = 0; k <= 12; k++) {
          const t = k / 12, a = a0 + t * 2.2, r = h.r * (1 - t) * 0.95 + 4;
          const px = x + Math.cos(a) * r, py = y + Math.sin(a) * r;
          if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
        }
        ctx.stroke();
      }
      ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(x, y, 12, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = U.rgba(c, 0.9); ctx.lineWidth = 2; ctx.stroke();
      if (this.eid === 'accretion') {
        for (const o of this.orbs(h)) {
          ctx.drawImage(Glow.get([190, 200, 255], 12), o.x - cam.x - 12, o.y - cam.y - 12, 24, 24);
          ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(o.x - cam.x, o.y - cam.y, this.ep.size * 0.6, 0, Math.PI * 2); ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
    }
  }
}

/* ------------------ 플라즈마 ------------------ */
class Plasma extends Weapon {
  constructor(game) { super(game, 'plasma'); }
  /* 총 타격 수 (첫 대상 포함) */
  hits() { return this.lv.chain + (this.mods.chainAdd || 0) + (this.special ? this.cfg.lv5.chain : 0); }   // 5레벨: 연쇄 +N
  update(dt) {
    const g = this.game, p = g.player, cfg = this.cfg, ep = this.ep;
    this.timer -= dt;
    if (this.timer > 0) return;
    const first = g.findNearestEnemy(p.x, p.y, cfg.targetRange);
    if (!first) { this.timer = cfg.retry; return; }
    const dmg = this.lv.damage * this.mod('damage'), jr = cfg.jumpRange * this.mod('jumpRange');
    this.sfx();
    const res = g.chain(first, dmg, this.hits(), jr, p.x, p.y, cfg.color);
    if (this.special) for (const e of res.list) g.stun(e, cfg.lv5.stun);      // 5레벨: 맞은 적 감전(기절)
    switch (this.eid) {
      case 'condense': {                                  // 맞은 적들을 중심점으로 뭉침
        let cx = 0, cy = 0;
        for (const e of res.list) { cx += e.x; cy += e.y; }
        cx /= res.list.length; cy /= res.list.length;
        for (const e of res.list) g.knock(e, cx - e.x, cy - e.y, Math.min(ep.pull, Math.hypot(cx - e.x, cy - e.y)), ep.dur);
        break;
      }
      case 'plasmaLaser':                                 // 연쇄 경로에 레이저가 남음
        g.addSeg({ pts: res.pts, life: ep.life, tick: ep.tick, dmg: ep.damage, width: ep.width, color: cfg.color });
        break;
      case 'tractor': {                                   // 위성 가까이에서 맞은 적을 위성 쪽으로 끌고 다님
        const sat = p.getWeapon('satellite');
        if (sat && sat.active) {
          const pos = sat.positions();
          for (const e of res.list) {
            if (pos.some((s) => Math.hypot(s.x - e.x, s.y - e.y) <= ep.range)) e.tow = { t: ep.time, speed: ep.speed };
          }
        }
        break;
      }
      case 'guided':                                      // 표식 → 우주 먼지가 유도됨
        for (const e of res.list) e.mark = ep.mark;
        break;
    }
    this.timer = this.cooldown();
  }
}

const WEAPON_CLASSES = {
  spaceDust: SpaceDust, radiantHeat: RadiantHeat, satellite: Satellite, meteor: Meteor,
  atmosphere: Atmosphere, comet: Comet, blackHole: BlackHole, plasma: Plasma,
};
