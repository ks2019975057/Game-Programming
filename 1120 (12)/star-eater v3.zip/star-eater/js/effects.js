'use strict';
/* effects.js - 글로우 스프라이트, 파티클, 데미지 숫자, 충격 링, 배경 */

/* 부드러운 빛 덩어리를 미리 그려 두고 재사용합니다. (shadowBlur보다 훨씬 가벼움) */
const Glow = {
  cache: new Map(),
  get(color, size) {
    const key = color.join(',') + ':' + size;
    let c = this.cache.get(key);
    if (!c) {
      c = document.createElement('canvas');
      c.width = c.height = size * 2;
      const g = c.getContext('2d');
      const grad = g.createRadialGradient(size, size, 0, size, size, size);
      grad.addColorStop(0, U.rgba(color, 1));
      grad.addColorStop(0.25, U.rgba(color, 0.55));
      grad.addColorStop(1, U.rgba(color, 0));
      g.fillStyle = grad;
      g.fillRect(0, 0, size * 2, size * 2);
      this.cache.set(key, c);
    }
    return c;
  },
};

class Effects {
  constructor() {
    this.particles = [];
    this.popups = [];
    this.rings = [];
    this.pool = [];              // 파티클 오브젝트 풀 (new 대신 재사용)
  }
  reset() { for (const p of this.particles) this.pool.push(p); this.particles.length = 0; this.popups.length = 0; this.rings.length = 0; }

  burst(x, y, color, n, speed, life, size) {
    n = Math.round(n * CONFIG.fx.particles);
    for (let i = 0; i < n && this.particles.length < 500; i++) {
      const a = Math.random() * Math.PI * 2, s = speed * (0.4 + Math.random() * 0.6);
      const p = this.pool.pop() || {};
      p.x = x; p.y = y; p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s; p.life = life; p.max = life; p.color = color; p.size = size;
      this.particles.push(p);
    }
  }
  popup(x, y, text, color) {
    if (CONFIG.fx.popups <= 0 || this.popups.length >= 70) return;
    this.popups.push({ x: x + U.rand(-6, 6), y: y - 8, text, color, life: 0.6, max: 0.6 });
  }
  ring(x, y, r, color, life) {
    this.rings.push({ x, y, r, color, life, max: life });
  }

  update(dt) {
    let j = 0;                                       // 죽은 파티클은 풀로 돌려보내며 제자리에서 압축
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.vx *= 1 - 3 * dt; p.vy *= 1 - 3 * dt;
      p.life -= dt;
      if (p.life > 0) this.particles[j++] = p; else this.pool.push(p);
    }
    this.particles.length = j;
    for (const p of this.popups) { p.y -= 28 * dt; p.life -= dt; }
    for (const r of this.rings) r.life -= dt;
    this.popups = this.popups.filter((p) => p.life > 0);
    this.rings = this.rings.filter((r) => r.life > 0);
  }

  draw(ctx, cam) {
    for (const r of this.rings) {
      const t = 1 - r.life / r.max;
      ctx.strokeStyle = U.rgba(r.color, (1 - t) * 0.9);
      ctx.lineWidth = 3 * (1 - t) + 1;
      ctx.beginPath();
      ctx.arc(r.x - cam.x, r.y - cam.y, r.r * (0.6 + 0.4 * t), 0, Math.PI * 2);
      ctx.stroke();
    }
    for (const p of this.particles) {
      const a = p.life / p.max;
      ctx.fillStyle = U.rgba(p.color, a);
      const s = p.size * (0.5 + a * 0.5);
      ctx.fillRect(p.x - cam.x - s / 2, p.y - cam.y - s / 2, s, s);
    }
    ctx.font = 'bold 12px "Noto Sans KR", "Malgun Gothic", sans-serif';
    ctx.textAlign = 'center';
    for (const p of this.popups) {
      ctx.fillStyle = U.rgba(p.color, Math.min(1, p.life / p.max * 1.6));
      ctx.fillText(p.text, p.x - cam.x, p.y - cam.y);
    }
  }
}

/* 성운·행성·별이 겹친 패럴랙스 배경 (무한 반복).
   시간과 위치에 따라 색조가 천천히 바뀌고, suck(0~1)이 올라가면 모든 것이 중심으로 빨려 들어갑니다 (엔딩). */
class Background {
  constructor() {
    this.layers = [
      { tile: 520, count: 55, size: 1.2, parallax: 0.15, alpha: 0.35 },
      { tile: 420, count: 38, size: 1.8, parallax: 0.35, alpha: 0.55 },
      { tile: 320, count: 22, size: 2.6, parallax: 0.60, alpha: 0.80 },
    ];
    for (const L of this.layers) {
      L.stars = [];
      for (let i = 0; i < L.count; i++) {
        L.stars.push({ x: Math.random() * L.tile, y: Math.random() * L.tile, warm: Math.random() < 0.25, ph: Math.random() * 6.28, sp: 1 + Math.random() * 2 });
      }
    }
    this.suck = 0; this.cx = 0; this.cy = 0;
    this.hues = [250, 285, 205, 330, 170];
    this.neb = this.hues.map((h, i) => this.makeNebula(h, i));           // 성운 스프라이트
    this.planets = [this.makePlanet(0), this.makePlanet(1), this.makePlanet(2)];
    this.far = { tile: 1700, items: [] };                                // 행성 배치
    for (let i = 0; i < 3; i++) this.far.items.push({ x: 150 + i * 560 + Math.random() * 200, y: 200 + Math.random() * 1200, p: i, s: 0.7 + Math.random() * 0.8 });
    this.nebs = [];
    for (let i = 0; i < 6; i++) this.nebs.push({ x: Math.random() * 1500, y: Math.random() * 1500, n: i % this.neb.length, s: 0.9 + Math.random() * 0.9, par: i < 3 ? 0.10 : 0.22 });
  }
  makeNebula(hue, seed) {
    const S = 520, c = document.createElement('canvas'); c.width = c.height = S;
    const g = c.getContext('2d');
    let r = seed * 7.13 + 1; const rnd = () => (r = (r * 16807) % 2147483647) / 2147483647;
    for (let k = 0; k < 9; k++) {                                         // 겹친 부드러운 덩어리
      const x = S * (0.25 + rnd() * 0.5), y = S * (0.25 + rnd() * 0.5), rad = S * (0.14 + rnd() * 0.2);
      const h = hue + (rnd() - 0.5) * 50;
      const gr = g.createRadialGradient(x, y, 0, x, y, rad);
      gr.addColorStop(0, 'hsla(' + h + ',80%,60%,0.34)');
      gr.addColorStop(0.5, 'hsla(' + h + ',75%,45%,0.14)');
      gr.addColorStop(1, 'hsla(' + h + ',70%,35%,0)');
      g.fillStyle = gr; g.fillRect(0, 0, S, S);
    }
    return c;
  }
  makePlanet(i) {
    const S = 220, c = document.createElement('canvas'); c.width = c.height = S;
    const g = c.getContext('2d'), cx = S / 2, cy = S / 2, R = 62;
    const pal = [['#7fa8ff', '#1a2a6a'], ['#ffb27a', '#5a2a1a'], ['#9cf0c8', '#16503f']][i];
    const gr = g.createRadialGradient(cx - R * 0.4, cy - R * 0.4, R * 0.1, cx, cy, R);
    gr.addColorStop(0, pal[0]); gr.addColorStop(1, pal[1]);
    if (i === 1) {                                                         // 고리
      g.strokeStyle = 'rgba(255,220,170,0.55)'; g.lineWidth = 7;
      g.beginPath(); g.ellipse(cx, cy, R * 1.6, R * 0.45, -0.35, Math.PI, Math.PI * 2); g.stroke();
    }
    g.fillStyle = gr; g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.fill();
    g.save(); g.beginPath(); g.arc(cx, cy, R, 0, Math.PI * 2); g.clip();     // 밤 쪽 그림자와 띠
    g.fillStyle = 'rgba(255,255,255,0.08)';
    for (let k = -2; k <= 2; k++) g.fillRect(cx - R, cy + k * 18, R * 2, 6);
    const sh = g.createRadialGradient(cx - R * 0.7, cy - R * 0.7, R * 0.4, cx - R * 0.5, cy - R * 0.5, R * 2);
    sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,8,0.85)');
    g.fillStyle = sh; g.fillRect(0, 0, S, S); g.restore();
    if (i === 1) {
      g.strokeStyle = 'rgba(255,220,170,0.65)'; g.lineWidth = 7;
      g.beginPath(); g.ellipse(cx, cy, R * 1.6, R * 0.45, -0.35, 0, Math.PI); g.stroke();
    }
    return c;
  }
  draw(ctx, cam, W, H) {
    const now = performance.now() / 1000, k = this.suck;
    const hue = 232 + 40 * Math.sin(now / 55 + cam.x / 7000) + 25 * Math.sin(cam.y / 5200);   // 위치와 시간에 따라 색조 변화
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, 'hsl(' + hue + ',55%,5%)'); g.addColorStop(1, 'hsl(' + (hue + 35) + ',60%,8%)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const pull = (x, y, amt) => [x + (this.cx - x) * amt, y + (this.cy - y) * amt];
    const fade = 1 - k;
    if (fade > 0.01) {
      ctx.globalCompositeOperation = 'lighter';
      for (const n of this.nebs) {                                       // 성운
        const T = 1500, ox = -((cam.x * n.par) % T), oy = -((cam.y * n.par) % T), S = 520 * n.s;
        ctx.globalAlpha = 0.85 * fade;
        for (let tx = ox - T; tx < W + S; tx += T) for (let ty = oy - T; ty < H + S; ty += T) {
          let x = tx + n.x - S / 2, y = ty + n.y - S / 2;
          if (x > W || y > H || x + S < 0 || y + S < 0) continue;
          if (k > 0) [x, y] = pull(x, y, k * k);
          ctx.drawImage(this.neb[n.n], x, y, S, S);
        }
      }
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
      const F = this.far, par = 0.3, ox = -((cam.x * par) % F.tile), oy = -((cam.y * par) % F.tile);   // 행성
      for (let tx = ox - F.tile; tx < W + 200; tx += F.tile) for (let ty = oy - F.tile * 0.6; ty < H + 200; ty += F.tile * 0.6) {
        for (const it of F.items) {
          const S = 220 * it.s * 0.8; let x = tx + it.x - S / 2, y = ty + it.y * 0.6 - S / 2;
          if (x > W || y > H || x + S < 0 || y + S < 0) continue;
          if (k > 0) [x, y] = pull(x, y, k * k);
          ctx.globalAlpha = 0.9 * fade; ctx.drawImage(this.planets[it.p], x, y, S, S);
        }
      }
      ctx.globalAlpha = 1;
    }
    for (const L of this.layers) {
      const ox = -(((cam.x * L.parallax) % L.tile) + L.tile) % L.tile;
      const oy = -(((cam.y * L.parallax) % L.tile) + L.tile) % L.tile;
      for (let tx = ox - L.tile; tx < W; tx += L.tile) {
        for (let ty = oy - L.tile; ty < H; ty += L.tile) {
          for (const s of L.stars) {
            let x = tx + s.x, y = ty + s.y;
            if (k > 0) [x, y] = pull(x, y, Math.min(1, k * (0.6 + L.parallax) * 1.4));
            if (x < -4 || x > W + 4 || y < -4 || y > H + 4) continue;
            const tw = 0.75 + 0.25 * Math.sin(now * s.sp + s.ph);       // 반짝임
            ctx.fillStyle = s.warm ? 'rgba(255,225,190,' + (L.alpha * tw * (1 - k * 0.6)) + ')' : 'rgba(200,220,255,' + (L.alpha * tw * (1 - k * 0.6)) + ')';
            const sz = L.size * (1 + k * 1.5);
            ctx.fillRect(x, y, sz, sz);
          }
        }
      }
    }
    if (k > 0) { ctx.fillStyle = 'rgba(0,0,0,' + Math.min(1, k * k * 1.1) + ')'; ctx.fillRect(0, 0, W, H); }
  }
}
