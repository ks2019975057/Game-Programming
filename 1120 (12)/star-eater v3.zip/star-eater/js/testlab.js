'use strict';
/* testlab.js - 디버그 실험실 (?debug=1 에서 Q 키)
   적 스폰을 멈추고, 허수아비(체력 무한, 안 움직임)를 세워 놓고, 무기 레벨과 진화를 마음대로 바꿔 보는 도구입니다.
   Q 열기/닫기 · [ ] 무기 선택 · , . 레벨 -/+ (없으면 추가, 1에서 -는 제거) · ; ' 진화 이전/다음 (없음 포함)
   1 허수아비 세우기 · 2 허수아비 치우기 · 3 적 스폰/보스 타이머 멈춤 토글 · 4 무기 전부 5레벨 · Backspace 무기 전부 제거 (WASD 이동과 안 겹치게 숫자 키 사용) */
const TestLab = {
  labOpen() { return !!(this.lab && this.lab.open); },
  labStopped() { return !!(this.lab && this.lab.noSpawn); },

  labKey(code) {
    if (code === 'KeyQ') {
      if (!this.lab) this.lab = { open: false, sel: 0, noSpawn: false, win: [], dealt: 0 };
      this.lab.open = !this.lab.open;
      if (this.lab.open) { this.godMode = true; this.lab.noSpawn = true; this.notify('실험실: 적 스폰 중단 · 무적 켜짐'); }
      return true;
    }
    if (!this.labOpen()) return false;
    const L = this.lab, p = this.player, ids = CONFIG.weaponOrder, id = ids[L.sel];
    const w = p.getWeapon(id);
    const evos = CONFIG.evolutions.filter((e) => e.target === id);
    switch (code) {
      case 'BracketRight': L.sel = (L.sel + 1) % ids.length; break;
      case 'BracketLeft': L.sel = (L.sel + ids.length - 1) % ids.length; break;
      case 'Period':
        if (!w) p.weapons.push(new WEAPON_CLASSES[id](this));
        else if (w.evo) break;
        else w.levelUp();
        break;
      case 'Comma':
        if (!w) break;
        if (w.evo) { w.evo = null; w.refresh(); break; }
        if (w.level <= 1) { p.weapons.splice(p.weapons.indexOf(w), 1); break; }
        w.level--; w.refresh();
        break;
      case 'Semicolon': case 'Quote': {
        const cur = w && w.evo ? evos.findIndex((e) => e.id === w.evo.id) : -1;      // -1 = 진화 없음
        const n = evos.length + 1, k = ((cur + 1 + (code === 'Quote' ? 1 : -1)) % n + n) % n - 1;
        if (k < 0) { if (w && w.evo) { w.evo = null; w.refresh(); } }
        else this.debugEvolve(evos[k].id);
        break;
      }
      case 'Digit1': this.labDummies(); break;
      case 'Digit2': for (const e of this.enemies) if (e.dummy) e.dead = true; break;
      case 'Digit3': L.noSpawn = !L.noSpawn; this.notify(L.noSpawn ? '적 스폰 중단' : '적 스폰 재개'); break;
      case 'Digit4': for (const wid of ids) { let q = p.getWeapon(wid); if (!q) { q = new WEAPON_CLASSES[wid](this); p.weapons.push(q); } while (!q.isLv5) q.levelUp(); } break;
      case 'Backspace': p.weapons.length = 0; break;
      default: return false;
    }
    return true;
  },

  /* 허수아비: 사방 고리 8마리 + 한 곳에 뭉친 4마리 */
  labDummies() {
    const p = this.player;
    for (const e of this.enemies) if (e.dummy) e.dead = true;
    const add = (x, y, big) => {
      const e = new Enemy(x, y, big ? 'tanker' : 'basic', 0);
      e.dummy = true; e.immovable = true; e.ccImmune = false; e.maxHp = e.hp = 1e9; e.speed = 0; e.contact = 0; e.contact0 = 0; e.defense = 0;
      this.enemies.push(e);
    };
    for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU; add(p.x + Math.cos(a) * 190, p.y + Math.sin(a) * 190, i % 4 === 0); }
    for (const o of [[-12, -12], [12, -12], [-12, 12], [12, 12]]) add(p.x + 330 + o[0], p.y + o[1], false);
  },

  /* damageEnemy 가 허수아비에게 준 피해를 기록 → 최근 5초 평균 DPS */
  labLog(dmg) {
    if (!this.lab) return;
    this.lab.win.push([this.time, dmg]);
  },
  labDps() {
    const L = this.lab, t = this.time;
    while (L.win.length && t - L.win[0][0] > 5) L.win.shift();
    let s = 0; for (const a of L.win) s += a[1];
    return s / 5;
  },

  drawLab(ctx, cam) {
    if (!this.lab) return;
    const L = this.lab;
    for (const e of this.enemies) {                                  // 허수아비 표시
      if (!e.dummy || e.dead || !this.onScreen(e.x, e.y, 40, cam)) continue;
      const x = e.x - cam.x, y = e.y - cam.y;
      ctx.strokeStyle = 'rgba(255,230,120,0.8)'; ctx.setLineDash([4, 4]); ctx.lineWidth = 1.5;
      ctx.beginPath(); ctx.arc(x, y, e.radius + 5, 0, TAU); ctx.stroke(); ctx.setLineDash([]);
    }
    if (!L.open) return;
    const p = this.player, ids = CONFIG.weaponOrder, id = ids[L.sel], w = p.getWeapon(id);
    const evos = CONFIG.evolutions.filter((e) => e.target === id);
    const x = 14, y = this.H * 0.28, wd = 262;
    ctx.fillStyle = 'rgba(8,10,24,0.85)'; ctx.fillRect(x, y, wd, 196);
    ctx.strokeStyle = 'rgba(255,214,90,0.8)'; ctx.lineWidth = 1; ctx.strokeRect(x, y, wd, 196);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillStyle = '#ffd65a'; ctx.font = 'bold 14px ' + FONT; ctx.fillText('실험실  (Q 닫기)', x + 10, y + 16);
    ctx.fillStyle = U.rgba(CONFIG.weapons[id].color, 1); ctx.font = 'bold 16px ' + FONT;
    ctx.fillText('[ ]  ' + CONFIG.weaponNames[id], x + 10, y + 42);
    ctx.fillStyle = '#fff'; ctx.font = '13px ' + FONT;
    ctx.fillText(', .  레벨: ' + (!w ? '없음' : w.evo ? '진화 (5)' : w.level + (w.isLv5 ? ' (MAX)' : '')), x + 10, y + 64);
    ctx.fillText('; \'  진화: ' + (w && w.evo ? w.evo.name : '없음') + '  (' + evos.map((e) => e.name).join(', ') + ')', x + 10, y + 86, wd - 20);
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    ctx.fillText('1 허수아비  2 치우기  3 스폰 ' + (L.noSpawn ? '멈춤' : '켜짐'), x + 10, y + 112);
    ctx.fillText('4 전부 MAX  Backspace 전부 제거', x + 10, y + 132);
    ctx.fillStyle = '#7fe0ff'; ctx.font = 'bold 18px ' + FONT;
    ctx.fillText('허수아비 DPS(5초) ' + Math.round(this.labDps()), x + 10, y + 164);
    ctx.fillStyle = 'rgba(255,255,255,0.6)'; ctx.font = '11px ' + FONT;
    ctx.fillText('보유 무기 ' + p.weapons.length + ' / ' + CONFIG.maxWeaponSlots, x + 10, y + 184);
  },
};
