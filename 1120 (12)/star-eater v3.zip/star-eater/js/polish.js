'use strict';
/* polish.js - 연출과 이벤트
   - MAX/진화 연출, 플레이어 강조 오라
   - 이벤트 웨이브 (무더기·압박·포위)
   - 엔딩 (배경이 플레이어에게 빨려 들어가 검은 화면만 남음)
   Object.assign(Game.prototype, Polish) 로 합쳐지며, 같은 이름의 Game 메서드(drawPlayer)는 이쪽이 덮어씁니다. */
const Polish = {
  initPolish() {
    this.evT = CONFIG.events.first; this.evN = 0; this.evLast = '';
    this.flash = null; this.banner = null; this.ending = null; this.auraT = 0; this.lab = null;
    if (this.bg) this.bg.suck = 0;
  },

  /* ---------- 무기 MAX / 진화 연출 ---------- */
  weaponMaxFx(w) {
    const p = this.player; if (!p || this.bench) return;
    const c = w.cfg.color;
    this.fx.ring(p.x, p.y, 70, c, 0.5); this.fx.ring(p.x, p.y, 110, [255, 255, 255], 0.6);
    this.fx.burst(p.x, p.y, c, 22, 240, 0.6, 3);
    this.banner = { t: 1.6, max: 1.6, text: w.cfg.name + '  MAX', sub: '피해 +' + Math.round((CONFIG.balance.lv5.damage - 1) * 100) + '% · 쿨타임 -' + Math.round((1 - CONFIG.balance.lv5.cooldown) * 100) + '%', color: c };
    Sound.play('card');
  },
  evolveFx(w) {
    const p = this.player, c = w.cfg.color, gold = [255, 214, 90];
    if (this.bench) return;
    for (let i = 0; i < 4; i++) this.fx.ring(p.x, p.y, 70 + i * 55, i % 2 ? c : gold, 0.5 + i * 0.15);
    this.fx.burst(p.x, p.y, gold, 40, 340, 0.9, 5); this.fx.burst(p.x, p.y, c, 40, 280, 0.9, 4);
    this.shake = Math.max(this.shake, 14);
    this.flash = { t: 0.55, max: 0.55, color: '255,236,170' };
    this.banner = { t: 2.4, max: 2.4, text: '★ ' + (w.evo ? w.evo.name : '') + ' ★', sub: '진화! 피해 +' + Math.round((CONFIG.balance.evo.damage - 1) * 100) + '% · 쿨타임 -' + Math.round((1 - CONFIG.balance.evo.cooldown) * 100) + '%', color: gold };
    Sound.play('evolve');
  },

  updatePolish(dt) {
    if (this.flash) { this.flash.t -= dt; if (this.flash.t <= 0) this.flash = null; }
    if (this.banner) { this.banner.t -= dt; if (this.banner.t <= 0) this.banner = null; }
    this.auraT += dt;
    const p = this.player;
    for (const w of p.weapons) {                       // 진화 무기는 반짝이는 입자를 계속 흘림
      if (!w.evo || Math.random() > dt * 9) continue;
      const a = Math.random() * TAU, r = 18 + Math.random() * 16;
      this.fx.burst(p.x + Math.cos(a) * r, p.y + Math.sin(a) * r, Math.random() < 0.5 ? w.cfg.color : [255, 224, 140], 1, 36, 0.55, 3);
    }
    this.updateEvents(dt);
  },

  /* ---------- 플레이어: 적과 확실히 구분되는 모양 ---------- */
  drawPlayer(ctx, cam) {
    const p = this.player, x = p.x - cam.x, y = p.y - cam.y, t = this.auraT;
    const pulse = 1 + 0.08 * Math.sin(t * 4);
    ctx.drawImage(Glow.get([120, 210, 255], 48), x - 64 * pulse, y - 64 * pulse, 128 * pulse, 128 * pulse);      // 넓은 푸른 빛
    ctx.drawImage(Glow.get([255, 255, 255], 20), x - 26, y - 26, 52, 52);
    // 회전하는 이중 고리
    ctx.save(); ctx.translate(x, y);
    ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(140,225,255,0.9)'; ctx.setLineDash([10, 8]);
    ctx.rotate(t * 1.2); ctx.beginPath(); ctx.arc(0, 0, p.radius + 9, 0, TAU); ctx.stroke();
    ctx.setLineDash([4, 10]); ctx.strokeStyle = 'rgba(255,255,255,0.75)';
    ctx.rotate(-t * 2.2); ctx.beginPath(); ctx.arc(0, 0, p.radius + 15, 0, TAU); ctx.stroke();
    ctx.setLineDash([]); ctx.restore();
    // MAX/진화 무기 하나당 궤도를 도는 빛 (진화는 금색 별 + 겹고리)
    let i = 0;
    for (const w of p.weapons) {
      if (!w.maxed) continue;
      const a = t * 2 + i * 1.05, R = p.radius + 24;
      const ox = x + Math.cos(a) * R, oy = y + Math.sin(a) * R, c = w.cfg.color;
      ctx.drawImage(Glow.get(c, 14), ox - 14, oy - 14, 28, 28);
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(ox, oy, w.evo ? 3.2 : 2.2, 0, TAU); ctx.fill();
      if (w.evo) { ctx.strokeStyle = 'rgba(255,214,90,0.85)'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(ox, oy, 6, 0, TAU); ctx.stroke(); }
      i++;
    }
    if (p.weapons.some((w) => w.evo)) {                // 진화 무기가 있으면 금빛 외곽 고리
      ctx.strokeStyle = 'rgba(255,214,90,' + (0.45 + 0.25 * Math.sin(t * 5)) + ')'; ctx.lineWidth = 2.5;
      ctx.beginPath(); ctx.arc(x, y, p.radius + 31, 0, TAU); ctx.stroke();
    }
    // 본체: 검은 테두리 + 흰 핵 + 푸른 중심
    const blink = p.invuln > 0 && Math.floor(p.invuln * 20) % 2 === 0;
    ctx.fillStyle = '#0a1230'; ctx.beginPath(); ctx.arc(x, y, p.radius + 2.5, 0, TAU); ctx.fill();
    ctx.fillStyle = blink ? 'rgba(255,255,255,0.4)' : '#ffffff'; ctx.beginPath(); ctx.arc(x, y, p.radius, 0, TAU); ctx.fill();
    ctx.fillStyle = blink ? 'rgba(120,200,255,0.3)' : '#6fd0ff'; ctx.beginPath(); ctx.arc(x, y, p.radius * 0.45, 0, TAU); ctx.fill();
  },

  drawBannerFlash(ctx) {
    const W = this.W, H = this.H;
    if (this.flash) { ctx.fillStyle = 'rgba(' + this.flash.color + ',' + (this.flash.t / this.flash.max * 0.55) + ')'; ctx.fillRect(0, 0, W, H); }
    const b = this.banner;
    if (b) {
      const k = b.t / b.max, a = Math.min(1, k * 3, (1 - k) * 8 + 0.2), y = H * 0.3 - 10 * (1 - k);
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.globalAlpha = Math.min(1, a);
      ctx.fillStyle = 'rgba(8,10,24,0.55)'; ctx.fillRect(W / 2 - 220, y - 34, 440, 74);
      ctx.fillStyle = U.rgba(b.color, 1); ctx.font = 'bold 30px ' + FONT; ctx.fillText(b.text, W / 2, y - 6);
      ctx.fillStyle = '#fff'; ctx.font = '14px ' + FONT; ctx.fillText(b.sub, W / 2, y + 24);
      ctx.globalAlpha = 1;
    }
  },

  /* ---------- 이벤트 웨이브 ---------- */
  updateEvents(dt) {
    const E = CONFIG.events;
    if (this.bench || this.bossPhase !== 'none' || this.ending || this.labStopped()) return;
    this.evT -= dt;
    if (this.evT > 0) return;
    if (this.bossTimer < 18) { this.evT = 6; return; }                    // 보스 직전에는 쉼
    const min = this.growthTime / 60;
    this.fireEvent(min);
    this.evT = U.rand(E.gapMin, E.gapMax) * (1 - Math.min(0.35, min * 0.03));
  },
  evPos(a, d) { const p = this.player; return [p.x + Math.cos(a) * d, p.y + Math.sin(a) * d]; },
  evAdd(type, a, d, min) {
    if (this.enemies.length >= CONFIG.events.maxEnemies) return;
    const [x, y] = this.evPos(a, d);
    this.enemies.push(new Enemy(x, y, type, min));
  },
  fireEvent(min) {
    const kinds = ['swarm', 'press', 'ring'].filter((k) => k !== this.evLast);
    const kind = kinds[Math.floor(Math.random() * kinds.length)];
    this.evLast = kind; this.evN++;
    const d = Math.hypot(this.W, this.H) / 2 + 70;
    this.fx.ring(this.player.x, this.player.y, 160, [255, 90, 90], 0.6);
    this.flash = { t: 0.35, max: 0.35, color: '255,70,70' };
    Sound.play('bossWarn');
    if (kind === 'swarm') {                                               // 한 방향에서 기본 적이 무더기로 몰려옴
      this.notify('⚠ 적 떼 습격!');
      const a0 = Math.random() * TAU, n = Math.round(34 + min * 7);
      for (let i = 0; i < n; i++) this.evAdd('basic', a0 + U.rand(-0.7, 0.7), d + U.rand(0, 140), min);
    } else if (kind === 'ring') {                                         // 사방에서 포위해 좁혀 옴
      this.notify('⚠ 포위당했다!');
      const n = Math.round(30 + min * 3);
      for (let i = 0; i < n; i++) this.evAdd(i % 5 === 0 && min >= 1 ? this.pickType(min) : 'basic', (i * TAU) / n, d, min);
    } else {                                                              // 특수 적 한 종이 압박
      const pool = CONFIG.specials.types.filter((t) => min >= t.unlock - 0.5 && t.id !== 'healer');
      pool.push({ id: 'charger' }, { id: 'archer' });
      const id = pool[Math.floor(Math.random() * pool.length)].id;
      const big = id === 'tanker' || id === 'devourer' || id === 'anchor';
      const n = Math.round((big ? 7 : 16) + min * (big ? 0.8 : 2));
      this.notify('⚠ ' + CONFIG.enemies[id].name + ' 무리 출현!');
      const a0 = Math.random() * TAU;
      for (let i = 0; i < n; i++) this.evAdd(id, a0 + (i - n / 2) * (id === 'archer' ? 0.18 : 0.1), d + (i % 3) * 36, min);
    }
  },

  /* ---------- 엔딩: 배경이 플레이어에게 빨려 들어감 ---------- */
  startEnding() {
    if (this.ending || this.state === 'clear') return;
    const p = this.player;
    this.state = 'ending'; this.ending = { t: 0, dur: 8 };
    Sound.setTrack(null); Sound.play('bossDeath');
    for (const e of this.enemies) if (!e.dead) { e.dead = true; this.fx.burst(e.x, e.y, e.color, 4, 140, 0.5, 3); }
    this.enemyBullets.length = 0; this.projectiles.length = 0; this.items.length = 0;
    this.input.override = { x: 0, y: 0 };
    this.fx.ring(p.x, p.y, 240, [190, 140, 255], 1.2);
    this.notify('');
  },
  updateEnding(dt) {
    const E = this.ending, p = this.player;
    E.t += dt; this.fx.update(dt); this.auraT += dt;
    for (const g of this.gems) { g.attracted = true; g.speed = Math.max(g.speed, 500); }
    this.updateGems(dt); compact(this.gems);
    if (this.flash) { this.flash.t -= dt; if (this.flash.t <= 0) this.flash = null; }
    this.shake = E.t > 1.5 && E.t < 5 ? 3 : 0;
    this.bg.suck = U.clamp((E.t - 1) / 4.5, 0, 1);               // 1초 뒤부터 4.5초 동안 빨려 들어감
    if (E.t > 1.5 && E.t < 5.5 && Math.random() < dt * 40) {      // 빨려 들어가는 빛 입자
      const a = Math.random() * TAU, r = 300 + Math.random() * 300;
      this.fx.burst(p.x + Math.cos(a) * r, p.y + Math.sin(a) * r, [190, 160, 255], 1, 0, 0.8, 3);
    }
    if (E.t >= E.dur) { this.bg.suck = 0; this.ending = null; this.victory(); }
  },
  drawEnding(ctx) {
    const E = this.ending, W = this.W, H = this.H;
    if (E.t > 5.2) {                                               // 검은 화면에 플레이어만 남음 → 문구
      const a = U.clamp((E.t - 5.4) / 1.5, 0, 1);
      ctx.fillStyle = 'rgba(255,255,255,' + a + ')'; ctx.font = 'bold 26px ' + FONT; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText('우주의 모든 별을 먹었다', W / 2, H / 2 + 80);
      if (E.t > 7.2) { ctx.fillStyle = 'rgba(0,0,0,' + U.clamp((E.t - 7.2) / 0.8, 0, 1) + ')'; ctx.fillRect(0, 0, W, H); }
    }
  },
};

/* HUD 무기 아이콘: 글자 대신 무기의 특징을 살린 작은 그림 (cx, cy 중심, r 크기) */
function drawWeaponIcon(ctx, id, cx, cy, r, color, t) {
  const col = U.rgba(color, 1), soft = U.rgba(color, 0.35);
  ctx.save(); ctx.translate(cx, cy); ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = Math.max(1.5, r * 0.18);
  switch (id) {
    case 'spaceDust':                                   // 꼬리를 끄는 작은 탄 3발
      for (let i = 0; i < 3; i++) {
        const x = r * (0.7 - i * 0.55), y = r * (-0.55 + i * 0.55);
        ctx.globalAlpha = 1 - i * 0.2; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x - r * 0.9, y + r * 0.0); ctx.stroke();
        ctx.beginPath(); ctx.arc(x, y, r * 0.2, 0, TAU); ctx.fill();
      }
      break;
    case 'radiantHeat': {                               // 퍼져 나가는 펄스 고리
      const k = (t * 1.2) % 1;
      ctx.beginPath(); ctx.arc(0, 0, r * 0.28, 0, TAU); ctx.fill();
      ctx.globalAlpha = 0.9; ctx.beginPath(); ctx.arc(0, 0, r * (0.45 + 0.5 * k), 0, TAU); ctx.stroke();
      ctx.globalAlpha = 0.45; ctx.beginPath(); ctx.arc(0, 0, r * 0.95, 0, TAU); ctx.stroke();
      break;
    }
    case 'satellite': {                                 // 중심 + 타원 궤도 + 공전하는 점
      ctx.globalAlpha = 0.5; ctx.beginPath(); ctx.ellipse(0, 0, r, r * 0.45, -0.5, 0, TAU); ctx.stroke(); ctx.globalAlpha = 1;
      ctx.beginPath(); ctx.arc(0, 0, r * 0.22, 0, TAU); ctx.fill();
      const a = t * 2.4, x = Math.cos(a) * r, y = Math.sin(a) * r * 0.45, c = Math.cos(-0.5), s = Math.sin(-0.5);
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x * c - y * s, x * s + y * c, r * 0.2, 0, TAU); ctx.fill();
      break;
    }
    case 'meteor':                                      // 비스듬히 떨어지는 불덩이
      ctx.globalAlpha = 0.55; for (const o of [-0.35, 0, 0.35]) { ctx.beginPath(); ctx.moveTo(r * 0.15, -r * 0.15 + o * r * 0.5); ctx.lineTo(r * 1.0, -r * 1.0 + o * r * 0.5); ctx.stroke(); }
      ctx.globalAlpha = 1; ctx.beginPath(); ctx.arc(-r * 0.2, r * 0.2, r * 0.5, 0, TAU); ctx.fill();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(-r * 0.3, r * 0.1, r * 0.2, 0, TAU); ctx.fill();
      break;
    case 'atmosphere':                                  // 방패 모양 보호막
      ctx.beginPath(); ctx.moveTo(0, -r); ctx.quadraticCurveTo(r * 0.95, -r * 0.7, r * 0.8, r * 0.1); ctx.quadraticCurveTo(r * 0.5, r * 0.75, 0, r); ctx.quadraticCurveTo(-r * 0.5, r * 0.75, -r * 0.8, r * 0.1); ctx.quadraticCurveTo(-r * 0.95, -r * 0.7, 0, -r); ctx.closePath();
      ctx.fillStyle = soft; ctx.fill(); ctx.stroke();
      break;
    case 'comet':                                       // 머리와 긴 꼬리
      ctx.fillStyle = soft; ctx.beginPath(); ctx.moveTo(r * 0.5, -r * 0.4); ctx.lineTo(-r * 1.1, r * 0.9); ctx.lineTo(r * 0.1, -r * 0.7); ctx.closePath(); ctx.fill();
      ctx.beginPath(); ctx.moveTo(r * 0.3, -r * 0.3); ctx.lineTo(-r * 0.9, r * 0.6); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(r * 0.45, -r * 0.45, r * 0.38, 0, TAU); ctx.fill();
      ctx.strokeStyle = col; ctx.beginPath(); ctx.arc(r * 0.45, -r * 0.45, r * 0.38, 0, TAU); ctx.stroke();
      break;
    case 'blackHole': {                                 // 검은 구멍 + 소용돌이
      ctx.fillStyle = col;
      for (let i = 0; i < 3; i++) {
        ctx.globalAlpha = 0.9 - i * 0.2; ctx.beginPath();
        for (let k = 0; k <= 14; k++) { const q = k / 14, a = t * 2 + i * 2.09 + q * 3, rr = r * (1 - 0.7 * q); const x = Math.cos(a) * rr, y = Math.sin(a) * rr; if (k) ctx.lineTo(x, y); else ctx.moveTo(x, y); }
        ctx.stroke();
      }
      ctx.globalAlpha = 1; ctx.fillStyle = '#05030c'; ctx.beginPath(); ctx.arc(0, 0, r * 0.3, 0, TAU); ctx.fill(); ctx.stroke();
      break;
    }
    case 'plasma':                                      // 번개
      ctx.beginPath(); ctx.moveTo(r * 0.35, -r); ctx.lineTo(-r * 0.4, r * 0.1); ctx.lineTo(r * 0.1, r * 0.1); ctx.lineTo(-r * 0.35, r); ctx.stroke();
      ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(r * 0.35, -r, r * 0.16, 0, TAU); ctx.arc(-r * 0.35, r, r * 0.16, 0, TAU); ctx.fill();
      break;
    default: ctx.beginPath(); ctx.arc(0, 0, r * 0.5, 0, TAU); ctx.fill();
  }
  ctx.restore();
}
