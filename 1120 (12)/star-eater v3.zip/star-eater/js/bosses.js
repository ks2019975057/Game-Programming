'use strict';
/* bosses.js - 보스 6종 (분열, 돌진, 보호막, 탱커, 크리스탈, 블랙홀)
   보스는 일반 적과 같은 Enemy 객체이고, 동작은 ENEMY_TYPES 에 등록됩니다.
   e.dmgMul / e.pSpeedMul / e.intMul 은 "몇 번째 보스인가"에 따른 배율입니다. */

/* 보스 탄 한 발 */
function bossShot(g, e, x, y, ang, speed, extra) {
  const B = CONFIG.boss;
  const b = new EnemyBullet(x, y, ang, speed * e.pSpeedMul, B.bulletDamage * e.dmgMul, B.bulletRange);
  if (extra) Object.assign(b, extra);
  g.enemyBullets.push(b);
  return b;
}
function ringShot(g, e, x, y, n, a0, speed, skipFrom, skipCount) {
  for (let i = 0; i < n; i++) {
    let skip = false;
    for (let k = 0; k < (skipCount || 0); k++) if (i === ((skipFrom || 0) + k) % n) skip = true;
    if (!skip) bossShot(g, e, x, y, a0 + (i * TAU) / n, speed);
  }
}
/* 플레이어를 직접 노리는 탄: 어디에 서 있어도 안전한 자리가 생기지 않게 모든 패턴에 섞음 */
function aimedShots(g, e, x, y, n, spread, speed) {
  const base = Math.atan2(g.player.y - y, g.player.x - x);
  for (let i = 0; i < n; i++) bossShot(g, e, x, y, base + (i - (n - 1) / 2) * spread, speed);
}

/* ---------------- 1. 분열 ---------------- */
ENEMY_TYPES.bossSplit = {
  update(e, dt, g) {
    const A = g.arena, S = CONFIG.boss.split;
    if (e.vx === undefined) { const a = Math.random() * TAU; e.vx = Math.cos(a); e.vy = Math.sin(a); }
    const sp = S.speed[e.gen] * (1 + (e.pSpeedMul - 1));
    e.x += e.vx * sp * dt; e.y += e.vy * sp * dt;
    const r = e.radius;
    if (e.x - r < A.x0) { e.x = A.x0 + r; e.vx = Math.abs(e.vx); }
    if (e.x + r > A.x1) { e.x = A.x1 - r; e.vx = -Math.abs(e.vx); }
    if (e.y - r < A.y0) { e.y = A.y0 + r; e.vy = Math.abs(e.vy); }
    if (e.y + r > A.y1) { e.y = A.y1 - r; e.vy = -Math.abs(e.vy); }
    if (e.gen < S.gens - 1 && e.hp <= e.maxHp * S.threshold && !e.dead) this.split(e, g);
    return true;
  },
  split(e, g) {
    const S = CONFIG.boss.split, gen = e.gen + 1;
    e.dead = true;
    g.fx.burst(e.x, e.y, e.color, 20, 220, 0.6, 4);
    g.fx.ring(e.x, e.y, e.radius, e.color, 0.4);
    g.shake = Math.max(g.shake, 6);
    const a0 = Math.random() * TAU;
    for (let i = 0; i < 2; i++) {
      const c = g.makePiece(e, gen);
      const a = a0 + i * Math.PI;
      c.x = e.x + Math.cos(a) * e.radius * 0.5; c.y = e.y + Math.sin(a) * e.radius * 0.5;
      c.vx = Math.cos(a); c.vy = Math.sin(a);
      g.enemies.push(c);
    }
    ringShot(g, e, e.x, e.y, S.bullets, a0 + 0.3, S.bulletSpeed);
    aimedShots(g, e, e.x, e.y, 2, 0.2, S.bulletSpeed);
  },
  draw(ctx, e, x, y) {
    circle(ctx, e, x, y);
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = Math.max(1, e.radius / 30); ctx.beginPath();
    const r = e.radius;
    ctx.moveTo(x - r * 0.2, y - r); ctx.lineTo(x + r * 0.15, y - r * 0.3); ctx.lineTo(x - r * 0.25, y + r * 0.1); ctx.lineTo(x + r * 0.2, y + r);
    ctx.moveTo(x + r * 0.15, y - r * 0.3); ctx.lineTo(x + r, y - r * 0.1);
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, r + 3, 0, TAU); ctx.stroke();
  },
};

/* ---------------- 2. 돌진 ---------------- */
ENEMY_TYPES.bossCharge = {
  init(e) { e.state = 'idle'; e.t = 0.8; e.dashAng = 0; e.dashLeft = 0; e.dashing = false; e.takeMul = 1; e.stunned = false; e.dashN = 0; },
  update(e, dt, g) {
    const b = e.base, p = g.player, A = g.arena;
    if (e.state === 'idle') {
      e.t -= dt;
      if (e.t <= 0) { e.state = 'warn'; e.t = b.warn * e.intMul; e.dashAng = Math.atan2(p.y - e.y, p.x - e.x); }
    } else if (e.state === 'warn') {
      e.t -= dt; e.ang = e.dashAng;
      if (e.t <= 0) { e.state = 'dash'; e.dashing = true; e.dashN++; e.dashLeft = e.dashN >= 3 ? 1e9 : b.dashDist; }   // 두 번 헛돌진한 뒤엔 벽까지 달림
    } else if (e.state === 'dash') {
      const step = Math.min(b.dashSpeed * e.pSpeedMul * dt, e.dashLeft);
      e.x += Math.cos(e.dashAng) * step; e.y += Math.sin(e.dashAng) * step; e.dashLeft -= step;
      const r = e.radius;
      const hitWall = e.x - r <= A.x0 || e.x + r >= A.x1 || e.y - r <= A.y0 || e.y + r >= A.y1;
      e.x = U.clamp(e.x, A.x0 + r, A.x1 - r); e.y = U.clamp(e.y, A.y0 + r, A.y1 - r);
      if (hitWall) {                                   // 벽에 쾅 → 기절, 잔해가 떨어짐
        e.state = 'stun'; e.dashN = 0; e.t = b.stun; e.dashing = false; e.takeMul = b.stunTaken; e.stunned = true;
        g.shake = 12; g.fx.ring(e.x, e.y, 140, [255, 200, 120], 0.5); g.fx.burst(e.x, e.y, e.color, 24, 260, 0.6, 4);
        for (let i = 0; i < b.debris; i++) bossShot(g, e, U.rand(A.x0 + 30, A.x1 - 30), A.y0 + 4, Math.PI / 2 + U.rand(-0.15, 0.15), 220);
      } else if (e.dashLeft <= 0) { e.state = 'idle'; e.t = 0.5; e.dashing = false; }   // 벽에 못 닿았으면 다시 경고 후 돌진
    } else if (e.state === 'stun') {
      e.t -= dt;
      if (e.t <= 0) { e.state = 'recover'; e.t = b.recover; e.takeMul = 1; e.stunned = false; }   // 이 동안은 기절 면역
    } else {
      e.t -= dt;
      if (e.t <= 0) { e.state = 'idle'; e.t = 0.4; }
    }
    return true;
  },
  draw(ctx, e, x, y) {
    const b = e.base;
    if (e.state === 'warn') {
      const k = 1 - e.t / (b.warn * e.intMul);
      ctx.strokeStyle = 'rgba(255,70,70,' + (0.3 + 0.5 * k) + ')'; ctx.lineWidth = 6 + 18 * k;
      ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(e.dashAng) * 2000, y + Math.sin(e.dashAng) * 2000); ctx.stroke();
    }
    const r = e.radius;
    ctx.save(); ctx.translate(x, y); ctx.rotate(e.ang);
    ctx.fillStyle = e.stunned ? (e.flash > 0 ? '#fff' : 'rgb(150,90,90)') : bodyColor(e); ctx.fillRect(-r, -r, r * 2, r * 2);
    ctx.strokeStyle = e.dashing ? '#fff' : 'rgba(0,0,0,0.55)'; ctx.lineWidth = 4; ctx.strokeRect(-r, -r, r * 2, r * 2);
    ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(r * 0.15, -r * 0.5, r * 0.55, r * 0.25); ctx.fillRect(r * 0.15, r * 0.25, r * 0.55, r * 0.25);
    ctx.restore();
    if (e.stunned) {                                    // 기절 표시
      const t = performance.now() / 300;
      for (let i = 0; i < 3; i++) { const a = t + i * 2.1; ctx.fillStyle = '#ffe680'; ctx.beginPath(); ctx.arc(x + Math.cos(a) * 32, y - r - 14 + Math.sin(a) * 6, 4, 0, TAU); ctx.fill(); }
    }
  },
  filter(e, g, amount) { return amount * e.takeMul; },
};

/* ---------------- 3. 보호막 ---------------- */
ENEMY_TYPES.bossShield = {
  init(e) { e.state = 'guard'; e.orbit = 0; e.t = 0; e.fireT = 1.5; e.rot = 0; e.sats = []; },
  spawnSats(e, g) {
    const b = e.base, hp = e.maxHp * b.satHpRatio;
    e.sats = [];
    for (let i = 0; i < b.sats; i++) {
      const s = new Enemy(e.x, e.y, 'bossSat', 0);
      s.maxHp = s.hp = hp; s.parent = e; s.idx = i; s.bossPart = true;
      s.ccImmune = true; s.immovable = true; s.contact = CONFIG.boss.contact * 0.5 * e.dmgMul;
      e.sats.push(s); g.enemies.push(s);
    }
  },
  update(e, dt, g) {
    const b = e.base, p = g.player;
    e.orbit += (b.orbitSpeed * Math.PI / 180) * dt;
    if (e.state === 'guard') {
      if (e.sats.length && e.sats.every((s) => s.dead)) { e.state = 'open'; e.t = b.open; g.notify('방벽 파괴! 지금이 기회다'); g.fx.ring(e.x, e.y, 120, [255, 225, 80], 0.6); }
    } else {
      e.t -= dt;
      if (e.t <= 0) { e.state = 'guard'; this.spawnSats(e, g); }
    }
    e.fireT -= dt;
    if (e.fireT <= 0) {                                 // 12방향 회전 탄막
      ringShot(g, e, e.x, e.y, b.dirs, Math.random() * TAU, 150);       // 매번 무작위 각도라 안전한 틈이 고정되지 않음
      aimedShots(g, e, e.x, e.y, 3, 0.22, 170);
      e.fireT = b.fireGap * e.intMul;
    }
    e.ang += dt * 0.5;
    return true;
  },
  satUpdate(s, dt, g) {
    const P = s.parent, b = P.base;
    if (P.dead) { s.dead = true; return true; }
    const a = P.orbit + (s.idx * TAU) / b.sats;
    s.x = P.x + Math.cos(a) * b.orbit; s.y = P.y + Math.sin(a) * b.orbit;
    return true;
  },
  onDeath(e, g) { for (const s of e.sats) s.dead = true; },
  filter(e, g, amount, kind) { return (e.state === 'guard' && kind !== 'area') ? 0 : amount; },   // 위성이 투사체/선 공격을 흡수
  draw(ctx, e, x, y) {
    const r = e.radius;
    if (e.state === 'guard') { ctx.strokeStyle = 'rgba(255,225,80,0.18)'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(x, y, e.base.orbit, 0, TAU); ctx.stroke(); }
    ctx.fillStyle = bodyColor(e); ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill(); outline(ctx);
    ctx.strokeStyle = e.state === 'open' ? 'rgba(255,255,255,0.9)' : 'rgba(255,225,80,0.9)'; ctx.lineWidth = 4;
    ctx.beginPath(); ctx.arc(x, y, r * 0.55, 0, TAU); ctx.stroke();
    if (e.state === 'open') { ctx.fillStyle = 'rgba(255,255,255,' + (0.2 + 0.2 * Math.sin(performance.now() / 80)) + ')'; ctx.beginPath(); ctx.arc(x, y, r + 8, 0, TAU); ctx.fill(); }
  },
};
ENEMY_TYPES.bossSat = {
  update(s, dt, g) { return ENEMY_TYPES.bossShield.satUpdate(s, dt, g); },
  draw(ctx, s, x, y) {
    ctx.drawImage(Glow.get(s.color, 24), x - 34, y - 34, 68, 68);
    ctx.fillStyle = bodyColor(s); ctx.beginPath(); ctx.arc(x, y, s.radius, 0, TAU); ctx.fill(); outline(ctx);
    ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(x - 18, y + s.radius + 4, 36, 4);
    ctx.fillStyle = '#ffe650'; ctx.fillRect(x - 18, y + s.radius + 4, 36 * Math.max(0, s.hp / s.maxHp), 4);
  },
};

/* ---------------- 4. 탱커 ---------------- */
ENEMY_TYPES.bossTank = {
  init(e) { e.state = 'tele'; e.t = e.base.tele; e.open = Math.floor(Math.random() * e.base.sections); e.waveT = 2; e.angW = 0; },
  update(e, dt, g) {
    const b = e.base, p = g.player;
    e.t -= dt;
    if (e.t <= 0) {
      if (e.state === 'tele') { e.state = 'open'; e.t = b.open; }
      else {                                            // 다음 약점은 다른 구역
        let n; do { n = Math.floor(Math.random() * b.sections); } while (n === e.open);
        e.open = n; e.state = 'tele'; e.t = b.tele;
      }
    }
    e.chase(dt, p, 1);                                  // 느리게 추격
    const A = g.arena, r = e.radius;
    e.x = U.clamp(e.x, A.x0 + r, A.x1 - r); e.y = U.clamp(e.y, A.y0 + r, A.y1 - r);
    e.waveT -= dt;
    if (e.waveT <= 0) {                                 // 지면 충격파: 틈이 있는 탄 고리
      g.shake = Math.max(g.shake, 6); g.fx.ring(e.x, e.y, 100, [200, 215, 255], 0.5);
      ringShot(g, e, e.x, e.y, b.waveDirs, Math.random() * TAU, b.waveSpeed, Math.floor(Math.random() * b.waveDirs), b.waveGapDirs);
      aimedShots(g, e, e.x, e.y, 3, 0.2, 200);
      e.waveT = b.waveGap * e.intMul;
    }
    return true;
  },
  sector(e, hx, hy) {
    const a = Math.atan2(hy - e.y, hx - e.x);
    return Math.floor(((a + Math.PI) / TAU) * e.base.sections) % e.base.sections;
  },
  filter(e, g, amount, kind, hx, hy) {                  // 열린 약점 구역에 맞은 공격만 피해
    return (e.state === 'open' && this.sector(e, hx, hy) === e.open) ? amount : 0;
  },
  draw(ctx, e, x, y) {
    const r = e.radius, n = e.base.sections;
    ctx.fillStyle = bodyColor(e); ctx.fillRect(x - r, y - r, r * 2, r * 2);
    ctx.strokeStyle = 'rgba(0,0,0,0.6)'; ctx.lineWidth = 4; ctx.strokeRect(x - r, y - r, r * 2, r * 2);
    ctx.strokeStyle = 'rgba(200,215,255,0.25)'; ctx.lineWidth = 1;     // 구역선
    for (let i = 0; i < n; i++) { const a = -Math.PI + (i * TAU) / n; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(a) * r * 1.5, y + Math.sin(a) * r * 1.5); ctx.stroke(); }
    const a0 = -Math.PI + (e.open * TAU) / n, a1 = a0 + TAU / n;      // 약점 구역
    const open = e.state === 'open', k = open ? 1 : 0.35 + 0.35 * Math.sin(performance.now() / 70);
    ctx.fillStyle = open ? 'rgba(120,255,150,0.55)' : 'rgba(255,230,120,' + (0.25 * k) + ')';
    ctx.beginPath(); ctx.moveTo(x, y); ctx.arc(x, y, r * 1.45, a0, a1); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = open ? '#7dff9a' : 'rgba(255,230,120,0.8)'; ctx.lineWidth = 3;
    ctx.beginPath(); ctx.arc(x, y, r * 1.45, a0, a1); ctx.stroke();
  },
};

/* ---------------- 5. 크리스탈 ---------------- */
ENEMY_TYPES.bossCrystal = {
  init(e) { e.state = 'off'; e.t = 1.5; e.la = Math.random() * TAU; e.spiralT = 2; e.burst = 0; e.emitT = 0; e.sa = 0; },
  beams(e) { return [e.la]; },                                   // 레이저는 한 줄
  update(e, dt, g) {
    const b = e.base, p = g.player;
    e.t -= dt;
    if (e.state === 'off' && e.t <= 0) { e.state = 'warn'; e.t = b.laserWarn; }
    else if (e.state === 'warn' && e.t <= 0) { e.state = 'on'; e.t = b.laserOn; }
    else if (e.state === 'on') {
      e.la += (b.laserSpeed * Math.PI / 180) * e.pSpeedMul * dt;
      for (const a of this.beams(e)) {
        const d = Math.abs(Math.cos(a) * (p.y - e.y) - Math.sin(a) * (p.x - e.x));
        if (d <= b.laserWidth + p.radius && p.invuln <= 0 && p.takeDamage(b.laserDamage * e.dmgMul)) g.hurtFx();
      }
      if (e.t <= 0) { e.state = 'off'; e.t = b.laserOff * e.intMul; }
    }
    e.spiralT -= dt;                                    // 나선 탄막
    if (e.spiralT <= 0 && e.burst <= 0) { e.sa = Math.random() * TAU; aimedShots(g, e, e.x, e.y, 3, 0.25, 200); e.burst = b.spiralTime; e.spiralT = b.spiralGap * e.intMul + b.spiralTime; }
    if (e.burst > 0) {
      e.burst -= dt; e.emitT -= dt;
      while (e.emitT <= 0) {
        e.emitT += b.spiralEmit;
        for (let k = 0; k < b.spiralArms; k++) bossShot(g, e, e.x, e.y, e.sa + (k * TAU) / b.spiralArms, b.spiralSpeed);
        e.sa += (b.spiralStep * Math.PI) / 180;
      }
    }
    e.ang += dt * 0.4;
    return true;
  },
  draw(ctx, e, x, y) {
    const b = e.base, r = e.radius;
    if (e.state === 'warn' || e.state === 'on') {
      const warn = e.state === 'warn';
      for (const a of this.beams(e)) {
        const dx = Math.cos(a) * 2400, dy = Math.sin(a) * 2400;
        ctx.lineCap = 'butt';
        if (warn) { ctx.strokeStyle = 'rgba(120,230,255,' + (0.25 + 0.4 * (1 - e.t / b.laserWarn)) + ')'; ctx.lineWidth = 2; ctx.setLineDash([14, 10]); }
        else { ctx.strokeStyle = 'rgba(120,230,255,0.35)'; ctx.lineWidth = b.laserWidth * 2.6; ctx.setLineDash([]);
          ctx.beginPath(); ctx.moveTo(x - dx, y - dy); ctx.lineTo(x + dx, y + dy); ctx.stroke();
          ctx.strokeStyle = '#ffffff'; ctx.lineWidth = b.laserWidth * 0.7; }
        ctx.beginPath(); ctx.moveTo(x - dx, y - dy); ctx.lineTo(x + dx, y + dy); ctx.stroke(); ctx.setLineDash([]);
      }
    }
    ctx.drawImage(Glow.get(e.color, 40), x - r * 2, y - r * 2, r * 4, r * 4);
    ctx.fillStyle = bodyColor(e);
    ctx.beginPath(); ctx.moveTo(x, y - r * 1.3); ctx.lineTo(x + r * 0.9, y); ctx.lineTo(x, y + r * 1.3); ctx.lineTo(x - r * 0.9, y); ctx.closePath(); ctx.fill(); outline(ctx);
    ctx.strokeStyle = 'rgba(255,255,255,0.7)'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(x, y - r * 1.3); ctx.lineTo(x, y + r * 1.3); ctx.moveTo(x - r * 0.9, y); ctx.lineTo(x + r * 0.9, y); ctx.stroke();
  },
};

/* ---------------- 6. 블랙홀 (최종) ---------------- */
ENEMY_TYPES.bossHole = {
  init(e) { e.spawnT = 1; e.spin = 0; },
  update(e, dt, g) {
    const b = e.base, p = g.player, A = g.arena;
    e.spin += dt * 2;
    const dx = e.x - p.x, dy = e.y - p.y, d = Math.hypot(dx, dy) || 1;
    const pull = b.pull * (e.hp < e.maxHp * 0.5 ? b.pullEnraged : 1);
    p.x += (dx / d) * pull * dt; p.y += (dy / d) * pull * dt;               // 천천히 끌려옴
    if (d <= e.radius + p.radius) {                                       // 중심에 닿으면 초당 피해
      p.hp -= b.drainPerSec * e.dmgMul * dt; g.hitFlash = Math.max(g.hitFlash, 0.15);
    }
    e.spawnT -= dt;
    if (e.spawnT <= 0) {                                                  // 맵 바깥에서 소용돌이 모양으로 탄이 빨려 들어옴
      e.spawnT = b.spawnGap * e.intMul;
      const R = Math.hypot(A.x1 - A.x0, A.y1 - A.y0) / 2 + 40;
      e.vth = (e.vth || 0) + 0.55;                                       // 발사 각도가 조금씩 돌아 나선 팔이 만들어짐
      for (let i = 0; i < b.spawnCount; i++) {
        const th = e.vth + (i * TAU) / b.spawnCount;
        bossShot(g, e, e.x + Math.cos(th) * R, e.y + Math.sin(th) * R, 0, b.bulletSpeed, { vortex: { r: R, th, dir: 1 }, life: 16, tail: true });
      }
    }
    return true;
  },
  draw(ctx, e, x, y) {
    const r = e.radius, t = e.spin;
    ctx.drawImage(Glow.get(e.color, 64), x - r * 3, y - r * 3, r * 6, r * 6);
    for (let i = 0; i < 4; i++) {
      ctx.strokeStyle = 'rgba(190,140,255,' + (0.7 - i * 0.12) + ')'; ctx.lineWidth = 3;
      ctx.beginPath();
      for (let k = 0; k <= 20; k++) { const q = k / 20, a = t + i * Math.PI / 2 + q * 3.2, rr = r * (2.2 - 1.6 * q); const px = x + Math.cos(a) * rr, py = y + Math.sin(a) * rr; if (k === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); }
      ctx.stroke();
    }
    ctx.fillStyle = e.flash > 0 ? '#555' : '#000'; ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    ctx.strokeStyle = '#d0a8ff'; ctx.lineWidth = 3; ctx.stroke();
  },
};

/* =====================================================================
   보스별 추가 패턴 (기존 패턴 위에 겹쳐서 돌아갑니다)
   체력이 절반 아래로 내려가면(2페이즈) 간격이 짧아지고 패턴이 하나 더 붙습니다.
   ===================================================================== */
function wrapBoss(id, extra) {
  const T = ENEMY_TYPES[id], base = T.update;
  T.update = function (e, dt, g) {
    const r = base.call(T, e, dt, g);
    if (!e.dead && g.arena) {
      if (e.xt === undefined) { e.xt = 3; e.xn = 0; e.q = []; }
      e.rage = e.hp < e.maxHp * 0.5;
      for (const j of e.q) j.t -= dt;                      // 예약된 발사
      e.q = e.q.filter((j) => (j.t <= 0 ? (j.f(), false) : true));
      e.xt -= dt;
      if (e.xt <= 0) { e.xn++; e.xt = extra(e, g) * e.intMul * (e.rage ? 0.7 : 1); }
    }
    return r;
  };
}
function later(e, t, f) { e.q.push({ t, f }); }
function arenaEdge(g, side, u) {                            // side 0 위 1 아래 2 왼쪽 3 오른쪽, u 0~1 은 변 위의 위치
  const A = g.arena;
  if (side === 0) return [A.x0 + (A.x1 - A.x0) * u, A.y0 + 4, Math.PI / 2];
  if (side === 1) return [A.x0 + (A.x1 - A.x0) * u, A.y1 - 4, -Math.PI / 2];
  if (side === 2) return [A.x0 + 4, A.y0 + (A.y1 - A.y0) * u, 0];
  return [A.x1 - 4, A.y0 + (A.y1 - A.y0) * u, Math.PI];
}
/* 한쪽 벽에서 반대쪽으로 가는 탄 장막 (틈 하나) */
function curtain(g, e, side, speed, gap) {
  const n = 22, hole = 2 + Math.floor(Math.random() * (n - 5));
  for (let i = 0; i < n; i++) {
    if (i >= hole && i < hole + gap) continue;
    const [x, y, a] = arenaEdge(g, side, (i + 0.5) / n);
    bossShot(g, e, x, y, a, speed);
  }
}

/* 분열체: 별똥 폭우 ↔ 꽃잎 고리 */
wrapBoss('bossSplit', (e, g) => {
  const A = g.arena;
  if (e.xn % 2) {                                          // 꽃잎: 어긋난 고리 3번
    const a0 = Math.random() * TAU;
    for (let k = 0; k < 3; k++) later(e, k * 0.3, () => { if (!e.dead) ringShot(g, e, e.x, e.y, 14, a0 + k * 0.22, 150 + k * 25); });
    return 6;
  }
  for (let i = 0; i < 16; i++) {                           // 위에서 쏟아지는 별똥
    const x = A.x0 + (A.x1 - A.x0) * (i + Math.random() * 0.8) / 16;
    later(e, i * 0.08, () => bossShot(g, e, x, A.y0 + 4, Math.PI / 2 + U.rand(-0.12, 0.12), 230));
  }
  if (e.rage) later(e, 1, () => aimedShots(g, e, e.x, e.y, 5, 0.16, 210));
  return 5.5;
});

/* 돌진체: 돌진 중 꼬리 탄, 대기 중 십자 포격 */
wrapBoss('bossCharge', (e, g) => {
  if (e.state === 'dash') { for (const s of [-1, 1]) bossShot(g, e, e.x, e.y, e.dashAng + s * Math.PI / 2, 70); return 0.07; }
  if (e.xn % 3 === 0) { const a0 = Math.random() * TAU; for (let i = 0; i < 8; i++) bossShot(g, e, e.x, e.y, a0 + i * TAU / 8, 210); return 1.2; }
  curtain(g, e, Math.floor(Math.random() * 4), 140, 4); return e.rage ? 2.5 : 4;
});

/* 방벽체: 쌍나선 + 열린 동안 역회전 고리 */
wrapBoss('bossShield', (e, g) => {
  const dir = e.xn % 2 ? 1 : -1, a0 = Math.random() * TAU;
  for (let k = 0; k < 16; k++) later(e, k * 0.1, () => {
    if (e.dead) return;
    for (let s = 0; s < 2; s++) bossShot(g, e, e.x, e.y, a0 + dir * k * 0.42 + s * Math.PI, 175);
    if (e.rage) bossShot(g, e, e.x, e.y, a0 - dir * k * 0.3 + Math.PI / 2, 160);
  });
  return e.state === 'open' ? 3 : 6.5;
});

/* 철갑체: 탄 장막 + 유도 포격 */
wrapBoss('bossTank', (e, g) => {
  if (e.xn % 2) { curtain(g, e, Math.floor(Math.random() * 4), 125, e.rage ? 3 : 4); if (e.rage) later(e, 1.4, () => curtain(g, e, Math.floor(Math.random() * 4), 125, 3)); return 5; }
  for (let k = 0; k < 4; k++) later(e, k * 0.35, () => { if (!e.dead) aimedShots(g, e, e.x, e.y, 5, 0.14, 230); });
  return 5.5;
});

/* 수정체: 2페이즈에서 십자 레이저, 평소엔 파편 부채꼴과 격자 탄 */
const _crystalBeams = ENEMY_TYPES.bossCrystal.beams;
ENEMY_TYPES.bossCrystal.beams = (e) => (e.hp < e.maxHp * 0.5 ? [e.la, e.la + Math.PI / 2] : [e.la]);
wrapBoss('bossCrystal', (e, g) => {
  if (e.xn % 2) { const a = Math.atan2(g.player.y - e.y, g.player.x - e.x); for (let i = 0; i < 9; i++) bossShot(g, e, e.x, e.y, a + (i - 4) * 0.2, 170 + (i % 2) * 50); return 4; }
  const a0 = Math.random() * TAU;                          // 수정 파편: 두 겹 고리가 서로 엇갈림
  ringShot(g, e, e.x, e.y, 18, a0, 130); later(e, 0.45, () => { if (!e.dead) ringShot(g, e, e.x, e.y, 18, a0 + Math.PI / 18, 190); });
  return 5;
});

/* 심연의 블랙홀: 중력 맥동 + 회전 팔, 2페이즈에선 4방향 소용돌이 */
wrapBoss('bossHole', (e, g) => {
  if (e.xn % 3 === 0) {                                    // 중력 맥동: 촘촘한 고리가 빠르게 퍼짐
    g.shake = Math.max(g.shake, 5); g.fx.ring(e.x, e.y, 160, [190, 140, 255], 0.6);
    ringShot(g, e, e.x, e.y, 26, Math.random() * TAU, 190, Math.floor(Math.random() * 26), 3);
    return 4;
  }
  const dir = Math.random() < 0.5 ? 1 : -1, arms = e.rage ? 4 : 2, a0 = Math.random() * TAU;
  for (let k = 0; k < 18; k++) later(e, k * 0.09, () => { if (e.dead) return; for (let s = 0; s < arms; s++) bossShot(g, e, e.x, e.y, a0 + dir * k * 0.38 + s * TAU / arms, 185); });
  if (e.rage) later(e, 1.8, () => aimedShots(g, e, e.x, e.y, 7, 0.14, 220));
  return 5;
});
