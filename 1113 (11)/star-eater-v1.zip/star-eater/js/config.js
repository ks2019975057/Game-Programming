'use strict';
/* ============================================================
   config.js - 게임의 모든 수치는 여기서 관리합니다.
   밸런스를 바꿀 때는 이 파일의 숫자만 고치면 됩니다.
   ============================================================ */
const CONFIG = {
  player: {
    maxHp: 100,
    speed: 200,        // px/s
    smooth: 12,        // 가감속 부드러움 (클수록 즉각 반응)
    radius: 6,
    invuln: 0.5,       // 피격 후 무적 시간(초)
    magnetRange: 60,   // 경험치 구슬 흡수 범위(px)
  },

  // ---------- 경험치 구슬 ----------
  xp: {
    gems: {
      small:  { value: 1,  radius: 4,  color: [255, 230, 128] },
      medium: { value: 5,  radius: 7,  color: [127, 224, 255] },
      large:  { value: 20, radius: 11, color: [224, 160, 255] },
    },
    magnet: { startSpeed: 150, accel: 600, pickupRadius: 12 },
    maxGems: 300,                              // 초과하면 가까운 구슬끼리 합침
    need: (level) => Math.round(5 * Math.pow(1.25, level - 1)),
    recoverCardRate: 0.30,                     // 카드가 모자랄 때 나오는 회복 카드
  },

  // ---------- 시간에 따른 적 성장 (분 단위) ----------
  growth: { hp: 0.30, speed: 0.03, contact: 0.10 },
  // 초반 적 체력 완화: 시작 시 earlyHp.start 배에서 earlyHp.minutes 분에 걸쳐 1배로
  earlyHp: { start: 0.6, minutes: 4 },

  // ---------- 스폰 ----------
  spawn: { base: 2, perMin: 0.6, maxEnemies: 300, margin: 60 },

  // ---------- 적 ----------
  // drop: 확정으로 떨구는 구슬 / bonus: 낮은 확률로 추가로 떨구는 구슬
  enemies: {
    basic:    { name: '기본 적', hp: 20,  defense: 0,    speed: 80, contact: 5,  radius: 10, color: [107, 127, 153],
                drop: { tier: 'small', bonusTier: 'medium', bonusChance: 0.08 } },
    speedy:   { name: '스피드', hp: 10,  defense: 0,    speed: 70, contact: 4,  radius: 8,  color: [255, 170, 90],
                boostMul: 2, boostTime: 3,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    shielded: { name: '보호막', hp: 20,  defense: 0,    speed: 75, contact: 5,  radius: 10, color: [140, 150, 175],
                shieldBase: 3, shieldPerMin: 1 / 3, shieldMax: 6, shieldGap: 0.2,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    tanker:   { name: '탱커', hp: 100, defense: 0.30, speed: 45, contact: 12, radius: 18, color: [96, 112, 150],
                defensePerMin: 0.02, defenseMax: 0.50,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    splitter: { name: '분열', hp: 40,  defense: 0,    speed: 70, contact: 5,  radius: 13, color: [176, 144, 214],
                splitCount: 3, splitCountLate: 4, lateMin: 7,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    fragment: { name: '분열 조각', hp: 10, defense: 0, speed: 90, contact: 3, radius: 6, color: [200, 175, 235],
                drop: { tier: 'small' } },
    counter:  { name: '반격', hp: 30,  defense: 0,    speed: 75, contact: 5,  radius: 11, color: [232, 96, 96],
                bullets: 10, dirs: 12, gapDirs: 2, bulletDamage: 6, bulletSpeed: 180, bulletRange: 400,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    charger:  { name: '돌진', hp: 25,  defense: 0,    speed: 60, contact: 6,  radius: 11, color: [255, 72, 72],
                stopDist: 300, warn: 0.8, dashDist: 450, dashSpeed: 400, dashContactMul: 2, rest: 1.5,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    healer:   { name: '치유', hp: 30,  defense: 0,    speed: 65, contact: 3,  radius: 10, color: [90, 230, 130],
                healRange: 120, healRate: 0.05,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    devourer: { name: '포식', hp: 30,  defense: 0,    speed: 60, contact: 6,  radius: 12, color: [210, 60, 170],
                huntRange: 400, eatDist: 20, eatPause: 0.5, eatGap: 2, maxEats: 8,
                gainHp: 0.5, gainContact: 0.3, gainSpeed: 3, gainRadius: 0.05,
                awakeDefense: 0.30, awakeSpeedMul: 1.2, timeout: 90,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    anchor:   { name: '앵커', hp: 60,  defense: 0.15, speed: 55, contact: 8,  radius: 12, color: [150, 154, 176], immovable: true,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    archer:   { name: '사수', hp: 25,  defense: 0,    speed: 70, contact: 4,  radius: 10, color: [120, 200, 255],
                stopDist: 350, retreatDist: 150, fireRange: 450, fireGap: 2.5, aim: 0.4,
                bulletDamage: 8, bulletSpeed: 220, bulletRange: 600,
                drop: { tier: 'medium', bonusTier: 'large', bonusChance: 0.05 } },
    // ---- 보스 (체력은 CONFIG.boss 로 계산하므로 hp 는 자리표시) ----
    bossSplit:   { name: '분열체',   hp: 1, defense: 0, speed: 30, contact: 1, radius: 120, color: [176, 144, 214], drop: null },
    bossCharge:  { name: '돌진체',   hp: 1, defense: 0, speed: 0,  contact: 1, radius: 50,  color: [255, 72, 72], drop: null,
                   dashSpeed: 500, dashDist: 450, dashContactMul: 2, warn: 1.0, idle: 0.6, stun: 3, stunTaken: 1.3, recover: 2, debris: 8 },
    bossShield:  { name: '방벽체',   hp: 1, defense: 0, speed: 0,  contact: 1, radius: 40,  color: [255, 225, 80], drop: null,
                   sats: 8, orbit: 140, orbitSpeed: 60, satRadius: 28, satHpRatio: 0.06, open: 14, fireGap: 2, dirs: 12, rotStep: 15 },
    bossSat:     { name: '방벽 위성', hp: 1, defense: 0, speed: 0,  contact: 1, radius: 28,  color: [255, 235, 140], drop: null },
    bossTank:    { name: '철갑체',   hp: 1, defense: 0, speed: 25, contact: 1, radius: 60,  color: [96, 112, 150], drop: null,
                   sections: 8, tele: 1, open: 4, waveGap: 3, waveDirs: 20, waveGapDirs: 3, waveSpeed: 170 },
    bossCrystal: { name: '수정체',   hp: 1, defense: 0, speed: 0,  contact: 1, radius: 45,  color: [120, 230, 255], drop: null,
                   laserSpeed: 12, laserWarn: 1.5, laserOn: 6, laserOff: 2.5, laserWidth: 12, laserDamage: 15,
                   spiralGap: 2.5, spiralTime: 1.2, spiralArms: 3, spiralEmit: 0.06, spiralStep: 22, spiralSpeed: 190 },
    bossHole:    { name: '심연의 블랙홀', hp: 1, defense: 0, speed: 0, contact: 1, radius: 60, color: [170, 110, 255], drop: null,
                   pull: 40, pullEnraged: 1.5, drainPerSec: 40, spawnGap: 0.45, spawnCount: 3, bulletSpeed: 150, spin: 1.0 },
  },

  // 특수 적: 스폰 중 일부가 특수 적이 됨 (비율 = base + perMin × 분, 최대 maxShare)
  specials: {
    shareBase: 0.05, sharePerMin: 0.02, maxShare: 0.5,
    types: [   // unlock: 등장 시작 분, weight: 뽑힐 가중치
      { id: 'speedy',   unlock: 0, weight: 20 },
      { id: 'shielded', unlock: 0, weight: 15 },
      { id: 'tanker',   unlock: 1, weight: 12 },
      { id: 'splitter', unlock: 2, weight: 12 },
      { id: 'archer',   unlock: 2, weight: 10 },
      { id: 'charger',  unlock: 3, weight: 10 },
      { id: 'healer',   unlock: 4, weight: 6 },
      { id: 'counter',  unlock: 5, weight: 8 },
      { id: 'anchor',   unlock: 5, weight: 7 },
      { id: 'devourer', unlock: 6, weight: 5 },
    ],
  },
  enemyBullet: { radius: 5, color: [255, 90, 90], growthContact: true },


  // ---------- 보스 ----------
  boss: {
    firstAt: 120, gap: 120,            // 첫 보스까지 / 보스 처치 후 다음 보스까지 (초)
    warnAt: 30, countdownAt: 10, intro: 2,
    baseHp: 3500, bulletDamage: 10, contact: 20, bulletRange: 1600,
    hpMul: { bossSplit: 1, bossCharge: 0.8, bossShield: 0.8, bossTank: 0.5, bossCrystal: 1, bossHole: 1 },
    // 나오는 순서(1번째~5번째)에 따른 배율
    scale: [
      { hp: 1.0, dmg: 1.00, speed: 1.00, interval: 1.00 },
      { hp: 1.5, dmg: 1.15, speed: 1.05, interval: 0.95 },
      { hp: 2.0, dmg: 1.30, speed: 1.10, interval: 0.90 },
      { hp: 2.5, dmg: 1.45, speed: 1.15, interval: 0.85 },
      { hp: 3.0, dmg: 1.60, speed: 1.20, interval: 0.80 },
    ],
    final: { hp: 3.5 * 1.5, dmg: 1.75, speed: 1.25, interval: 0.75 },
    healOnKill: 0, dropCount: 2, dropExtraChance: 0.5,   // 보스 처치 회복은 회복 구슬(items.bossDrop)로 대체
    order: ['bossSplit', 'bossCharge', 'bossShield', 'bossTank', 'bossCrystal'],   // 이 순서를 무작위로 섞음
    finalBoss: 'bossHole',
    split: { gens: 5, radius: [120, 84, 59, 41, 29], speed: [30, 45, 65, 90, 120], threshold: 0.5, bullets: 6, bulletSpeed: 200 },
  },

  // ---------- 이펙트 강도 (0 = 끔, 1 = 기본, 2 = 두 배) ----------
  fx: { shake: 1, particles: 1, popups: 1, hitFlash: 1 },

  // ---------- 특수 아이템 ----------
  // 적이 가끔 떨어뜨리며, 가까이 가서 먹어야 발동합니다. 특수 적은 확률 x specialMul.
  items: {
    maxOnField: 3, minGap: 15, life: 30, pickupRadius: 16, attractRange: 90,
    specialMul: 3, bossDrop: 'healOrb',
    types: {
      starBurst:  { name: '별의 폭발', color: [255, 226, 120], chance: 0.004, damage: 150, desc: '화면 안의 모든 적에게 피해 150' },
      gravityOrb: { name: '중력 구슬', color: [170, 110, 255], chance: 0.004, magnetMul: 3, time: 8, desc: '모든 별 조각을 끌어오고 8초간 흡수 범위 3배' },
      healOrb:    { name: '회복 구슬', color: [120, 230, 150], chance: 0.005, heal: 0.30, desc: '최대 체력의 30% 회복' },
    },
  },

  // ---------- 무기 ----------
  weaponOrder: ['spaceDust', 'radiantHeat', 'satellite', 'meteor', 'atmosphere', 'comet', 'blackHole', 'plasma'],
  maxWeaponSlots: 6,
  weapons: {
    spaceDust: {
      name: '우주 먼지', color: [127, 224, 255],
      desc: '가장 가까운 적에게 작은 투사체를 연사합니다.',
      burstInterval: 0.05, maxRange: 500, targetRange: 600, minCooldown: 0.15, projectileRadius: 4,
      labels: { damage: '피해', count: '투사체 수', speed: '투사체 속도', cooldown: '쿨타임' },
      levels: [
        { damage: 8,  count: 1, speed: 300, cooldown: 1.00 },
        { damage: 9,  count: 1, speed: 330, cooldown: 0.75 },
        { damage: 10, count: 2, speed: 360, cooldown: 0.60 },
        { damage: 11, count: 2, speed: 390, cooldown: 0.42 },
        { damage: 12, count: 3, speed: 420, cooldown: 0.30 },
      ],
    },
    radiantHeat: {
      name: '복사열', color: [255, 154, 60],
      desc: '플레이어 중심의 원형 영역이 주기적으로 펄스를 내서 닿은 적에게 피해를 줍니다.',
      minCooldown: 0.30,
      labels: { damage: '피해', radius: '범위', cooldown: '쿨타임' },
      levels: [
        { damage: 5, radius: 60,  cooldown: 1.00 },
        { damage: 6, radius: 70,  cooldown: 0.90 },
        { damage: 7, radius: 80,  cooldown: 0.80 },
        { damage: 8, radius: 90,  cooldown: 0.70 },
        { damage: 9, radius: 100, cooldown: 0.60 },
      ],
    },

    satellite: {
      name: '위성', color: [190, 200, 255],
      desc: '위성이 플레이어 주위를 공전하며 닿은 적에게 피해를 줍니다. 지속시간이 끝나면 사라지고 쿨타임 뒤 다시 소환됩니다.',
      orbitRadius: 120, satRadius: 8, hitInterval: 0.5, fade: 0.3,
      labels: { damage: '피해', count: '위성 수', orbitSpeed: '공전 속도', duration: '지속시간', cooldown: '쿨타임' },
      levels: [
        { damage: 8,  count: 2, orbitSpeed: 100, duration: 3.0, cooldown: 5.0 },
        { damage: 9,  count: 2, orbitSpeed: 110, duration: 3.5, cooldown: 4.5 },
        { damage: 10, count: 3, orbitSpeed: 120, duration: 4.0, cooldown: 4.0 },
        { damage: 11, count: 4, orbitSpeed: 130, duration: 4.5, cooldown: 3.5 },
        { damage: 12, count: 5, orbitSpeed: 140, duration: 5.0, cooldown: 3.0 },
      ],
    },
    meteor: {
      name: '운석', color: [255, 120, 70],
      desc: '근처 무작위 적 위로 운석을 떨어뜨립니다. 경고 표시 뒤 착탄해 범위 피해를 줍니다.',
      warn: 0.6, castInterval: 0.15, targetRange: 500, retry: 0.3,
      labels: { damage: '피해', radius: '범위', count: '운석 수', cooldown: '쿨타임' },
      levels: [
        { damage: 25, radius: 50, count: 1, cooldown: 4.0 },
        { damage: 30, radius: 55, count: 1, cooldown: 3.6 },
        { damage: 35, radius: 60, count: 2, cooldown: 3.2 },
        { damage: 40, radius: 65, count: 2, cooldown: 2.8 },
        { damage: 45, radius: 70, count: 3, cooldown: 2.4 },
      ],
    },
    atmosphere: {
      name: '대기', color: [127, 200, 255],
      desc: '피해를 한 번 막아 주는 보호막을 두릅니다. 깨지면 잠시 무적이 되고, 쿨타임 뒤 다시 생깁니다.',
      minCooldown: 4.0, breakInvuln: 0.5,
      labels: { cooldown: '재생성 쿨타임' },
      levels: [
        { cooldown: 20 }, { cooldown: 17 }, { cooldown: 14 }, { cooldown: 11 }, { cooldown: 8 },
      ],
    },
    comet: {
      name: '혜성', color: [160, 230, 255],
      desc: '가장 가까운 적 방향으로 적을 꿰뚫는 혜성을 부채꼴로 발사합니다.',
      speed: 500, radius: 12, range: 800, spread: 10, targetRange: 600,
      labels: { damage: '피해', count: '혜성 수', cooldown: '쿨타임' },
      levels: [
        { damage: 20, count: 1, cooldown: 3.0 },
        { damage: 24, count: 1, cooldown: 2.8 },
        { damage: 28, count: 2, cooldown: 2.6 },
        { damage: 32, count: 2, cooldown: 2.4 },
        { damage: 36, count: 3, cooldown: 2.2 },
      ],
    },
    blackHole: {
      name: '블랙홀', color: [170, 110, 255],
      desc: '적이 가장 많이 모인 곳에 블랙홀을 만들어 적을 끌어당기며 지속 피해를 줍니다.',
      pullSpeed: 80, tick: 0.5, targetRange: 500, stopRadius: 12, retry: 0.3,
      labels: { damage: '피해', radius: '범위', duration: '지속시간', cooldown: '쿨타임' },
      levels: [
        { damage: 4, radius: 90,  duration: 2.0, cooldown: 8.0 },
        { damage: 5, radius: 100, duration: 2.5, cooldown: 7.5 },
        { damage: 6, radius: 110, duration: 3.0, cooldown: 7.0 },
        { damage: 7, radius: 120, duration: 3.5, cooldown: 6.5 },
        { damage: 8, radius: 130, duration: 4.0, cooldown: 6.0 },
      ],
    },
    plasma: {
      name: '플라즈마', color: [255, 110, 220],
      desc: '가까운 적을 맞히고 주변 적에게 튕기며 연쇄 피해를 줍니다. 피해는 줄지 않습니다.',
      jumpRange: 150, targetRange: 400, retry: 0.2,
      labels: { damage: '피해', chain: '연쇄 수', cooldown: '쿨타임' },
      levels: [
        { damage: 14, chain: 2, cooldown: 2.0 },
        { damage: 16, chain: 3, cooldown: 1.9 },
        { damage: 18, chain: 3, cooldown: 1.8 },
        { damage: 20, chain: 4, cooldown: 1.6 },
        { damage: 22, chain: 5, cooldown: 1.4 },
      ],
    },
  },

  // ---------- 진화 (레벨 없는 고정 수치) ----------
  // stats: 5레벨 수치 위에 덮어쓰는 값 / p: 진화 효과 수치
  evoWeight: 3,                      // 진화 카드의 추첨 가중치 (일반 카드는 1)
  evolutions: [
    // --- 우주 먼지 ---
    { id: 'starRay', name: '별가루 광선', target: 'spaceDust', partner: 'comet',
      desc: '먼지가 가늘고 빠른 광선이 되어 적을 3마리까지 관통합니다.', stats: { speed: 800, cooldown: 0.38, pierce: 2 }, p: {} },
    { id: 'burstDust', name: '폭렬 먼지', target: 'spaceDust', partner: 'meteor',
      desc: '적중하면 반경 40px 폭발(피해 20). 쿨타임이 1.0초로 늘어납니다.', stats: { cooldown: 1.0 }, p: { radius: 40, damage: 20 } },
    { id: 'shockDust', name: '충격 먼지', target: 'spaceDust', partner: 'atmosphere',
      desc: '피해 18. 맞은 적을 날아가던 방향으로 40px 밀어냅니다.', stats: { damage: 18 }, p: { dist: 40, dur: 0.12, cd: 0.5 } },
    { id: 'ricochetDust', name: '도탄 먼지', target: 'spaceDust', partner: 'plasma',
      desc: '적에 맞으면 250px 안의 다른 적으로 최대 2번 튕깁니다. (튕긴 뒤 피해 75%)', stats: { cooldown: 0.35 }, p: { range: 250, max: 2, mul: 0.75 } },
    // --- 혜성 ---
    { id: 'nebula', name: '성운 혜성', target: 'comet', partner: 'spaceDust',
      desc: '혜성이 나는 동안 0.25초마다 좌우로 우주 먼지 탄환을 쏩니다.', stats: {}, p: { interval: 0.25, maxPairs: 6, damage: 8, speed: 400, range: 200 } },
    { id: 'blaze', name: '작열 혜성', target: 'comet', partner: 'radiantHeat',
      desc: '혜성이 지나간 자리에 2초간 남는 복사열 장판(0.5초마다 피해 14)을 남깁니다.', stats: {}, p: { step: 60, radius: 40, life: 2, tick: 0.5, damage: 14 } },
    { id: 'boom', name: '폭발 혜성', target: 'comet', partner: 'meteor',
      desc: '사거리가 550px로 줄고, 사거리 끝에서 반경 100px 폭발(피해 18)을 일으킵니다.', stats: { range: 550 }, p: { radius: 100, damage: 18 } },
    { id: 'cometLaser', name: '혜성 레이저', target: 'comet', partner: 'atmosphere',
      desc: '발사 대신 2초간 이어지는 레이저를 쏘고, 맞은 적을 밀어냅니다.', stats: { cooldown: 3.0 }, p: { len: 600, width: 24, dur: 2, tick: 0.1, damage: 18, turn: 240, knock: 40, knockCd: 0.5 } },
    // --- 블랙홀 ---
    { id: 'discharge', name: '방전 블랙홀', target: 'blackHole', partner: 'plasma',
      desc: '블랙홀이 1초마다 범위 안 적에게 플라즈마(피해 8, 연쇄 4)를 일으킵니다.', stats: {}, p: { interval: 1.0, damage: 8, hits: 4, jump: 100 } },
    { id: 'accretion', name: '강착 원반', target: 'blackHole', partner: 'satellite',
      desc: '블랙홀 중심을 작은 위성 3개가 공전하며 닿은 적에게 피해 5를 줍니다.', stats: {}, p: { count: 3, radius: 30, speed: 180, size: 8, damage: 5, gap: 0.5 } },
    { id: 'collapse', name: '중력 붕괴', target: 'blackHole', partner: 'meteor',
      desc: '블랙홀이 끝날 때 중심으로 운석 2발(반경 90px, 피해 16)이 떨어집니다.', stats: {}, p: { count: 2, gap: 0.2, radius: 90, damage: 16, warn: 0.5 } },
    { id: 'flameHole', name: '화염 블랙홀', target: 'blackHole', partner: 'radiantHeat',
      desc: '블랙홀 안에 반경 100px 복사열 장판이 생겨 0.5초마다 피해 4를 줍니다.', stats: {}, p: { radius: 100, tick: 0.5, damage: 4 } },
    // --- 운석 ---
    { id: 'dustRain', name: '먼지 운석우', target: 'meteor', partner: 'spaceDust',
      desc: '착탄 지점에서 우주 먼지 탄환 8발이 사방으로 퍼집니다.', stats: {}, p: { count: 8, damage: 14, speed: 350, range: 200 } },
    { id: 'barrier', name: '방벽 운석', target: 'meteor', partner: 'atmosphere',
      desc: '피해 68. 착탄 지점에 3초간 벽이 생겨 일반 적과 적 탄이 통과하지 못합니다.', stats: { damage: 68 }, p: { len: 120, thick: 12, life: 3, max: 9 } },
    { id: 'fireball', name: '화구 폭격', target: 'meteor', partner: 'radiantHeat',
      desc: '착탄한 자리에 3초간 불타는 장판(반경 70px, 0.5초마다 피해 14)이 남습니다.', stats: {}, p: { radius: 70, life: 3, tick: 0.5, damage: 14 } },
    { id: 'gravityMeteor', name: '중력 운석', target: 'meteor', partner: 'blackHole',
      desc: '피해 68. 착탄 지점에 2초간 블랙홀이 생겨 적을 끌어당깁니다.', stats: { damage: 68 }, p: { radius: 90, life: 2, pull: 80, max: 6 } },
    // --- 복사열 ---
    { id: 'pressure', name: '복사압', target: 'radiantHeat', partner: 'atmosphere',
      desc: '피해 14. 펄스마다 범위 안의 적을 바깥으로 12px 밀어냅니다.', stats: { damage: 14, cooldown: 0.62 }, p: { push: 12, dur: 0.1 } },
    { id: 'shockHeat', name: '전열 복사', target: 'radiantHeat', partner: 'plasma',
      desc: '펄스에 맞은 적이 감전 피해 5를 받고 0.3초간 멈춥니다.', stats: {}, p: { damage: 5, stun: 0.3, stunCd: 1.5 } },
    { id: 'orbitHeat', name: '궤도 복사', target: 'radiantHeat', partner: 'satellite',
      desc: '복사열이 반경 50px 영역 4개로 갈라져 플레이어 주변을 공전하며 펄스(피해 13)를 냅니다.', stats: { damage: 13, cooldown: 0.6 }, p: { count: 4, radius: 50, orbit: 70, speed: 120 } },
    { id: 'rayHeat', name: '복사 광선', target: 'radiantHeat', partner: 'comet',
      desc: '원형 펄스 대신 0.8초마다 가까운 적에게 짧은 광선(피해 30)을 쏩니다.', stats: { damage: 30, cooldown: 0.8 }, p: { len: 100, width: 24, dur: 0.15, range: 250 } },
    // --- 위성 ---
    { id: 'gravitySat', name: '인력 위성', target: 'satellite', partner: 'blackHole',
      desc: '접촉 피해 18. 위성 반경 50px 안의 적을 위성 쪽으로 약하게 끌어당깁니다.', stats: { damage: 18 }, p: { range: 50, pull: 30 } },
    { id: 'dustSat', name: '먼지 위성', target: 'satellite', partner: 'spaceDust',
      desc: '위성마다 1.5초에 한 번 가까운 적에게 우주 먼지탄(피해 9)을 쏩니다.', stats: {}, p: { gap: 1.5, damage: 9, speed: 400, range: 400 } },
    { id: 'plasmaSat', name: '방전 위성', target: 'satellite', partner: 'plasma',
      desc: '위성마다 3초에 한 번 플라즈마(피해 7, 연쇄 4)를 쏩니다.', stats: {}, p: { gap: 3, damage: 7, hits: 4, jump: 100, range: 400 } },
    { id: 'heatSat', name: '열위성', target: 'satellite', partner: 'radiantHeat',
      desc: '위성에 부딪힌 적이 3초간 0.5초마다 화상 피해 4를 입습니다.', stats: {}, p: { time: 3, tick: 0.5, damage: 4 } },
    // --- 플라즈마 ---
    { id: 'condense', name: '응집 플라즈마', target: 'plasma', partner: 'blackHole',
      desc: '피해 33. 맞은 적들이 서로 뭉치도록 중심점 쪽으로 끌려갑니다.', stats: { damage: 33 }, p: { pull: 40, dur: 0.3 } },
    { id: 'plasmaLaser', name: '플라즈마 레이저', target: 'plasma', partner: 'comet',
      desc: '연쇄 경로에 레이저가 1.5초간 남아 0.5초마다 피해 4를 줍니다.', stats: {}, p: { width: 16, life: 1.5, tick: 0.5, damage: 4 } },
    { id: 'tractor', name: '견인 플라즈마', target: 'plasma', partner: 'satellite',
      desc: '피해 33. 위성 가까이에서 맞은 적이 2초간 위성 쪽으로 끌려다닙니다.', stats: { damage: 33 }, p: { range: 80, time: 2, speed: 60 } },
    { id: 'guided', name: '유도 플라즈마', target: 'plasma', partner: 'spaceDust',
      desc: '피해 33. 맞은 적에게 표식이 붙어 우주 먼지 탄환이 유도됩니다.', stats: { damage: 33 }, p: { mark: 2, range: 150, turn: 180 } },
    // --- 대기 (보호막이 깨질 때마다 발동) ---
    { id: 'gravityWall', name: '중력 방벽', target: 'atmosphere', partner: 'blackHole',
      desc: '보호막이 깨질 때 반경 400px 충격파(피해 200)로 적을 화면 가장자리까지 밀어냅니다.', stats: {}, p: { radius: 400, damage: 200, dur: 0.5 } },
    { id: 'starWall', name: '별똥 방벽', target: 'atmosphere', partner: 'comet',
      desc: '보호막이 깨질 때 사방으로 혜성 24발(피해 100)을 쏩니다.', stats: {}, p: { count: 24, damage: 100 } },
    { id: 'meteorWall', name: '유성 방벽', target: 'atmosphere', partner: 'meteor',
      desc: '보호막이 깨질 때 주변 적 위로 운석 8발(피해 25)이 떨어집니다.', stats: {}, p: { count: 8, gap: 0.1, range: 400, warn: 0.3, damage: 25, radius: 60 } },
    { id: 'twinWall', name: '쌍성 방벽', target: 'atmosphere', partner: 'satellite',
      desc: '보호막이 깨질 때 위성을 즉시 소환하고 3초간 5개를 더해 10개로 만듭니다.', stats: {}, p: { extra: 5, time: 3 } },
  ],

  // ---------- 시작 패시브 ----------
  // enabled: false 로 바꾸면 선택 화면에서 잠깁니다.
  passives: [
    { id: 'interstellar', name: '성간 가속',     weapon: 'spaceDust',   enabled: true,
      desc: '쿨타임 -15%, 투사체 속도 +15%', mods: { cooldown: 0.85, speed: 1.15 } },
    { id: 'sun',          name: '태양',         weapon: 'radiantHeat', enabled: true,
      desc: '피해 +15%, 범위 +15%',          mods: { damage: 1.15, radius: 1.15 } },
    { id: 'saturn',       name: '토성',         weapon: 'satellite',   enabled: true,
      desc: '지속시간 +25%, 쿨타임 -15%',     mods: { duration: 1.25, cooldown: 0.85 } },
    { id: 'asteroidBelt', name: '소행성대',      weapon: 'meteor',      enabled: true,
      desc: '쿨타임 -15%, 폭발 범위 +15%',    mods: { cooldown: 0.85, radius: 1.15 } },
    { id: 'oort',         name: '오르트 구름',   weapon: 'comet',       enabled: true,
      desc: '피해 +20%, 사거리 +25%',        mods: { damage: 1.20, range: 1.25 } },
    { id: 'horizon',      name: '사건의 지평선', weapon: 'blackHole',   enabled: true,
      desc: '지속시간 +25%, 쿨타임 -15%',     mods: { duration: 1.25, cooldown: 0.85 } },
    { id: 'ionStorm',     name: '이온 폭풍',     weapon: 'plasma',      enabled: true,
      desc: '연쇄 +1, 튀는 거리 +20%',       mods: { chainAdd: 1, jumpRange: 1.2 } },
    { id: 'earth',        name: '지구',         weapon: 'atmosphere',  enabled: true,
      desc: '보호막 2겹 중첩 + 랜덤 무기 1개로 시작', mods: { layers: 2 } },
  ],

  weaponNames: {
    spaceDust: '우주 먼지', radiantHeat: '복사열', satellite: '위성', meteor: '운석',
    atmosphere: '대기', comet: '혜성', blackHole: '블랙홀', plasma: '플라즈마',
  },
};
