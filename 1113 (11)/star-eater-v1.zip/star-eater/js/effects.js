'use strict';
/* effects.js - 글로우 스프라이트, 파티클, 데미지 숫자, 충격 링, 배경 */

/* 부드러운 빛 덩어리를 미리 그려 두고 재사용합니다. (shadowBlur보다 훨씬 가벼움) */
const Glow = {
  cache: new Map(),
  get(color, size) {
    const key = color.join(',') + ':' + size;
    let c = this.cache.get(key);
    if (!c) {
      c = document.createElement('canvas');
      c.width = c.height = size * 2;
      const g = c.getContext('2d');
      const grad = g.createRadialGradient(size, size, 0, size, size, size);
      grad.addColorStop(0, U.rgba(color, 1));
      grad.addColorStop(0.25, U.rgba(color, 0.55));
      grad.addColorStop(1, U.rgba(color, 0));
      g.fillStyle = grad;
      g.fillRect(0, 0, size * 2, size * 2);
      this.cache.set(key, c);
    }
    return c;
  },
};

class Effects {
  constructor() {
    this.particles = [];
    this.popups = [];
    this.rings = [];
    this.pool = [];              // 파티클 오브젝트 풀 (new 대신 재사용)
  }
  reset() { for (const p of this.particles) this.pool.push(p); this.particles.length = 0; this.popups.length = 0; this.rings.length = 0; }

  burst(x, y, color, n, speed, life, size) {
    n = Math.round(n * CONFIG.fx.particles);
    for (let i = 0; i < n && this.particles.length < 500; i++) {
      const a = Math.random() * Math.PI * 2, s = speed * (0.4 + Math.random() * 0.6);
      const p = this.pool.pop() || {};
      p.x = x; p.y = y; p.vx = Math.cos(a) * s; p.vy = Math.sin(a) * s; p.life = life; p.max = life; p.color = color; p.size = size;
      this.particles.push(p);
    }
  }
  popup(x, y, text, color) {
    if (CONFIG.fx.popups <= 0 || this.popups.length >= 70) return;
    this.popups.push({ x: x + U.rand(-6, 6), y: y - 8, text, color, life: 0.6, max: 0.6 });
  }
  ring(x, y, r, color, life) {
    this.rings.push({ x, y, r, color, life, max: life });
  }

  update(dt) {
    let j = 0;                                       // 죽은 파티클은 풀로 돌려보내며 제자리에서 압축
    for (let i = 0; i < this.particles.length; i++) {
      const p = this.particles[i];
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.vx *= 1 - 3 * dt; p.vy *= 1 - 3 * dt;
      p.life -= dt;
      if (p.life > 0) this.particles[j++] = p; else this.pool.push(p);
    }
    this.particles.length = j;
    for (const p of this.popups) { p.y -= 28 * dt; p.life -= dt; }
    for (const r of this.rings) r.life -= dt;
    this.popups = this.popups.filter((p) => p.life > 0);
    this.rings = this.rings.filter((r) => r.life > 0);
  }

  draw(ctx, cam) {
    for (const r of this.rings) {
      const t = 1 - r.life / r.max;
      ctx.strokeStyle = U.rgba(r.color, (1 - t) * 0.9);
      ctx.lineWidth = 3 * (1 - t) + 1;
      ctx.beginPath();
      ctx.arc(r.x - cam.x, r.y - cam.y, r.r * (0.6 + 0.4 * t), 0, Math.PI * 2);
      ctx.stroke();
    }
    for (const p of this.particles) {
      const a = p.life / p.max;
      ctx.fillStyle = U.rgba(p.color, a);
      const s = p.size * (0.5 + a * 0.5);
      ctx.fillRect(p.x - cam.x - s / 2, p.y - cam.y - s / 2, s, s);
    }
    ctx.font = 'bold 12px "Noto Sans KR", "Malgun Gothic", sans-serif';
    ctx.textAlign = 'center';
    for (const p of this.popups) {
      ctx.fillStyle = U.rgba(p.color, Math.min(1, p.life / p.max * 1.6));
      ctx.fillText(p.text, p.x - cam.x, p.y - cam.y);
    }
  }
}

/* 별이 흐르는 패럴랙스 배경 (3겹, 무한 반복) */
class Background {
  constructor() {
    this.layers = [
      { tile: 520, count: 55, size: 1.2, parallax: 0.15, alpha: 0.35 },
      { tile: 420, count: 38, size: 1.8, parallax: 0.35, alpha: 0.55 },
      { tile: 320, count: 22, size: 2.6, parallax: 0.60, alpha: 0.80 },
    ];
    for (const L of this.layers) {
      L.stars = [];
      for (let i = 0; i < L.count; i++) {
        L.stars.push({ x: Math.random() * L.tile, y: Math.random() * L.tile, warm: Math.random() < 0.25 });
      }
    }
  }
  draw(ctx, cam, W, H) {
    const g = ctx.createLinearGradient(0, 0, 0, H);
    g.addColorStop(0, '#070816'); g.addColorStop(1, '#0b0a1f');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
    for (const L of this.layers) {
      const ox = -(((cam.x * L.parallax) % L.tile) + L.tile) % L.tile;
      const oy = -(((cam.y * L.parallax) % L.tile) + L.tile) % L.tile;
      for (let tx = ox - L.tile; tx < W; tx += L.tile) {
        for (let ty = oy - L.tile; ty < H; ty += L.tile) {
          for (const s of L.stars) {
            const x = tx + s.x, y = ty + s.y;
            if (x < -4 || x > W + 4 || y < -4 || y > H + 4) continue;
            ctx.fillStyle = s.warm ? 'rgba(255,225,190,' + L.alpha + ')' : 'rgba(200,220,255,' + L.alpha + ')';
            ctx.fillRect(x, y, L.size, L.size);
          }
        }
      }
    }
  }
}
